<?php
namespace Opencart\Admin\Controller\Extension\IvoMarketplace\Startup;

/**
 * Class IvoMarketplace
 * 
 * Startup controller to add IVO Marketplace menu item
 * 
 * @package Opencart\Admin\Controller\Extension\IvoMarketplace\Startup
 */
class IvoMarketplace extends \Opencart\System\Engine\Controller {
	
	/**
	 * Add IVO Marketplace to the Marketing menu
	 * 
	 * @param string $route
	 * @param array $data
	 * @return void
	 */
	public function index(string &$route, array &$data): void {
		if ($this->user->hasPermission('access', 'extension/ivo_marketplace/module/ivo_marketplace')) {
			$this->load->language('extension/ivo_marketplace/module/ivo_marketplace');
			
			// Find the Marketing menu and add IVO Marketplace to it
			foreach ($data['menus'] as &$menu) {
				if ($menu['id'] == 'menu-marketing') {
					$menu['children'][] = [
						'name'     => $this->language->get('heading_title'),
						'href'     => $this->url->link('extension/ivo_marketplace/module/ivo_marketplace', 'user_token=' . $this->session->data['user_token']),
						'children' => []
					];
					break;
				}
			}
		}
	}
}
