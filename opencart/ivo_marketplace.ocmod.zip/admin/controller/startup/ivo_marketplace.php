<?php
namespace Opencart\Admin\Controller\Extension\IvoMarketplace\Startup;

/**
 * Class IvoMarketplace
 * 
 * Startup controller to add IVO Marketplace menu item
 * 
 * @package Opencart\Admin\Controller\Extension\IvoMarketplace\Startup
 */
class IvoMarketplace extends \Opencart\System\Engine\Controller {
	
	/**
	 * Add IVO Marketplace to the Marketing menu
	 * 
	 * @param string $route
	 * @param array $data
	 * @return void
	 */
	public function index(string &$route, array &$data): void {
		$this->ensureStockSyncEvent();

		if ($this->user->hasPermission('access', 'extension/ivo_marketplace/module/ivo_marketplace')) {
			$this->load->language('extension/ivo_marketplace/module/ivo_marketplace');
			
			// Find the Marketing menu and add IVO Marketplace to it
			foreach ($data['menus'] as &$menu) {
				if ($menu['id'] == 'menu-marketing') {
					$menu['children'][] = [
						'name'     => $this->language->get('heading_title'),
						'href'     => $this->url->link('extension/ivo_marketplace/module/ivo_marketplace', 'user_token=' . $this->session->data['user_token']),
						'children' => []
					];
					break;
				}
			}
		}
	}

	/**
	 * Upgrading by zip never runs install() again, so the automatic stock
	 * sync event (added in 1.0.25) is registered here, on the next admin page.
	 */
	private function ensureStockSyncEvent(): void {
		$query = $this->db->query("SELECT `event_id` FROM `" . DB_PREFIX . "event` WHERE `code` = 'ivo_marketplace_stock_sync'");
		if ($query->num_rows) {
			return;
		}

		$this->load->model('setting/event');
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_stock_sync',
			'description' => 'IVO Marketplace - Automatic stock sync',
			'trigger' => 'catalog/controller/common/footer/after',
			'action' => 'extension/ivo_marketplace/module/ivo_marketplace_stock.sync',
			'status' => 1,
			'sort_order' => 0
		]);
	}
}
