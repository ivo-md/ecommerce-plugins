<?php
namespace Opencart\Admin\Controller\Extension\IvoMarketplace\Marketplace;

/**
 * Class IvoMarketplace
 * 
 * IVO Marketplace integration for OpenCart
 * 
 * 
 * @package Opencart\Admin\Controller\Extension\IvoMarketplace\Marketplace
 */
class IvoMarketplace extends \Opencart\System\Engine\Controller {
	// Plugin version, kept in step with install.json by build.sh
	public const VERSION = '1.0.20';
	// Force Sync slices: products read, and payloads gathered, per request
	private const SYNC_SLICE_PRODUCTS = 50;
	private const SYNC_SLICE_PAYLOADS = 50;

	
	// IVO Endpoints - 
	private string $setupUrl = 'https://www.ivo.md/merchant/plugin/setup';
	private string $apiBaseUrl = 'https://a.ivo.md';
	private string $lastSyncError = '';
	private array $measureUnits = [];
	private array $activeSpecials = [];
	private ?bool $specialsInDiscounts = null;

	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);
		if ($setupUrl = getenv('IVO_SETUP_URL')) {
			$this->setupUrl = $setupUrl;
		}
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}
	
	/**
	 * Display the main configuration page
	 * 
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');

		$this->ensureDeleteEventRegistered();

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=marketplace')
		];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace', 'user_token=' . $this->session->data['user_token'])
		];

		// URLs for actions
		$data['save'] = $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=marketplace');
		
		// Check if configured (has API key)
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		$data['configured'] = (bool)$apiKey;
		$data['version'] = self::VERSION;
		$data['api_valid'] = false;
		$data['api_error'] = '';
		$data['merchant_info'] = [];
		$data['marketplace_ivo_marketplace_status'] = $this->config->get('marketplace_ivo_marketplace_status');
		$data['marketplace_ivo_marketplace_merchant_point_id'] = $this->config->get('marketplace_ivo_marketplace_merchant_point_id');		
		// Setup config values
		if (!$this->config->has('marketplace_ivo_marketplace_price_modifier')) {
			$data['marketplace_ivo_marketplace_price_modifier'] = '0';
		} else {
			$val_modifier = $this->config->get('marketplace_ivo_marketplace_price_modifier');
			$data['marketplace_ivo_marketplace_price_modifier'] = ($val_modifier === '') ? '0' : $val_modifier;
		}

		if (!$this->config->has('marketplace_ivo_marketplace_update_stock')) {
			$data['marketplace_ivo_marketplace_update_stock'] = '1';
		} else {
			$data['marketplace_ivo_marketplace_update_stock'] = $this->config->get('marketplace_ivo_marketplace_update_stock');
		}
		
		// Masked API key (show first 8 chars)
		if ($apiKey) {
			$data['api_key_masked'] = substr($apiKey, 0, 8) . '••••••••••••••••';
			
			// Check if API key is valid
			$merchantInfo = $this->checkApiKey();
			if (isset($merchantInfo['error'])) {
				$data['api_error'] = $merchantInfo['error'];
			} else {
				$data['api_valid'] = true;
				$data['merchant_info'] = $merchantInfo;
			}
		} else {
			$data['api_key_masked'] = '';
		}
		
		// URLs for buttons
		$data['configure_url'] = $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace.setup', 'user_token=' . $this->session->data['user_token']);
		$data['sync_url'] = $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace.syncAll', 'user_token=' . $this->session->data['user_token'], true);
		$locale = $this->language->get('code');
		if (strpos($locale, 'ru') === 0) {
			$data['help_guide_url'] = 'https://www.ivo.md/ru/help/merchant-integration/opencart';
		} elseif (strpos($locale, 'en') === 0) {
			$data['help_guide_url'] = 'https://www.ivo.md/en/help/merchant-integration/opencart';
		} else {
			$data['help_guide_url'] = 'https://www.ivo.md/help/merchant-integration/opencart';
		}
		
		// Fetch merchant points only if API is valid
		$data['merchant_points'] = [];
		$data['merchant_point_warning'] = '';
		if ($data['api_valid']) {
			$data['merchant_points'] = $this->fetchMerchantPoints();

			// Warning if no merchant point selected
			if (!$data['marketplace_ivo_marketplace_merchant_point_id'] && count($data['merchant_points']) > 1) {
				$data['merchant_point_warning'] = 'Please select a Merchant Point. The plugin will not sync products until a merchant point is selected.';
			}
		}
		
		// Check for callback cookies (from catalog callback)
		if (isset($_COOKIE['ivo_callback_success'])) {
			$this->session->data['success'] = $this->language->get('text_success_configured');
			setcookie('ivo_callback_success', '', time() - 3600, '/');
			// Re-check configured status since API key was just saved
			$data['configured'] = true;
			$merchantInfo = $this->checkApiKey();
			if ($merchantInfo !== false) {
				$data['api_valid'] = true;
				$data['merchant_info'] = $merchantInfo;
				$data['merchant_points'] = $this->fetchMerchantPoints();
			}
		}
		
		if (isset($_COOKIE['ivo_callback_error'])) {
			$error = $_COOKIE['ivo_callback_error'];
			if ($error === 'decrypt_failed') {
				$this->session->data['error_warning'] = $this->language->get('error_api_key_decrypt');
			} else {
				$this->session->data['error_warning'] = $this->language->get('error_no_api_key');
			}
			setcookie('ivo_callback_error', '', time() - 3600, '/');
		}
		
		// Handle success/error messages from session
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}
		
		// Language variables for template
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_select'] = $this->language->get('text_select');
		$data['text_syncing'] = $this->language->get('text_syncing');
		$data['text_please_configure'] = $this->language->get('text_please_configure');
		$data['text_merchant_name'] = $this->language->get('text_merchant_name');
		$data['text_merchant_status'] = $this->language->get('text_merchant_status');
		
		$data['entry_api_key'] = $this->language->get('entry_api_key');
		$data['entry_merchant_point'] = $this->language->get('entry_merchant_point');
		$data['entry_price_modifier'] = $this->language->get('entry_price_modifier');
		$data['entry_update_stock'] = $this->language->get('entry_update_stock');
		$data['text_price_modifier_comment'] = $this->language->get('text_price_modifier_comment');
		$data['text_update_stock_comment'] = $this->language->get('text_update_stock_comment');
		
		$data['error_api_connection'] = $this->language->get('error_api_connection');
		
		$data['button_configure'] = $this->language->get('button_configure');
		$data['button_reconfigure'] = $this->language->get('button_reconfigure');
		$data['button_force_sync'] = $this->language->get('button_force_sync');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		// Add new UI strings
		$new_ui_strings = [
			'text_opencart_bridge', 'text_connect_prompt', 'text_connect_desc', 
			'text_configure_conn', 'text_view_guide', 'text_settings', 'text_save_settings', 
			'text_reconfigure', 'text_force_sync', 'text_step_account', 'text_step_account_desc',
			'text_step_sync', 'text_step_sync_desc', 'text_step_order', 'text_step_order_desc',
			'text_badge_success', 'text_badge_required', 'text_badge_active', 'text_badge_inactive', 'text_badge_next', 
			'text_badge_ready', 'text_connected'
		];
		foreach ($new_ui_strings as $key) {
			$data[$key] = $this->language->get($key);
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/ivo_marketplace/marketplace/ivo_marketplace', $data));
	}

	public function save(): void {
		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/ivo_marketplace/marketplace/ivo_marketplace')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');
			
			// Preserve the API key
			$settings = $this->request->post;
			$settings['marketplace_ivo_marketplace_api_key'] = $this->config->get('marketplace_ivo_marketplace_api_key');
			// The form has no status field: saving it used to drop the status,
			// which silently switched off product, order and stock pushes.
			// A connected store is an enabled one.
			$settings['marketplace_ivo_marketplace_status'] = $settings['marketplace_ivo_marketplace_api_key'] ? 1 : 0;
			
			// Check if price modifier has changed			
			$old_modifier = $this->config->get('marketplace_ivo_marketplace_price_modifier');
			$new_modifier = $settings['marketplace_ivo_marketplace_price_modifier'] ?? '0';
			if ($new_modifier === '') {
				$new_modifier = '0';
			}
			
			$this->model_setting_setting->editSetting('marketplace_ivo_marketplace', $settings);

			// New prices for the whole catalogue: the page re-sends it slice by
			// slice, as Force Sync does, not inside this request
			if ((float)$old_modifier !== (float)$new_modifier) {
				$json['ivo_resync'] = true;
			}

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	/**
	 * Redirect to IVO setup page
	 */
	public function setup(): void {
		$shopUrl = HTTP_CATALOG;
		
		// Generate a security nonce and store it temporarily
		$nonce = bin2hex(random_bytes(16));
		$adminUrl = rtrim(HTTP_SERVER, '/') . '/';
		$adminLanguage = (string)($this->config->get('config_admin_language') ?: $this->config->get('config_language') ?: 'en-gb');
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_setup_nonce'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'marketplace_ivo_marketplace', `key` = 'marketplace_ivo_marketplace_setup_nonce', `value` = '" . $this->db->escape($nonce . '|' . time() . '|' . $adminUrl . '|' . $adminLanguage) . "', `serialized` = '0'");
		
		// Include nonce and user_token (as token) in callback URL to use the catalog endpoint
		$returnUrl = HTTP_CATALOG . 'index.php?route=extension/ivo_marketplace/marketplace/ivo_marketplace_callback&token=' . $this->session->data['user_token'] . '&nonce=' . $nonce;
		
		$params = [
			'url_shop' => $shopUrl,
			'url_return' => $returnUrl,
			'platform' => 'opencart',
			'version' => VERSION,
			'ip_server' => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
			'os_server' => php_uname('s')
		];
		
		$setupUrl = $this->setupUrl . '?' . http_build_query($params);
		$this->response->redirect($setupUrl);
	}
	
	/**
	 * Callback from IVO after setup
	 */
	public function callback(): void {
		// Check if user is logged in (session still valid)
		if (!$this->user->isLogged()) {
			// Store the key temporarily in session for after login
			if (isset($this->request->get['key'])) {
				$this->session->data['ivo_pending_key'] = $this->request->get['key'];
			}
			$this->response->redirect($this->url->link('common/login'));
			return;
		}

		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');
		
		if (isset($this->request->get['key'])) {
			$encryptedKey = $this->request->get['key'];
			$apiKey = $this->decryptIvoKey($encryptedKey);
			
			if ($apiKey) {
				$this->load->model('setting/setting');
				
				// Get existing settings and merge
				$existingSettings = $this->model_setting_setting->getSetting('marketplace_ivo_marketplace');
				$existingSettings['marketplace_ivo_marketplace_api_key'] = $apiKey;
				$existingSettings['marketplace_ivo_marketplace_status'] = 1;
				unset($existingSettings['marketplace_ivo_marketplace_merchant_point_id']);
				
				$this->model_setting_setting->editSetting('marketplace_ivo_marketplace', $existingSettings);
				
				$this->session->data['success'] = $this->language->get('text_success_configured');
			} else {
				$this->session->data['error_warning'] = $this->language->get('error_api_key_decrypt');
			}
		} else {
			$this->session->data['error_warning'] = $this->language->get('error_no_api_key');
		}
		
		$this->response->redirect($this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace', 'user_token=' . $this->session->data['user_token']));
	}
	
	/**
	 * Decrypt the IVO API key (base64 decode)
	 */
	private function decryptIvoKey(string $encryptedKey): string|false {
		$decoded = base64_decode($encryptedKey, true);
		return $decoded !== false ? $decoded : false;
	}
	
	/**
	 * Check if API key is valid by calling /v1/merchant-api/check
	 * Returns merchant info if valid, false if invalid
	 */
	private function checkApiKey(): array|false {
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		
		// Also try direct DB query in case config cache is stale
		if (!$apiKey) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_api_key'");
			if ($query->num_rows) {
				$apiKey = $query->row['value'];
			}
		}
		
		if (!$apiKey) {
			return ['error' => 'No API key configured'];
		}
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/check');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $apiKey,
			'Accept: application/json'
		]);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$curlError = curl_error($ch);
		curl_close($ch);
		
		$this->log->write('IVO Marketplace: API Check HTTP Code: ' . $httpCode);
		if ($curlError) {
			$this->log->write('IVO Marketplace: API Check CURL Error: ' . $curlError);
			return ['error' => 'cURL error: ' . $curlError];
		}
		
		if ($httpCode !== 200) {
			return ['error' => 'HTTP ' . $httpCode . ' - ' . substr($response, 0, 200)];
		}
		
		$data = json_decode($response, true);
		if (isset($data['merchant_id'])) {
			return $data;
		}
		
		return ['error' => 'Invalid API response: ' . substr($response, 0, 200)];
	}
	
	/**
	 * Fetch merchant points from IVO API
	 */
	private function fetchMerchantPoints(): array {
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		
		// Also try direct DB query in case config cache is stale
		if (!$apiKey) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_api_key'");
			if ($query->num_rows) {
				$apiKey = $query->row['value'];
			}
		}
		
		if (!$apiKey) {
			$this->log->write('IVO Marketplace: No API key found for fetching merchant points');
			return [];
		}
		
		$this->log->write('IVO Marketplace: Fetching merchant points with API key length: ' . strlen($apiKey));
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/merchant-points');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $apiKey,
			'Accept: application/json'
		]);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$curlError = curl_error($ch);
		curl_close($ch);
		
		$this->log->write('IVO Marketplace: HTTP Code: ' . $httpCode);
		$this->log->write('IVO Marketplace: Response: ' . substr($response, 0, 1000));
		if ($curlError) {
			$this->log->write('IVO Marketplace: CURL Error: ' . $curlError);
		}
		
		if ($httpCode === 200) {
			$data = json_decode($response, true);
			$this->log->write('IVO Marketplace: Decoded data keys: ' . implode(', ', array_keys($data ?? [])));
			// Handle different response formats: { "data": [...] }, { "points": [...] }, or direct array
			$points = $data['points'] ?? $data['data'] ?? $data ?? [];
			foreach ($points as &$point) {
				if (isset($point['_id']) && !isset($point['id'])) {
					$point['id'] = $point['_id'];
				}
				if (isset($point['id'])) {
					$point['id'] = $this->normalizeMerchantPointId($point['id']);
				}
			}
			$this->log->write('IVO Marketplace: Found ' . count($points) . ' merchant points');
			return $points;
		}
		
		return [];
	}
	
	/**
	 * Force Sync, one slice per request (see syncSlice): the page calls again
	 * with the returned `after` and `run_id` until `done`.
	 */
	public function syncAll(): void {
		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');

		$json = [];

		try {
			if (!$this->user->hasPermission('modify', 'extension/ivo_marketplace/marketplace/ivo_marketplace')) {
				$json['error'] = $this->language->get('error_permission');
			} else {
				$after = (int)($this->request->get['after'] ?? 0);
				$runId = (string)preg_replace('/[^A-Za-z0-9_]/', '', (string)($this->request->get['run_id'] ?? ''));
				// Force Sync re-imports every product; a new price modifier only re-sends them
				$reprocess = (string)($this->request->get['reprocess'] ?? '1') !== '0';
				$selectedMerchantPointId = $this->normalizeMerchantPointId($this->request->get['merchant_point_id'] ?? '');
				if ($selectedMerchantPointId !== '' && $runId === '') {
					$this->saveMerchantPointId($selectedMerchantPointId);
				}

				$slice = $this->syncSlice($after, $runId, $selectedMerchantPointId ?: null, $reprocess);
				if ($slice === null) {
					$json['error'] = $this->lastSyncError ?: $this->language->get('error_not_configured');
				} else {
					$json = $slice;
					if ($slice['done']) {
						$json['success'] = $this->language->get('text_sync_success');
					}
				}
			}
		} catch (\Throwable $e) {
			$this->log->write('IVO Marketplace Force Sync Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
			$json['error'] = 'Force sync failed: ' . $e->getMessage();
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	/**
	 * Get Merchant Point ID - 
	 */
	private function getMerchantPointId(): ?string {
		// First check config
		$configId = $this->normalizeMerchantPointId($this->config->get('marketplace_ivo_marketplace_merchant_point_id'));
		if ($configId) {
			return $configId;
		}
		
		// Fetch from API if not in config
		$points = $this->fetchMerchantPoints();

		if (count($points) === 1 && isset($points[0])) {
			return $this->normalizeMerchantPointId($points[0]['id'] ?? $points[0]['_id'] ?? null);
		}
		
		return null;
	}

	private function normalizeMerchantPointId($value): string {
		if (is_array($value)) {
			$value = $value['$oid'] ?? $value['oid'] ?? $value['id'] ?? $value['_id'] ?? '';
		}
		return trim((string)$value);
	}

	private function saveMerchantPointId(string $merchantPointId): void {
		$this->load->model('setting/setting');

		$settings = [
			'marketplace_ivo_marketplace_api_key' => $this->config->get('marketplace_ivo_marketplace_api_key'),
			'marketplace_ivo_marketplace_status' => $this->config->get('marketplace_ivo_marketplace_api_key') ? 1 : 0,
			'marketplace_ivo_marketplace_price_modifier' => $this->config->get('marketplace_ivo_marketplace_price_modifier') ?: '0',
			'marketplace_ivo_marketplace_update_stock' => $this->config->get('marketplace_ivo_marketplace_update_stock') ?: '1',
			'marketplace_ivo_marketplace_merchant_point_id' => $merchantPointId
		];

		$this->model_setting_setting->editSetting('marketplace_ivo_marketplace', $settings);
		$this->config->set('marketplace_ivo_marketplace_merchant_point_id', $merchantPointId);
	}
	
	/**
	 * The ID this product is known by on IVO. Must stay in lockstep with what
	 * full and single-product syncs send, or deletions zero the wrong offer.
	 */
	private function getMerchantInternalId(array $product): string {
		if (!empty($product['_ivo_option_variant'])) {
			return (string)($product['_ivo_variant_internal_id'] ?? $product['product_id']);
		}

		$masterId = (int)($product['master_id'] ?? 0);
		if ($masterId > 0) {
			return (string)$product['product_id'];
		}

		return (string)(($product['model'] ?? '') ?: $product['product_id']);
	}

	/**
	 * Prepare product payload for IVO API
	 * Includes: name, price, currency, availability, merchant_point_id, merchant_internal_id,
	 *           description (description + attributes), brand, category
	 */
	private function prepareProductPayload(array $product, string $merchantPointId, string $currency): array {
		$languageId = (int)$this->config->get('config_language_id');
		$masterId = (int)($product['master_id'] ?? 0);
		$isOptionVariant = !empty($product['_ivo_option_variant']);
		$variantParentId = (int)($product['_ivo_variant_parent_id'] ?? 0);
		$variantOptions = $product['_ivo_variant_options'] ?? [];
		$rawPrice = $isOptionVariant ? (float)($product['_ivo_variant_price'] ?? $product['price']) : (float)$product['price'];
		// Sold at the running special (sale) price, otherwise the regular price
		$specialPrice = $this->getSpecialPrice($product);
		$sellingPrice = $specialPrice ?? $rawPrice;
		$availability = $isOptionVariant ? (int)($product['_ivo_variant_quantity'] ?? $product['quantity']) : (int)$product['quantity'];
		$merchantInternalId = $this->getMerchantInternalId($product);
		
		// Build description: product description + attributes
		$descriptionParts = [];
		
		// Get product description
		$this->load->model('catalog/product');
		$productDescriptions = $this->model_catalog_product->getDescriptions($product['product_id']);
		if (isset($productDescriptions[$languageId]['description'])) {
			$desc = strip_tags(html_entity_decode($productDescriptions[$languageId]['description'], ENT_QUOTES, 'UTF-8'));
			if ($desc) {
				$descriptionParts[] = $desc;
			}
		}
		
		// Get product attributes
		$productAttributes = $this->model_catalog_product->getAttributes($product['product_id']);
		if (!empty($productAttributes)) {
			foreach ($productAttributes as $attributeGroup) {
				if (isset($attributeGroup['product_attribute_description'][$languageId])) {
					$attrText = $attributeGroup['product_attribute_description'][$languageId]['text'] ?? '';
					$attrName = '';
					if (!empty($attributeGroup['attribute_id'])) {
						$this->load->model('catalog/attribute');
						$attributeInfo = $this->model_catalog_attribute->getAttribute((int)$attributeGroup['attribute_id']);
						$attrName = $attributeInfo['name'] ?? '';
					}
					if ($attrName && $attrText) {
						$descriptionParts[] = $attrName . ': ' . $attrText;
					}
				} elseif (isset($attributeGroup['attribute']) && is_array($attributeGroup['attribute'])) {
					foreach ($attributeGroup['attribute'] as $attr) {
						if (is_array($attr)) {
							$attrName = $attr['name'] ?? '';
							$attrText = $attr['text'] ?? '';
							if ($attrName && $attrText) {
								$descriptionParts[] = $attrName . ': ' . $attrText;
							}
						}
					}
				} elseif (isset($attributeGroup['name'], $attributeGroup['text'])) {
					$attrName = $attributeGroup['name'] ?? '';
					$attrText = $attributeGroup['text'] ?? '';
					if ($attrName && $attrText) {
							$descriptionParts[] = $attrName . ': ' . $attrText;
					}
				}
			}
		}
		
		$description = implode("\n\n", $descriptionParts);
		
		// Get brand (manufacturer)
		$brand = '';
		if (!empty($product['manufacturer_id'])) {
			$this->load->model('catalog/manufacturer');
			$manufacturer = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
			if ($manufacturer && !empty($manufacturer['name'])) {
				$brand = $manufacturer['name'];
			}
		}
		
		// Get category (with full path)
		$category = '';
		$productCategories = $this->model_catalog_product->getCategories($product['product_id']);
		if (!empty($productCategories)) {
			$this->load->model('catalog/category');
			$categoryPaths = [];
			
			foreach ($productCategories as $productCategory) {
				$categoryId = is_array($productCategory) ? (int)($productCategory['category_id'] ?? 0) : (int)$productCategory;
				if ($categoryId <= 0) {
					continue;
				}
				$categoryInfo = $this->model_catalog_category->getCategory($categoryId);
				
				if ($categoryInfo) {
					// Build full path
					$path = $this->getCategoryPath($categoryId, $languageId);
					if ($path) {
						$categoryPaths[] = $path;
					}
				}
			}
			
			// Use the deepest category path
			if (!empty($categoryPaths)) {
				usort($categoryPaths, function($a, $b) {
					return substr_count($b, '>') - substr_count($a, '>');
				});
				$category = $categoryPaths[0];
			}
		}
		
		$payload = [
			'name' => $product['name'],
			'price' => $this->applyPriceModifier($sellingPrice),
			'currency' => $currency,
			'availability' => $availability,
			'merchant_point_id' => $merchantPointId,
			'merchant_internal_id' => $merchantInternalId
		];

		if ($isOptionVariant) {
			$payload['item_group_id'] = 'opencart-product-' . $variantParentId;
			$payload['item_group_title'] = $product['_ivo_variant_parent_name'] ?? $product['name'];
			if (!empty($variantOptions)) {
				$payload['variant_options'] = array_values($variantOptions);
				$payload['variant_option'] = implode(' / ', $variantOptions);
			}
		} elseif ($masterId > 0) {
			$payload['item_group_id'] = 'opencart-product-' . $masterId;

			$masterProduct = $this->model_catalog_product->getProduct($masterId);
			if (!empty($masterProduct['name'])) {
				$payload['item_group_title'] = $masterProduct['name'];
			}

			$productVariantOptions = $this->normalizeVariantOptions($product['variant'] ?? []);
			if (!empty($productVariantOptions)) {
				$payload['variant_options'] = $productVariantOptions;
				$payload['variant_option'] = implode(' / ', $productVariantOptions);
			}
		}
		
		// Add optional fields only if they have values
		if ($description) {
			$payload['description'] = $description;
		}
		if ($brand) {
			$payload['brand'] = $brand;
		}
		if ($category) {
			$payload['category'] = $category;
		}
		
		// Get product images
		$images = $this->getProductImages($product['product_id']);
		if (!empty($images)) {
			$payload['images'] = $images;
		}

		// While a special sells below it, the regular price goes out as the
		// recommended retail price (PRP), without the price modifier
		if ($specialPrice !== null && $rawPrice > $specialPrice) {
			$payload['retail_price'] = round($rawPrice, 2);
		}

		// Weight and package dimensions, only when set
		$payload = array_merge($payload, $this->getProductMeasures($product));
		
		return $payload;
	}

	/**
	 * Weight and package dimensions, each with its unit spelled out (IVO
	 * converts units itself). Option variants carry their own weight (parent
	 * weight adjusted by the selected option values); dimensions stay the
	 * parent's. Empty or zero values are left out, and the three dimensions
	 * are sent together or not at all.
	 */
	private function getProductMeasures(array $product): array {
		$measures = [];

		$weight = $this->formatMeasure($product['_ivo_variant_weight'] ?? $product['weight'] ?? null);
		if ($weight !== null) {
			$weightUnit = $this->getMeasureUnit('weight', (int)($product['weight_class_id'] ?? 0));
			if ($weightUnit !== '') {
				$measures['weight'] = $weight . ' ' . $weightUnit;
			}
		}

		$length = $this->formatMeasure($product['length'] ?? null);
		$width = $this->formatMeasure($product['width'] ?? null);
		$height = $this->formatMeasure($product['height'] ?? null);
		if ($length !== null && $width !== null && $height !== null) {
			$lengthUnit = $this->getMeasureUnit('length', (int)($product['length_class_id'] ?? 0));
			if ($lengthUnit !== '') {
				$measures['length'] = $length . ' ' . $lengthUnit;
				$measures['width'] = $width . ' ' . $lengthUnit;
				$measures['height'] = $height . ' ' . $lengthUnit;
			}
		}

		return $measures;
	}

	/**
	 * Positive measure as a plain decimal string; null when empty, zero or not numeric
	 */
	private function formatMeasure($value): ?string {
		if (!is_numeric($value)) {
			return null;
		}
		$value = round((float)$value, 4);
		if ($value <= 0) {
			return null;
		}
		return rtrim(rtrim(number_format($value, 4, '.', ''), '0'), '.');
	}

	/**
	 * IVO unit (kg, g, lbs, oz / mm, cm, m, in) of a weight or length class,
	 * read from the class's unit and title; '' when it is not recognised.
	 * A product without a class uses the store default.
	 */
	private function getMeasureUnit(string $type, int $classId): string {
		if ($classId <= 0) {
			$classId = (int)$this->config->get('config_' . $type . '_class_id');
		}

		if (!isset($this->measureUnits[$type][$classId])) {
			$class = [];
			if ($classId > 0) {
				if ($type === 'weight') {
					$this->load->model('localisation/weight_class');
					$class = $this->model_localisation_weight_class->getWeightClass($classId);
				} else {
					$this->load->model('localisation/length_class');
					$class = $this->model_localisation_length_class->getLengthClass($classId);
				}
			}

			$units = $type === 'weight'
				? ['kg' => 'kg', 'kgs' => 'kg', 'kilogram' => 'kg', 'kilograms' => 'kg', 'кг' => 'kg', 'килограмм' => 'kg',
					'g' => 'g', 'gr' => 'g', 'gram' => 'g', 'grams' => 'g', 'г' => 'g', 'гр' => 'g', 'грамм' => 'g',
					'lb' => 'lbs', 'lbs' => 'lbs', 'pound' => 'lbs', 'pounds' => 'lbs', 'фунт' => 'lbs',
					'oz' => 'oz', 'ounce' => 'oz', 'ounces' => 'oz', 'унция' => 'oz']
				: ['mm' => 'mm', 'millimeter' => 'mm', 'millimetre' => 'mm', 'milimetru' => 'mm', 'мм' => 'mm', 'миллиметр' => 'mm',
					'cm' => 'cm', 'centimeter' => 'cm', 'centimetre' => 'cm', 'centimetru' => 'cm', 'см' => 'cm', 'сантиметр' => 'cm',
					'm' => 'm', 'meter' => 'm', 'metre' => 'm', 'metru' => 'm', 'м' => 'm', 'метр' => 'm',
					'in' => 'in', 'inch' => 'in', 'inches' => 'in', 'дюйм' => 'in'];

			$unit = '';
			foreach ([$class['unit'] ?? '', $class['title'] ?? ''] as $name) {
				$name = mb_strtolower(trim(rtrim(trim((string)$name), '.')), 'UTF-8');
				if (isset($units[$name])) {
					$unit = $units[$name];
					break;
				}
			}
			$this->measureUnits[$type][$classId] = $unit;
		}

		return $this->measureUnits[$type][$classId];
	}

	private function normalizeVariantOptions($variant): array {
		if (is_string($variant)) {
			$decoded = json_decode($variant, true);
			$variant = is_array($decoded) ? $decoded : [$variant];
		}

		if (!is_array($variant)) {
			return [];
		}

		$options = [];
		array_walk_recursive($variant, function($value) use (&$options) {
			if (is_scalar($value)) {
				$value = trim((string)$value);
				if ($value !== '') {
					$options[] = $value;
				}
			}
		});

		return array_values(array_unique($options));
	}

	/**
	 * Apply price modifier
	 */
	private function applyPriceModifier(float $price): float {
		$modifier = (float)($this->config->get('marketplace_ivo_marketplace_price_modifier') ?? 0);
		if ($modifier === 0.0) {
			return $price;
		}
		$adjustedPrice = $price * (1 + ($modifier / 100));
		return round(max(0.0, $adjustedPrice), 2);
	}

	/**
	 * Price while a special (sale) runs for the product, or null when none
	 * does. A fixed special replaces the base price and option deltas stay on
	 * top of it; percent and subtract specials (OpenCart 4.1+) come off the
	 * option-adjusted price, the way the cart charges them.
	 */
	private function getSpecialPrice(array $product): ?float {
		$special = $this->getActiveSpecial((int)$product['product_id']);
		if ($special === null) {
			return null;
		}

		// A special at zero or below would list the product on IVO for free
		$basePrice = (float)$product['price'];
		if ($this->applySpecial($special, $basePrice, 0.0) <= 0) {
			return null;
		}

		return max(0.0, $this->applySpecial($special, $basePrice, (float)($product['_ivo_variant_price_delta'] ?? 0)));
	}

	private function applySpecial(array $special, float $basePrice, float $optionDelta): float {
		if ($special['type'] === 'P') {
			return ($basePrice + $optionDelta) * (1 - ($special['price'] / 100));
		}
		if ($special['type'] === 'S') {
			return $basePrice + $optionDelta - $special['price'];
		}
		return $special['price'] + $optionDelta;
	}

	/**
	 * The special running now for the store's default customer group, chosen
	 * the way the storefront chooses it: start/end dates open or current,
	 * lowest priority, then lowest price. OpenCart 4.1+ keeps specials in
	 * product_discount (special = 1, with a fixed/percent/subtract type), 4.0
	 * in product_special (always a fixed price).
	 */
	private function getActiveSpecial(int $productId): ?array {
		if (!array_key_exists($productId, $this->activeSpecials)) {
			if ($this->specialsInDiscounts === null) {
				$this->specialsInDiscounts = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product_discount` LIKE 'special'")->num_rows > 0;
			}

			$customerGroupId = (int)$this->config->get('config_customer_group_id');
			$running = "((`date_start` = '0000-00-00' OR `date_start` < NOW()) AND (`date_end` = '0000-00-00' OR `date_end` > NOW()))";
			if ($this->specialsInDiscounts) {
				$query = $this->db->query("SELECT `price`, `type` FROM `" . DB_PREFIX . "product_discount` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . $customerGroupId . "' AND `quantity` = '1' AND `special` = '1' AND " . $running . " ORDER BY `priority` ASC, `price` ASC LIMIT 1");
			} else {
				$query = $this->db->query("SELECT `price`, 'F' AS `type` FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . $customerGroupId . "' AND " . $running . " ORDER BY `priority` ASC, `price` ASC LIMIT 1");
			}

			$this->activeSpecials[$productId] = $query->num_rows ? ['type' => (string)$query->row['type'], 'price' => (float)$query->row['price']] : null;
		}

		return $this->activeSpecials[$productId];
	}

	/**
	 * One slice of a full sync: the next products by id after $afterProductId,
	 * expanded into the payloads IVO receives and sent as one batch.
	 *
	 * The page walks the catalogue slice by slice, so no request runs anywhere
	 * near a shop's PHP or proxy timeout (often 30 s); a whole catalogue in one
	 * request was cut off on 585.md. Every slice carries the same run id and
	 * the last one closes the run, so IVO zeroes what the run never mentioned.
	 * A failed slice stops the walk before that, so a partial run never zeroes
	 * products that merely did not arrive. Paging by product id, not offset,
	 * keeps a product added or deleted mid-run from shifting the pages and
	 * skipping a neighbour.
	 */
	private function syncSlice(int $afterProductId, string $runId, ?string $merchantPointIdOverride = null, bool $forceReprocess = false): ?array {
		$this->lastSyncError = '';
		$merchantPointId = $merchantPointIdOverride ?: $this->getMerchantPointId();
		$apiKey = (string)$this->config->get('marketplace_ivo_marketplace_api_key');
		if (!$merchantPointId || $apiKey === '') {
			$this->lastSyncError = $this->language->get('error_not_configured');
			return null;
		}

		if ($runId === '') {
			$runId = 'oc_' . time() . '_' . substr(md5(uniqid((string)random_int(0, PHP_INT_MAX), true)), 0, 12);
		}

		// The products the admin catalogue lists (getProducts reads the same)
		$languageId = (int)$this->config->get('config_language_id');
		$from = " FROM `" . DB_PREFIX . "product` `p` LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`p`.`product_id` = `pd`.`product_id`) WHERE `pd`.`language_id` = '" . $languageId . "'";
		$query = $this->db->query("SELECT *" . $from . " AND `p`.`product_id` > '" . $afterProductId . "' ORDER BY `p`.`product_id` ASC LIMIT " . self::SYNC_SLICE_PRODUCTS);

		$this->load->model('catalog/product');
		$currency = (string)$this->config->get('config_currency');
		$payloads = [];
		$after = $afterProductId;
		$consumed = 0;

		foreach ($query->rows as $product) {
			$after = (int)$product['product_id'];
			$consumed++;

			foreach ($this->expandProductForSync($product) as $item) {
				$payload = $this->prepareProductPayload($item, $merchantPointId, $currency);
				if (!$this->isValidSyncPayload($payload)) {
					$this->log->write('IVO Marketplace: Skipping invalid sync payload for product ' . ($payload['merchant_internal_id'] ?? $product['product_id']) . ' (a non-empty name and price >= 0.01 are required)');
					continue;
				}
				if ($forceReprocess) {
					$payload['force_reprocess'] = '1';
				}
				$payloads[] = $payload;
			}

			if (count($payloads) >= self::SYNC_SLICE_PAYLOADS) {
				break;
			}
		}

		// One product can have more option combinations than IVO takes in one call
		foreach (array_chunk($payloads, 100) as $batch) {
			if (!$this->syncProductBatch($batch, $apiKey, $runId)) {
				return null;
			}
		}

		$done = $consumed === count($query->rows) && count($query->rows) < self::SYNC_SLICE_PRODUCTS;
		if ($done) {
			$this->completeSyncRun($runId, $apiKey);
		}

		$position = $this->db->query("SELECT COUNT(*) AS `total`" . $from . " AND `p`.`product_id` <= '" . $after . "'");
		$total = $this->db->query("SELECT COUNT(*) AS `total`" . $from);

		return [
			'done' => $done,
			'after' => $after,
			'run_id' => $runId,
			'position' => (int)$position->row['total'],
			'total' => (int)$total->row['total'],
		];
	}

	private function isValidSyncPayload(array $payload): bool {
		return is_string($payload['name'] ?? null)
			&& trim($payload['name']) !== ''
			&& is_numeric($payload['price'] ?? null)
			&& (float)$payload['price'] >= 0.01;
	}

	/**
	 * Close a full-sync run: products IVO knows from this store that were NOT
	 * part of the run no longer exist here, so their offers go out of stock.
	 */
	private function completeSyncRun(string $runId, string $apiKey): void {
		$payload = [
			'import_name' => 'api_sync_import_opencart',
			'integration_run_id' => $runId,
		];

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/product/complete-run');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $apiKey,
			'Accept: application/json',
			'Content-Type: application/json',
		]);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($httpCode < 200 || $httpCode >= 300) {
			$this->log->write('IVO Marketplace Complete Run Failed: HTTP ' . $httpCode . ' response=' . (string)$response);
		}
	}

	/**
	 * What one catalogue product sends to IVO. A native variant goes on its own
	 * row of the walk; its master sends nothing, since each of its variants
	 * comes along on its own row. Otherwise the option combinations, or the
	 * product itself.
	 */
	private function expandProductForSync(array $product): array {
		$productId = (int)($product['product_id'] ?? 0);
		if ($productId <= 0) {
			return [];
		}

		if ((int)($product['master_id'] ?? 0) > 0) {
			return [$product];
		}

		$query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `master_id` = '" . $productId . "' LIMIT 1");
		if ($query->num_rows) {
			return [];
		}

		return $this->getOptionVariantProducts($product) ?: [$product];
	}

	private function getVariantProductsByMasterId(int $masterId): array {
		if ($masterId <= 0) {
			return [];
		}

		$query = $this->db->query("SELECT `product_id`, `variant` FROM `" . DB_PREFIX . "product` WHERE `master_id` = '" . (int)$masterId . "' ORDER BY `sort_order` ASC, `product_id` ASC");
		$variants = [];

		foreach ($query->rows as $row) {
			$product = $this->model_catalog_product->getProduct((int)$row['product_id']);
			if (!$product) {
				continue;
			}
			$product['master_id'] = $masterId;
			if (!isset($product['variant'])) {
				$product['variant'] = $row['variant'] ?? [];
			}
			$variants[] = $product;
		}

		return $variants;
	}

	private function getOptionVariantProducts(array $product): array {
		$productId = (int)($product['product_id'] ?? 0);
		if ($productId <= 0) {
			return [];
		}

		$languageId = (int)$this->config->get('config_language_id');
		$query = $this->db->query("SELECT pov.*, od.`name` AS option_name, ovd.`name` AS value_name FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "product_option` po ON (po.`product_option_id` = pov.`product_option_id`) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (od.`option_id` = pov.`option_id` AND od.`language_id` = '" . (int)$languageId . "') LEFT JOIN `" . DB_PREFIX . "option_value` ov ON (ov.`option_value_id` = pov.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value_description` ovd ON (ovd.`option_value_id` = pov.`option_value_id` AND ovd.`language_id` = '" . (int)$languageId . "') LEFT JOIN `" . DB_PREFIX . "option` o ON (o.`option_id` = pov.`option_id`) WHERE pov.`product_id` = '" . (int)$productId . "' AND o.`type` IN ('select', 'radio', 'checkbox', 'image') ORDER BY po.`product_option_id` ASC, ov.`sort_order` ASC, pov.`product_option_value_id` ASC");
		if (empty($query->rows)) {
			return [];
		}

		$groups = [];
		$stockedGroups = [];
		foreach ($query->rows as $row) {
			$groupKey = (int)$row['product_option_id'];
			$groups[$groupKey][] = $row;
			// An option keeps its own stock when OpenCart subtracts it, or when
			// the merchant fills quantities in anyway: 585.md keeps ring sizes at
			// 1 and 0 with subtract off. All zeros with subtract off is an option
			// nobody stocks, and the product's quantity stands for it.
			if ((int)$row['subtract'] === 1 || (int)$row['quantity'] > 0) {
				$stockedGroups[$groupKey] = true;
			}
		}

		$combinations = [[]];
		foreach ($groups as $values) {
			$next = [];
			foreach ($combinations as $combo) {
				foreach ($values as $value) {
					$next[] = array_merge($combo, [$value]);
				}
			}
			$combinations = $next;
		}

		$variants = [];
		foreach ($combinations as $combo) {
			$variant = $product;
			$price = (float)$product['price'];
			$weight = (float)($product['weight'] ?? 0);
			$trackedQuantities = [];
			$labels = [];
			$valueIds = [];

			foreach ($combo as $value) {
				$optionName = trim((string)($value['option_name'] ?? ''));
				$valueName = trim((string)($value['value_name'] ?? ''));
				$labels[] = trim(($optionName ? $optionName . ': ' : '') . $valueName);
				$valueIds[] = (int)$value['product_option_value_id'];

				$delta = (float)($value['price'] ?? 0);
				if (($value['price_prefix'] ?? '+') === '-') {
					$price -= $delta;
				} else {
					$price += $delta;
				}
				// Option value weight is in the product's weight class
				$weightDelta = (float)($value['weight'] ?? 0);
				if (($value['weight_prefix'] ?? '+') === '-') {
					$weight -= $weightDelta;
				} else {
					$weight += $weightDelta;
				}
				// A stocked option's quantity is this variant's, even at 0 (sold out)
				if (isset($stockedGroups[(int)$value['product_option_id']])) {
					$trackedQuantities[] = max(0, (int)($value['quantity'] ?? 0));
				}
			}

			$variant['_ivo_option_variant'] = true;
			$variant['_ivo_variant_parent_id'] = $productId;
			$variant['_ivo_variant_parent_name'] = $product['name'];
			$variant['_ivo_variant_options'] = array_values(array_filter($labels));
			$variant['_ivo_variant_price'] = max(0.0, $price);
			// The option deltas alone, for when a special replaces the base price
			$variant['_ivo_variant_price_delta'] = $price - (float)$product['price'];
			$variant['_ivo_variant_weight'] = max(0.0, $weight);
			// The variant's own stock (its scarcest stocked option value) when any
			// of its options is stocked; otherwise the product's.
			$variant['_ivo_variant_quantity'] = !empty($trackedQuantities) ? min($trackedQuantities) : (int)$product['quantity'];
			$variant['_ivo_variant_internal_id'] = $productId . '-' . implode('-', $valueIds);
			if (!empty($variant['_ivo_variant_options'])) {
				$variant['name'] = $product['name'] . ' - ' . implode(' / ', $variant['_ivo_variant_options']);
			}

			$variants[] = $variant;
		}

		return $variants;
	}

	private function syncProductBatch(array $productsPayload, string $apiKey, ?string $integrationRunId = null): bool {
		$result = $this->syncProducts($productsPayload, $apiKey, 'async', $integrationRunId);
		$code = (int)($result['code'] ?? 0);
		if ($code >= 200 && $code < 300) {
			return true;
		}

		$response = $result['response'] ?? [];
		$message = is_array($response) ? ($response['message'] ?? $response['error'] ?? '') : '';
		$this->lastSyncError = $message ? sprintf($this->language->get('error_sync_failed'), $code) . ' ' . $message : sprintf($this->language->get('error_sync_failed'), $code);
		$this->log->write('IVO Marketplace Sync Batch Failed: HTTP ' . $code . ' response=' . json_encode($response));
		return false;
	}
	
	/**
	 * Get product images (main + additional)
	 * Returns array of full image URLs
	 */
	private function getProductImages(int $productId): array {
		$images = [];
		
		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);
		
		// Main image
		if (!empty($product['image'])) {
			$images[] = $this->getImageUrl($product['image']);
		}
		
		// Additional images
		$productImages = $this->model_catalog_product->getImages($productId);
		foreach ($productImages as $productImage) {
			if (!empty($productImage['image'])) {
				$url = $this->getImageUrl($productImage['image']);
				if ($url && !in_array($url, $images)) {
					$images[] = $url;
				}
			}
		}
		
		return $images;
	}
	
	/**
	 * Get full URL for an image path
	 */
	private function getImageUrl(string $imagePath): string {
		if (empty($imagePath) || $imagePath === 'no_image.png') {
			return '';
		}
		
		// Build the catalog image URL
		$baseUrl = $this->config->get('config_url') ?: HTTP_CATALOG;
		return rtrim($baseUrl, '/') . '/image/' . $imagePath;
	}
	
	/**
	 * Get full category path (Parent > Child > Grandchild)
	 */
	private function getCategoryPath(int $categoryId, int $languageId): string {
		$this->load->model('catalog/category');
		
		$path = [];
		$currentId = $categoryId;
		
		// Walk up the category tree (max 10 levels to prevent infinite loops)
		for ($i = 0; $i < 10 && $currentId > 0; $i++) {
			$category = $this->model_catalog_category->getCategory($currentId);
			if (!$category) {
				break;
			}
			
			// Get category name for this language
			$descriptions = $this->model_catalog_category->getDescriptions($currentId);
			$name = $descriptions[$languageId]['name'] ?? $category['name'] ?? '';
			
			if ($name) {
				array_unshift($path, $name);
			}
			
			$currentId = (int)($category['parent_id'] ?? 0);
		}
		
		return implode(' > ', $path);
	}
	
	/**
	 * Send products to IVO API - 
	 */
	private function syncProducts(array $productsData, string $apiKey, string $mode = 'async', ?string $integrationRunId = null): array {
		// EXACT payload from Magento Config.php syncProducts()
		$payload = [
			'mode' => $mode,
			'import_name' => 'api_sync_import_opencart',  // Similar to Magento's "api_sync_import_magento"
			'products' => $productsData
		];
		if ($integrationRunId) {
			$payload['integration_run_id'] = $integrationRunId;
		}
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $apiKey,
			'Accept: application/json',
			'Content-Type: application/json'
		]);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		// EXACT return format from Magento
		return ['code' => $httpCode, 'response' => json_decode($response, true)];
	}
	
	/**
	 * Get product IVO status (for product edit page tab)
	 * 
	 */
	public function getProductStatus(): void {
		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');
		
		$json = [];
		
		$productId = $this->request->get['product_id'] ?? null;
		
		if (!$productId) {
			$json['error'] = 'Product ID required';
		} else {
			$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
			
			if (!$apiKey) {
				// EXACT: "Not configured."
				$json['error'] = $this->language->get('text_not_configured');
			} else {
				// Get product model/SKU
				$this->load->model('catalog/product');
				$product = $this->model_catalog_product->getProduct($productId);
				
				if ($product) {
					$sku = $product['model'] ?: (string)$productId;
					
					$ivoData = $this->getProductInfoFromIvo($sku, $apiKey);
					
					// API response format:
					// Success: { status: "success", product: {...}, offer: {...} }
					// Error: { status: "error", message: "code" }
					if ($ivoData && isset($ivoData['status']) && $ivoData['status'] === 'success' && isset($ivoData['product'])) {
						// Success - offer found
						$json['status'] = 'success';
						$json['name'] = $ivoData['product']['name'] ?? [];
						$json['urls'] = $ivoData['product']['urls'] ?? [];
						$json['url'] = $ivoData['product']['url'] ?? '';
					} else if ($ivoData && isset($ivoData['status']) && $ivoData['status'] === 'error' && isset($ivoData['message'])) {
						// Error status with message code from API
						$json['status'] = 'error';
						$json['message'] = $ivoData['message'];
					} else {
						// No response or invalid response - treat as not imported
						$json['status'] = 'error';
						$json['message'] = 'not_imported';
					}
				} else {
					$json['error'] = 'Product not found';
				}
			}
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	/**
	 * Sync a single product to IVO (from product edit page)
	 */
	public function syncProduct(): void {
		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');
		
		$json = [];
		
		$productId = $this->request->get['product_id'] ?? null;
		
		if (!$productId) {
			$json['error'] = 'Product ID required';
		} else if (!$this->user->hasPermission('modify', 'extension/ivo_marketplace/marketplace/ivo_marketplace')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
			$merchantPointId = $this->getMerchantPointId();
			
			if (!$apiKey || !$merchantPointId) {
				$json['error'] = $this->language->get('error_not_configured');
			} else {
				$this->load->model('catalog/product');
				$product = $this->model_catalog_product->getProduct($productId);
				
			if ($product) {
				$currency = $this->config->get('config_currency');
					
				if ((float)$product['price'] < 0.01) {
					$json['error'] = $this->language->get('error_no_price');
				} else {
					$productsData = [];
					foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
						$productsData[] = $this->prepareProductPayload($syncProduct, $merchantPointId, $currency);
					}
						
					$result = $this->syncProducts($productsData, $apiKey);
						
						if ($result['code'] >= 200 && $result['code'] < 300) {
							$json['success'] = $this->language->get('text_product_synced');
						} else {
							$json['error'] = sprintf($this->language->get('error_sync_failed'), $result['code']);
						}
					}
				} else {
					$json['error'] = 'Product not found';
				}
			}
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function getProductAndVariantsForSync(array $product): array {
		$productId = (int)($product['product_id'] ?? 0);
		$masterId = (int)($product['master_id'] ?? 0);
		$parentId = $masterId > 0 ? $masterId : $productId;

		if ($parentId > 0) {
			$variants = $this->getVariantProductsByMasterId($parentId);
			if (empty($variants)) {
				$parent = $this->model_catalog_product->getProduct($parentId);
				if ($parent) {
					$variants = $this->getOptionVariantProducts($parent);
				}
			}
			if (!empty($variants)) {
				return $variants;
			}
		}

		return $productId > 0 ? [$product] : [];
	}
	
	/**
	 * Get product info from IVO by SKU
	 * 
	 */
	private function getProductInfoFromIvo(string $sku, string $apiKey): ?array {
		// EXACT payload from Magento Config.php getProductIvoInfo()
		$payload = [
			'import_name' => 'api_sync_import_opencart',  // Similar to Magento's "api_sync_import_magento"
			'merchant_internal_id' => $sku
		];
		
		$url = $this->apiBaseUrl . '/v1/merchant-api/product/info-by-sku';
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $apiKey,
			'Accept: application/json',
			'Content-Type: application/json'
		]);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		// Always return response (even on non-200) to show real API errors to user
		if ($response) {
			return json_decode($response, true);
		}
		
		return null;
	}
	
	/**
	 * Install the module - register events and permissions
	 */
	public function install(): void {
		// Add permissions for this extension
		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/ivo_marketplace/marketplace/ivo_marketplace');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/ivo_marketplace/marketplace/ivo_marketplace');
		
		$this->load->model('setting/event');
		
		// Event for adding menu item
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_menu',
			'description' => 'IVO Marketplace - Add menu item',
			'trigger' => 'admin/view/common/column_left/before',
			'action' => 'extension/ivo_marketplace/startup/ivo_marketplace',
			'status' => 1,
			'sort_order' => 0
		]);
		
		// Event for product save (auto sync)
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_product_save',
			'description' => 'IVO Marketplace - Sync product on save',
			'trigger' => 'admin/model/catalog/product/editProduct/after',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace.eventProductSave',
			'status' => 1,
			'sort_order' => 1
		]);
		
		// Event for product add (auto sync on create)
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_product_add',
			'description' => 'IVO Marketplace - Sync product on create',
			'trigger' => 'admin/model/catalog/product/addProduct/after',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace.eventProductAdd',
			'status' => 1,
			'sort_order' => 1
		]);
		
		// Event for showing notification on all pages
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_admin_notification',
			'description' => 'IVO Marketplace - Show configuration notification',
			'trigger' => 'admin/view/common/header/after',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace.eventAdminNotification',
			'status' => 1,
			'sort_order' => 0
		]);
		
		// Event for product edit page tab - use /after to modify output
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_product_tab',
			'description' => 'IVO Marketplace - Product edit page tab',
			'trigger' => 'admin/view/catalog/product_form/after',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace.eventProductTab',
			'status' => 1,
			'sort_order' => 1
		]);
		
		// Event for order completion (sync stock to IVO) -
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_order_complete',
			'description' => 'IVO Marketplace - Sync stock on order',
			'trigger' => 'catalog/model/checkout/order/addOrder/after',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace_order.eventOrderComplete',
			'status' => 1,
			'sort_order' => 1
		]);

		// Event for product delete (zero stock on IVO) - /before, so the
		// product and its variants can still be read for their internal IDs
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_product_delete',
			'description' => 'IVO Marketplace - Zero stock on product delete',
			'trigger' => 'admin/model/catalog/product/deleteProduct/before',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace.eventProductDelete',
			'status' => 1,
			'sort_order' => 1
		]);
	}

	/**
	 * Installs added after the first release miss events that install() has
	 * since learned to register. Re-check on the settings page so an upgraded
	 * extension heals itself without a reinstall.
	 */
	private function ensureDeleteEventRegistered(): void {
		$query = $this->db->query("SELECT `event_id` FROM `" . DB_PREFIX . "event` WHERE `code` = 'ivo_marketplace_product_delete'");
		if ($query->num_rows) {
			return;
		}

		$this->load->model('setting/event');
		$this->model_setting_event->addEvent([
			'code' => 'ivo_marketplace_product_delete',
			'description' => 'IVO Marketplace - Zero stock on product delete',
			'trigger' => 'admin/model/catalog/product/deleteProduct/before',
			'action' => 'extension/ivo_marketplace/marketplace/ivo_marketplace.eventProductDelete',
			'status' => 1,
			'sort_order' => 1
		]);
	}
	
	/**
	 * Uninstall the module - remove events
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');
		
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_menu');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_save');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_add');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_admin_notification');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_tab');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_order_complete');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_delete');
	}
	
	/**
	 * Event: Sync product when created
	 */
	public function eventProductAdd(string &$route, array &$args, mixed &$output): void {
		// Check if module is enabled and configured
		if (!$this->config->get('marketplace_ivo_marketplace_status')) {
			return;
		}
		
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		$merchantPointId = $this->getMerchantPointId();
		
		if (!$apiKey || !$merchantPointId) {
			return;
		}
		
		// For addProduct/after, the new product ID is in $output (return value)
		$productId = $output ?? null;
		if (!$productId) {
			return;
		}
		
		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);
		
		if (!$product) {
			return;
		}
		
		$currency = $this->config->get('config_currency');

		// Expand variants (native master variants or option combinations) so the
		// product is synced as a main product + variants group, not as a single
		// stand-alone product.
		$productsData = [];
		foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
			$productsData[] = $this->prepareProductPayload($syncProduct, $merchantPointId, $currency);
		}

		if (empty($productsData)) {
			return;
		}

		$this->syncProducts($productsData, $apiKey);
	}
	
	/**
	 * Event: Sync product when saved
	 */
	public function eventProductSave(string &$route, array &$args, mixed &$output): void {
		// Check if module is enabled and configured
		if (!$this->config->get('marketplace_ivo_marketplace_status')) {
			return;
		}
		
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		$merchantPointId = $this->getMerchantPointId();
		
		if (!$apiKey || !$merchantPointId) {
			return;
		}
		
		$productId = $args[0] ?? null;
		if (!$productId) {
			return;
		}
		
		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);
		
		if (!$product) {
			return;
		}
		
		$currency = $this->config->get('config_currency');

		// Expand variants (native master variants or option combinations) so the
		// product is synced as a main product + variants group, not as a single
		// stand-alone product.
		$productsData = [];
		foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
			$productsData[] = $this->prepareProductPayload($syncProduct, $merchantPointId, $currency);
		}

		if (empty($productsData)) {
			return;
		}

		$this->syncProducts($productsData, $apiKey);
	}
	
	/**
	 * Event: Zero stock on IVO when a product is deleted.
	 *
	 * Fires on deleteProduct/BEFORE: the product and its variants are still
	 * readable, so their merchant internal IDs can be collected. The push is
	 * availability-only — the server updates rows and offers it already
	 * knows and never creates anything from it.
	 */
	public function eventProductDelete(string &$route, array &$args, mixed &$output): void {
		if (!$this->config->get('marketplace_ivo_marketplace_status')) {
			return;
		}

		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		$merchantPointId = $this->getMerchantPointId();

		if (!$apiKey || !$merchantPointId) {
			return;
		}

		$productId = (int)($args[0] ?? 0);
		if ($productId <= 0) {
			return;
		}

		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);

		if (!$product) {
			return;
		}

		$internalIds = [];
		if ((int)($product['master_id'] ?? 0) > 0) {
			// A variant deleted on its own zeroes only itself — expanding to
			// its group would zero siblings that still exist.
			$internalIds[] = $this->getMerchantInternalId($product);
		} else {
			// A deleted master takes its whole synced group down with it.
			foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
				$internalIds[] = $this->getMerchantInternalId($syncProduct);
			}
			$internalIds[] = $this->getMerchantInternalId($product);
		}

		$productsData = [];
		foreach (array_unique(array_filter($internalIds)) as $internalId) {
			$productsData[] = [
				'availability_only' => true,
				'availability' => 0,
				'merchant_internal_id' => $internalId,
				'merchant_point_id' => $merchantPointId,
			];
		}

		if (empty($productsData)) {
			return;
		}

		$this->syncProducts($productsData, $apiKey);
	}

	/**
	 * Event: Show notification on admin pages if not configured
	 *
	 */
	public function eventAdminNotification(string &$route, array &$args, mixed &$output): void {
		// Skip if on IVO Marketplace config page
		if (isset($this->request->get['route']) && strpos($this->request->get['route'], 'ivo_marketplace') !== false) {
			return;
		}
		
		// Skip AJAX requests
		if (!empty($this->request->server['HTTP_X_REQUESTED_WITH']) && 
			strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			return;
		}
		
		// Check if module is installed
		$this->load->model('setting/extension');
		
		$extensions = $this->model_setting_extension->getExtensionsByType('module');
		$installed = false;
		
		foreach ($extensions as $extension) {
			if ($extension['code'] == 'ivo_marketplace') {
				$installed = true;
				break;
			}
		}
		
		if (!$installed) {
			return;
		}
		
		// Check if configured (has API key)
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		
		if (!$apiKey) {
			$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');
			
			$configureUrl = $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace', 'user_token=' . $this->session->data['user_token']);
			$message = $this->language->get('text_please_configure');
			$configureText = $this->language->get('button_configure');
			
			// Inject warning notification via JavaScript to place it at top of #content
			$notification = '
			<script>
			document.addEventListener("DOMContentLoaded", function() {
				var content = document.getElementById("content");
				if (content) {
					var alert = document.createElement("div");
					alert.className = "alert alert-warning alert-dismissible";
					alert.style.margin = "15px";
					alert.style.marginBottom = "0";
					alert.innerHTML = \'<i class="fa-solid fa-exclamation-triangle"></i> <strong>IVO Marketplace:</strong> ' . addslashes($message) . ' <a href="' . $configureUrl . '" class="alert-link">' . $configureText . '</a> <button type="button" class="btn-close" data-bs-dismiss="alert"></button>\';
					content.insertBefore(alert, content.firstChild);
				}
			});
			</script>';
			
			// Append script after the header output
			$output = $output . $notification;
		}
	}
	
	/**
	 * Event: Add IVO tab to product edit page
	 * Injects tab HTML directly into the product form output
	 */
	public function eventProductTab(string &$route, array &$args, mixed &$output): void {
		// Only show on edit (when product_id exists)
		if (!isset($this->request->get['product_id'])) {
			return;
		}
		
		// Check if configured
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}
		
		$this->load->language('extension/ivo_marketplace/marketplace/ivo_marketplace');
		
		$productId = $this->request->get['product_id'];
		$statusUrl = $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace.getProductStatus', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $productId, true);
		$syncUrl = $this->url->link('extension/ivo_marketplace/marketplace/ivo_marketplace.syncProduct', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $productId, true);
		
		// Language strings
		$tabTitle = $this->language->get('tab_ivo_marketplace');
		$textLoading = $this->language->get('text_loading');
		$textActive = $this->language->get('text_status_active');
		$textInactive = $this->language->get('text_status_inactive');
		$textDraft = $this->language->get('text_status_draft');
		$textNotSynced = $this->language->get('text_not_synced');
		$textViewOnIvo = $this->language->get('text_view_on_ivo');
		$textProductHidden = $this->language->get('text_product_hidden');
		$textProductPending = $this->language->get('text_product_pending');
		$textProductVisible = $this->language->get('text_product_visible');
		$textProductAvailable = $this->language->get('text_product_available');
		$textConnectionError = $this->language->get('text_connection_error');
		$textErrorFetching = $this->language->get('text_error_fetching');
		$textProductSynced = $this->language->get('text_product_synced');
		$buttonForceSync = $this->language->get('button_force_sync');
		$textSyncing = $this->language->get('text_syncing');
		
		// Tab link HTML - insert before closing </ul> of main nav-tabs
		$tabLink = '<li class="nav-item"><a href="#tab-ivo" data-bs-toggle="tab" class="nav-link"><i class="fa-solid fa-shopping-cart"></i> ' . $tabTitle . '</a></li>';
		
		// Tab content HTML - 
		$tabContent = '
		<div id="tab-ivo" class="tab-pane">
			<div class="row">
				<div class="col-12">
					<div id="ivo-status-container" style="padding: 15px; background: #f8f8f8; border: 1px solid #d1d1d1; border-radius: 5px;">
						<div id="ivo-loading" class="text-center py-4">
							<i class="fa-solid fa-spinner fa-spin fa-2x"></i>
							<p class="mt-2">' . $textLoading . '</p>
						</div>
						<div id="ivo-status-content" style="display:none;">
							<h3 id="ivo-status-header" style="margin-top:0"></h3>
							<p id="ivo-status-description"></p>
							<div id="ivo-extra-info" style="display:none;">
								<ul id="ivo-info-list" style="padding-left: 20px; margin-bottom: 0;"></ul>
							</div>
							<div id="ivo-view-btn-container" style="display:none; margin-top:15px;">
								<a id="ivo-product-url" href="#" target="_blank" style="
									background-color: #eb5202;
									color: white;
									padding: 10px 20px;
									text-decoration: none;
									border-radius: 3px;
									font-weight: bold;
									display: inline-block;
								">' . $textViewOnIvo . '</a>
							</div>
						</div>
						<div id="ivo-error" class="alert alert-danger" style="display:none;"></div>
						<div style="margin-top: 15px; padding-top: 10px; border-top: 1px dashed #ccc;">
							<button type="button" id="btn-ivo-sync" class="btn btn-default">
								<i class="fa-solid fa-sync"></i> ' . $buttonForceSync . '
							</button>
							<span id="ivo-sync-status" style="margin-left: 10px; font-weight: bold;"></span>
						</div>
					</div>
				</div>
			</div>
		</div>';
		
		// JavaScript - New simplified API format
		$script = '
		<script>
		document.addEventListener("DOMContentLoaded", function() {
			var statusUrl = "' . $statusUrl . '";
			var syncUrl = "' . $syncUrl . '";
			
			// Message descriptions for error statuses
			var messageDescriptions = {
				"not_imported": "' . $this->language->get('text_not_imported') . '",
				"queued": "' . $this->language->get('text_queued') . '",
				"processing": "' . $this->language->get('text_processing') . '",
				"pending_approval": "' . $this->language->get('text_pending_approval') . '",
				"import_error": "' . $this->language->get('text_import_error') . '",
				"skipped_no_match": "' . $this->language->get('text_too_generic') . '",
				"too_generic": "' . $this->language->get('text_too_generic') . '",
				"unauthorized_category": "' . $this->language->get('text_not_authorized') . '",
				"offer_deleted": "' . $this->language->get('text_offer_deleted') . '",
				"offer_not_found": "' . $this->language->get('text_not_synced') . '"
			};
			
			// Load IVO status when tab is shown
			var ivoTab = document.querySelector(\'a[href="#tab-ivo"]\');
			var loaded = false;
			
			if (ivoTab) {
				ivoTab.addEventListener("shown.bs.tab", function() {
					if (!loaded) {
						loadIvoStatus();
						loaded = true;
					}
				});
			}
			
			function loadIvoStatus() {
				$.ajax({
					url: statusUrl,
					type: "GET",
					dataType: "json",
					success: function(json) {
						document.getElementById("ivo-loading").style.display = "none";
						
						if (json.error) {
							document.getElementById("ivo-error").innerHTML = json.error;
							document.getElementById("ivo-error").style.display = "block";
							document.getElementById("ivo-status-content").style.display = "block";
							return;
						}
						
						document.getElementById("ivo-status-content").style.display = "block";
						
						var header = document.getElementById("ivo-status-header");
						var desc = document.getElementById("ivo-status-description");
						var viewBtnContainer = document.getElementById("ivo-view-btn-container");
						var productUrl = document.getElementById("ivo-product-url");
						
						if (json.status === "success") {
							// Success - offer found, show Active status
							var color = "#28a745";
							header.innerHTML = "' . $this->language->get('text_status') . ': <span style=\"font-weight:bold; color: " + color + ";\">' . $this->language->get('text_status_active') . '</span>";
							desc.innerHTML = "' . $textProductVisible . '";
							
							// Show View Product button with language preference
							var targetUrl = null;
							var btnText = "' . $textViewOnIvo . '";
							var lang = "' . substr($this->config->get('config_admin_language'), 0, 2) . '";
							
							if (json.urls && json.urls[lang]) {
								targetUrl = json.urls[lang];
								btnText += " (" + lang.toUpperCase() + ")";
							} else if (json.urls && json.urls["en"]) {
								targetUrl = json.urls["en"];
								btnText += " (EN)";
							} else if (json.url) {
								targetUrl = json.url;
							}
							
							if (targetUrl) {
								productUrl.href = targetUrl;
								productUrl.innerHTML = btnText;
								viewBtnContainer.style.display = "block";
							}
						} else {
							// Error status - show appropriate message
							var message = json.message || "unknown";
							var color = "#dc3545"; // Red for errors
							var statusLabel = "' . $this->language->get('text_status_error') . '";
							
							// Determine color and label based on message type
							if (message === "queued" || message === "processing" || message === "pending_approval") {
								color = "#ffc107"; // Yellow for pending
								statusLabel = "' . $this->language->get('text_status_pending') . '";
							} else if (message === "not_imported") {
								color = "#6c757d"; // Gray for not synced
								statusLabel = "' . $this->language->get('text_status_not_synced') . '";
							}
							
							header.innerHTML = "' . $this->language->get('text_status') . ': <span style=\"font-weight:bold; color: " + color + ";\">" + statusLabel + "</span>";
							
							if (messageDescriptions[message]) {
								desc.innerHTML = messageDescriptions[message];
							} else {
								desc.innerHTML = "' . $this->language->get('text_unknown_status') . ': " + message;
							}
						}
					},
					error: function() {
						document.getElementById("ivo-loading").style.display = "none";
						document.getElementById("ivo-error").innerHTML = "' . $textConnectionError . '";
						document.getElementById("ivo-error").style.display = "block";
					}
				});
			}
			
			// Force sync button
			var btnSync = document.getElementById("btn-ivo-sync");
			if (btnSync) {
				btnSync.addEventListener("click", function() {
					btnSync.disabled = true;
					btnSync.innerHTML = \'<i class="fa-solid fa-spinner fa-spin"></i> ' . $textSyncing . '\';
					document.getElementById("ivo-sync-status").innerHTML = "";
					
					$.ajax({
						url: syncUrl,
						type: "GET",
						dataType: "json",
						success: function(json) {
							btnSync.disabled = false;
							btnSync.innerHTML = \'<i class="fa-solid fa-sync"></i> ' . $buttonForceSync . '\';
							
							if (json.success) {
								document.getElementById("ivo-sync-status").innerHTML = \'<span class="text-success"><i class="fa-solid fa-check"></i> \' + json.success + \'</span>\';
								// IVO processes sync asynchronously — wait before re-checking status
								document.getElementById("ivo-sync-status").innerHTML += \' <span style="color:#666;">' . $this->language->get('text_refreshing_status') . '</span>\';
								setTimeout(function() {
									loaded = false;
									document.getElementById("ivo-loading").style.display = "block";
									document.getElementById("ivo-status-content").style.display = "none";
									loadIvoStatus();
									loaded = true;
									document.getElementById("ivo-sync-status").innerHTML = "";
								}, 5000);
							} else if (json.error) {
								document.getElementById("ivo-sync-status").innerHTML = \'<span class="text-danger"><i class="fa-solid fa-times"></i> \' + json.error + \'</span>\';
							}
						},
						error: function() {
							btnSync.disabled = false;
							btnSync.innerHTML = \'<i class="fa-solid fa-sync"></i> ' . $buttonForceSync . '\';
							document.getElementById("ivo-sync-status").innerHTML = \'<span class="text-danger"><i class="fa-solid fa-times"></i> ' . $textConnectionError . '</span>\';
						}
					});
				});
			}
		});
		</script>';
		
		// Inject tab link before </ul> of first nav-tabs (main tabs)
		$output = preg_replace(
			'/(<ul class="nav nav-tabs">.*?<\/li>)(\s*<\/ul>)/s',
			'$1' . $tabLink . '$2',
			$output,
			1
		);
		
		// Inject tab content inside the tab-content div
		// Find the closing </div> of tab-report section (after </fieldset></div>) and insert our tab before the </div> that closes tab-content
		$output = preg_replace(
			'/(<div id="tab-report" class="tab-pane">.*?<\/fieldset>\s*<\/div>)(\s*<\/div>)/s',
			'$1' . $tabContent . '$2',
			$output,
			1
		);
		
		// Inject script before </body> or at the end
		if (strpos($output, '</body>') !== false) {
			$output = str_replace('</body>', $script . '</body>', $output);
		} else {
			$output .= $script;
		}
	}
}
