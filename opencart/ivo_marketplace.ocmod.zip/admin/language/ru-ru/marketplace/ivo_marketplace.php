<?php
// Heading
$_['heading_title']    = 'IVO Marketplace';


// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Настройки IVO Marketplace были изменены!';
$_['text_edit']        = 'Редактирование IVO Marketplace';
$_['text_home']        = 'Главная';
$_['text_select']      = '--- Выберите ---';
$_['text_enabled']     = 'Включено';
$_['text_disabled']    = 'Отключено';
$_['text_configured']  = 'Настроен';
$_['text_not_configured'] = 'Не настроено.';
$_['text_syncing']     = 'Синхронизация...';
$_['text_sync_success'] = 'Синхронизация товаров успешно начата.';
$_['text_success_configured'] = 'IVO Marketplace успешно настроен!';
$_['text_please_configure'] = 'IVO Marketplace установлен, но не настроен. Пожалуйста, настройте его, чтобы начать продавать на IVO.';
$_['text_loading']     = 'Загрузка...';

// UI Strings
$_['text_opencart_bridge'] = 'Коннектор OpenCart';
$_['text_connect_prompt']  = 'Подключите магазин к IVO.md.';
$_['text_connect_desc']    = 'Авторизуйте аккаунт маркетплейса, выберите данные для синхронизации, и OpenCart будет работать вместе с IVO.';
$_['text_configure_conn']  = 'Настроить подключение';
$_['text_view_guide']      = 'Открыть руководство';
$_['text_settings']        = 'Настройки';
$_['text_save_settings']   = 'Сохранить настройки';
$_['text_reconfigure']     = 'Перенастроить';
$_['text_force_sync']      = 'Принудительная синхронизация';

// Setup Steps
$_['text_step_account']    = 'Доступ к аккаунту';
$_['text_step_account_desc'] = 'Добавьте ключ API IVO и идентификатор продавца.';
$_['text_step_sync']       = 'Синхронизация товаров';
$_['text_step_sync_desc']  = 'Сопоставьте категории, цены, наличие и изображения.';
$_['text_step_order']      = 'Обновление наличия';
$_['text_step_order_desc'] = 'Автоматически синхронизируйте наличие между магазином и IVO.';

// Badges
$_['text_badge_success']   = 'Успешно';
$_['text_badge_required']  = 'Обязательно';
$_['text_badge_active']    = 'Активно';
$_['text_badge_inactive']  = 'Неактивно';
$_['text_badge_next']      = 'Далее';
$_['text_badge_ready']     = 'Готово';
$_['text_connected']       = 'Подключено';

// IVO Status messages
$_['text_status']          = 'Статус IVO';
$_['text_status_active']   = 'Активный';
$_['text_status_inactive'] = 'Неактивный';
$_['text_status_draft']    = 'Черновик';
$_['text_status_unknown']  = 'Неизвестный';
$_['text_status_error']    = 'Ошибка';
$_['text_status_pending']  = 'В ожидании';
$_['text_status_not_synced'] = 'Не синхронизирован';
$_['text_not_synced']      = 'Товар не найден на торговой площадке.';
$_['text_view_on_ivo']     = 'Посмотреть товар';
$_['text_product_hidden']  = 'Товар скрыт или отключен.';
$_['text_product_pending'] = 'Товар находится в процессе создания или проверки.';
$_['text_product_available'] = 'Товар доступен на IVO.';
$_['text_product_visible'] = 'Товар виден и доступен для покупки.';
$_['text_connection_error'] = 'Ошибка соединения.';
$_['text_error_fetching']  = 'Ошибка получения статуса.';
$_['text_product_synced']  = 'Товар успешно синхронизирован!';
$_['text_unknown_status']  = 'Неизвестный статус';
$_['text_refreshing_status'] = 'Обновление статуса...';

// New simplified message codes
$_['text_not_imported']    = 'Товар еще не синхронизирован с IVO.';
$_['text_queued']          = 'Товар в очереди на обработку.';
$_['text_processing']      = 'Товар в процессе обработки.';
$_['text_pending_approval'] = 'Товар создан, но ожидает одобрения.';
$_['text_import_error']    = 'Произошла ошибка при импорте.';
$_['text_offer_deleted']   = 'Предложение было удалено с торговой площадки.';

// Offer Status messages
$_['text_offer_status']    = 'Статус предложения';
$_['text_note']            = 'Примечание';
$_['text_detail']          = 'Детали';
$_['text_reason']          = 'Причина';
$_['text_no_variants']     = 'Варианты для этого продукта не найдены.';
$_['text_too_generic']     = 'Детали продукта слишком общие для точной идентификации товара.';
$_['text_not_authorized']  = 'Продавец не авторизован для этой категории товаров.';
$_['text_offer_created']   = 'Предложение успешно создано для продукта/варианта.';
$_['text_offer_error']     = 'Произошла ошибка при создании предложения.';
$_['text_offer_pending']   = 'Найден существующий продукт, создание предложения в ожидании.';

// Entry
$_['entry_status']         = 'Статус';
$_['entry_api_key']        = 'Ключ API';
$_['entry_merchant_point'] = 'Точка продаж';
$_['entry_price_modifier'] = 'Модификатор цены (%)';
$_['text_price_modifier_comment'] = 'Автоматически изменяйте цены товаров, отправляемых в IVO (например, 10 для увеличения на 10%, или -5 для уменьшения на 5%). Введите 0, чтобы оставить без изменений.';
$_['entry_update_stock']          = 'Обновлять наличие при продаже';
$_['text_update_stock_comment']   = 'Автоматически обновлять наличие в OpenCart при продаже на IVO.';

// Tab
$_['tab_ivo_marketplace']  = 'IVO Marketplace';

// Button
$_['button_configure']     = 'Настроить';
$_['button_reconfigure']   = 'Перенастроить';
$_['button_force_sync']    = 'Принудительная синхронизация с IVO';
$_['button_save']          = 'Сохранить';
$_['button_cancel']        = 'Отмена';

// Error
$_['error_permission']     = 'Предупреждение: У вас нет прав для изменения IVO Marketplace!';
$_['error_not_configured'] = 'Не удалось получить ID торговой точки. Проверьте настройку ключа API.';
$_['error_no_api_key']     = 'Ключ API не получен от IVO.';
$_['error_api_key_decrypt'] = 'Не удалось обработать ключ API от IVO.';
$_['error_payload']        = 'Не удалось подготовить данные или отсутствует ID торговой точки';
$_['error_sync_failed']    = 'Синхронизация не удалась. Код API: %s';
$_['error_no_price']       = 'Продукт не может быть синхронизирован. Убедитесь, что у него есть действительная цена.';
