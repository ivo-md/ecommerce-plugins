<?php
// Heading
$_['heading_title']    = 'IVO Marketplace';


// Text
$_['text_extension']   = 'Extensii';
$_['text_success']     = 'Succes: Setările IVO Marketplace au fost modificate!';
$_['text_edit']        = 'Editare IVO Marketplace';
$_['text_home']        = 'Acasă';
$_['text_select']      = '--- Selectați ---';
$_['text_enabled']     = 'Activat';
$_['text_disabled']    = 'Dezactivat';
$_['text_configured']  = 'Configurat';
$_['text_not_configured'] = 'Nu este configurat.';
$_['text_syncing']     = 'Se sincronizează...';
$_['text_sync_success'] = 'Sincronizarea produselor a început cu succes.';
$_['text_success_configured'] = 'IVO Marketplace configurat cu succes!';
$_['text_please_configure'] = 'IVO Marketplace este instalat dar nu este configurat. Vă rugăm să îl configurați pentru a începe să vindeți pe IVO.';
$_['text_loading']     = 'Se încarcă...';

// UI Strings
$_['text_opencart_bridge'] = 'Conector OpenCart';
$_['text_connect_prompt']  = 'Conectați magazinul la IVO.md.';
$_['text_connect_desc']    = 'Autorizați contul marketplace, alegeți ce se sincronizează și lăsați OpenCart și IVO să lucreze împreună.';
$_['text_configure_conn']  = 'Configurează conexiunea';
$_['text_view_guide']      = 'Vezi ghidul de configurare';
$_['text_settings']        = 'Setări';
$_['text_save_settings']   = 'Salvează setările';
$_['text_reconfigure']     = 'Reconfigurează';
$_['text_force_sync']      = 'Sincronizare forțată';

// Setup Steps
$_['text_step_account']    = 'Acces cont';
$_['text_step_account_desc'] = 'Adăugați cheia API IVO și identificatorul comerciantului.';
$_['text_step_sync']       = 'Sincronizare produse';
$_['text_step_sync_desc']  = 'Mapează categoriile, prețurile, stocurile și imaginile.';
$_['text_step_order']      = 'Actualizare stoc';
$_['text_step_order_desc'] = 'Sincronizează automat stocurile între magazin și IVO.';

// Badges
$_['text_badge_success']   = 'Succes';
$_['text_badge_required']  = 'Necesar';
$_['text_badge_active']    = 'Activ';
$_['text_badge_inactive']  = 'Inactiv';
$_['text_badge_next']      = 'Următorul';
$_['text_badge_ready']     = 'Pregătit';
$_['text_connected']       = 'Conectat';

// IVO Status messages
$_['text_status']          = 'Stare IVO';
$_['text_status_active']   = 'Activ';
$_['text_status_inactive'] = 'Inactiv';
$_['text_status_draft']    = 'Schiță';
$_['text_status_unknown']  = 'Necunoscut';
$_['text_status_error']    = 'Eroare';
$_['text_status_pending']  = 'În așteptare';
$_['text_status_not_synced'] = 'Nesincronizat';
$_['text_not_synced']      = 'Produsul nu a fost găsit în marketplace.';
$_['text_view_on_ivo']     = 'Vezi produsul';
$_['text_product_hidden']  = 'Produsul este ascuns sau dezactivat.';
$_['text_product_pending'] = 'Produsul este în curs de creare sau revizuire.';
$_['text_product_available'] = 'Produsul este disponibil pe IVO.';
$_['text_product_visible'] = 'Produsul este vizibil și poate fi cumpărat.';
$_['text_connection_error'] = 'Eroare de conexiune.';
$_['text_error_fetching']  = 'Eroare la preluarea stării.';
$_['text_product_synced']  = 'Produs sincronizat cu succes!';
$_['text_unknown_status']  = 'Stare necunoscută';
$_['text_refreshing_status'] = 'Se actualizează starea...';

// New simplified message codes
$_['text_not_imported']    = 'Produsul nu a fost încă sincronizat cu IVO.';
$_['text_queued']          = 'Produsul este în coada de procesare.';
$_['text_processing']      = 'Produsul este în curs de procesare.';
$_['text_pending_approval'] = 'Produs creat, dar încă în așteptarea aprobării.';
$_['text_import_error']    = 'A apărut o eroare în timpul importului.';
$_['text_offer_deleted']   = 'Oferta a fost ștearsă din marketplace.';

// Offer Status messages
$_['text_offer_status']    = 'Stare ofertă';
$_['text_note']            = 'Notă';
$_['text_detail']          = 'Detaliu';
$_['text_reason']          = 'Motiv';
$_['text_no_variants']     = 'Nu au fost găsite variante pentru acest produs.';
$_['text_too_generic']     = 'Detaliile produsului sunt prea generice pentru a identifica cu exactitate articolul.';
$_['text_not_authorized']  = 'Comerciantul nu este autorizat pentru categoria produsului.';
$_['text_offer_created']   = 'Oferta a fost creată cu succes pentru produs/variantă.';
$_['text_offer_error']     = 'A apărut o eroare în timpul creării ofertei.';
$_['text_offer_pending']   = 'Produs existent găsit, crearea ofertei este în așteptare.';

// Entry
$_['entry_status']         = 'Status';
$_['entry_api_key']        = 'Cheie API';
$_['entry_merchant_point'] = 'Punct de Vânzare';
$_['entry_price_modifier'] = 'Modificator de preț (%)';
$_['text_price_modifier_comment'] = 'Ajustează automat prețurile produselor trimise către IVO (ex. 10 pentru o creștere de 10%, sau -5 pentru o reducere de 5%). 0 pentru nicio modificare.';
$_['entry_update_stock']          = 'Actualizează stocul la vânzare';
$_['text_update_stock_comment']   = 'Actualizează automat stocul OpenCart atunci când are loc o vânzare pe IVO.';

// Tab
$_['tab_ivo_marketplace']  = 'IVO Marketplace';

// Button
$_['button_configure']     = 'Configurează';
$_['button_reconfigure']   = 'Reconfigurează';
$_['button_force_sync']    = 'Sincronizează forțat cu IVO';
$_['button_save']          = 'Salvează';
$_['button_cancel']        = 'Anulează';

// Error
$_['error_permission']     = 'Atenție: Nu aveți permisiunea de a modifica IVO Marketplace!';
$_['error_not_configured'] = 'Nu s-a putut obține ID-ul Punctului de Vânzare. Verificați configurația cheii API.';
$_['error_no_api_key']     = 'Nu s-a primit nicio cheie API de la IVO.';
$_['error_api_key_decrypt'] = 'Nu s-a putut procesa cheia API de la IVO.';
$_['error_payload']        = 'Nu s-a putut pregăti încărcarea sau ID-ul punctului comercial lipsește';
$_['error_sync_failed']    = 'Sincronizarea a eșuat. Cod API: %s';
$_['error_no_price']       = 'Produsul nu poate fi sincronizat. Asigurați-vă că are un preț valid.';
