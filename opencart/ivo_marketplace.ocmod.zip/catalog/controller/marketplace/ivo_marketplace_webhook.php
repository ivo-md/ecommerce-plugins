<?php
/**
 * IVO Marketplace - Inbound Stock Webhook
 *
 * Endpoint: /index.php?route=extension/ivo_marketplace/marketplace/ivo_marketplace_webhook|stock
 *           (admin redirects rewrite this; SEO-URL friendly aliases may also be added)
 *
 * Auth:    Authorization: Bearer <api_key>     (matches marketplace_ivo_marketplace_api_key)
 * Body:    { "products": [ { "merchant_internal_id": "SKU-or-ID", "availability": 5 }, ... ] }
 *
 * Triggered when a sale on IVO occurs, so the merchant's local OpenCart stock stays in sync.
 */
namespace Opencart\Catalog\Controller\Extension\IvoMarketplace\Marketplace;

class IvoMarketplaceWebhook extends \Opencart\System\Engine\Controller {

	/**
	 * POST /index.php?route=extension/ivo_marketplace/marketplace/ivo_marketplace_webhook|stock
	 */
	public function stock(): void {
		$this->response->addHeader('Content-Type: application/json');

		// Module must be enabled
		if (!$this->config->get('marketplace_ivo_marketplace_status')) {
			$this->respond(503, ['success' => false, 'error' => 'Module disabled']);
			return;
		}

		// Auth
		$expected = (string)$this->config->get('marketplace_ivo_marketplace_api_key');
		$bearer = $this->extractBearerToken();
		if ($expected === '' || $bearer === '' || !hash_equals($expected, $bearer)) {
			$this->respond(401, ['success' => false, 'error' => 'Unauthorized']);
			return;
		}

		// Body
		$raw = file_get_contents('php://input');
		$data = json_decode($raw, true);
		if (!is_array($data) || empty($data['products']) || !is_array($data['products'])) {
			$this->respond(400, ['success' => false, 'error' => 'Invalid payload: expected { products: [...] }']);
			return;
		}

		$updated = [];
		$errors = [];

		foreach ($data['products'] as $item) {
			$ref = isset($item['merchant_internal_id']) ? (string)$item['merchant_internal_id'] : '';
			if ($ref === '' || !array_key_exists('availability', $item)) {
				$errors[] = ['merchant_internal_id' => $ref, 'error' => 'Missing merchant_internal_id or availability'];
				continue;
			}
			$delta = (int)$item['availability'];

			$productId = $this->resolveProductId($ref);
			if (!$productId) {
				$errors[] = ['merchant_internal_id' => $ref, 'error' => 'Product not found'];
				continue;
			}
			
			// Get current stock
			$current_query = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$productId . "'");
			$current_stock = $current_query->num_rows ? (int)$current_query->row['quantity'] : 0;
			
			// Calculate new stock
			$new_stock = max(0, $current_stock + $delta);

			// Check if stock update is enabled (default to 1 if not set)
			$update_stock = $this->config->has('marketplace_ivo_marketplace_update_stock') 
				? $this->config->get('marketplace_ivo_marketplace_update_stock') 
				: '1';
				
			if ($update_stock !== '1') {
				// Simply acknowledge the webhook without modifying the quantity
				$updated[] = ['merchant_internal_id' => $ref, 'availability' => $new_stock, 'note' => 'Skipped (stock sync disabled)'];
				continue;
			}

			try {
				$this->db->query(
					"UPDATE `" . DB_PREFIX . "product` SET `quantity` = '" . (int)$new_stock . "' WHERE `product_id` = '" . (int)$productId . "'"
				);
				$updated[] = ['merchant_internal_id' => $ref, 'availability' => $new_stock];
			} catch (\Throwable $e) {
				$errors[] = ['merchant_internal_id' => $ref, 'error' => $e->getMessage()];
			}
		}

		$this->respond(200, [
			'success' => empty($errors),
			'updated' => $updated,
			'errors'  => $errors,
		]);
	}

	/**
	 * merchant_internal_id is product 'model' (SKU) when present, else product_id.
	 */
	private function resolveProductId(string $ref): ?int {
		// Try by model (SKU) first
		$escaped = $this->db->escape($ref);
		$query = $this->db->query(
			"SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `model` = '" . $escaped . "' OR `sku` = '" . $escaped . "' LIMIT 1"
		);
		if ($query->num_rows) {
			return (int)$query->row['product_id'];
		}

		// Fall back to numeric product_id
		if (ctype_digit($ref)) {
			$query = $this->db->query(
				"SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$ref . "' LIMIT 1"
			);
			if ($query->num_rows) {
				return (int)$query->row['product_id'];
			}
		}

		return null;
	}

	private function extractBearerToken(): string {
		$header = '';
		if (function_exists('apache_request_headers')) {
			$headers = apache_request_headers();
			foreach ($headers as $k => $v) {
				if (strcasecmp($k, 'Authorization') === 0) { $header = $v; break; }
			}
		}
		if ($header === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) {
			$header = $_SERVER['HTTP_AUTHORIZATION'];
		}
		if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
			$header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
		}
		if ($header === '') {
			return '';
		}
		if (stripos($header, 'Bearer ') === 0) {
			return trim(substr($header, 7));
		}
		return trim($header);
	}

	private function respond(int $status, array $payload): void {
		http_response_code($status);
		$this->response->setOutput(json_encode($payload));
	}
}
