<?php
namespace Opencart\Catalog\Controller\Extension\IvoMarketplace\Marketplace;

/**
 * Class IvoMarketplaceCallback
 * 
 * Frontend callback handler for IVO OAuth.
 * Standalone page with security protection against unauthorized access.
 */
class IvoMarketplaceCallback extends \Opencart\System\Engine\Controller {
	
	public function index(): void {
		$apiKey = $this->request->get['key'] ?? '';
		$nonce = $this->request->get['nonce'] ?? '';
		$userToken = $this->request->get['token'] ?? '';
		
		$success = false;
		$error = '';
		$syncUrl = '';
		// What the page says about the merchant point: ready, failed or choose
		$pointStatus = 'choose';
		
		// Security: Verify the nonce
		$storedNonce = '';
		$storedTime = 0;
		$storedAdminUrl = '';
		$storedLanguage = '';
		
		$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_setup_nonce'");
		if ($query->num_rows) {
			$parts = explode('|', $query->row['value']);
			$storedNonce = $parts[0] ?? '';
			$storedTime = (int)($parts[1] ?? 0);
			$storedAdminUrl = $parts[2] ?? '';
			$storedLanguage = $parts[3] ?? '';
		}
		$text = $this->getCallbackText($storedLanguage);
		
		// Delete the nonce immediately (one-time use)
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_setup_nonce'");
		
		// Validate security
		if (empty($nonce) || empty($storedNonce)) {
			$error = $text['error_missing_token'];
		} elseif (!hash_equals($storedNonce, $nonce)) {
			$error = $text['error_token_mismatch'];
		} elseif (time() - $storedTime > 600) { // 10 minutes expiry
			$error = $text['error_expired'];
		} elseif (empty($apiKey)) {
			$error = $text['error_api_key'];
		} else {
			// Decode the API key
			$decodedKey = base64_decode($apiKey, true);
			if ($decodedKey === false) {
				$decodedKey = $apiKey; // Use as-is if not base64
			}
			
			// Save API key to database
			$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_api_key'");
			$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'marketplace_ivo_marketplace', `key` = 'marketplace_ivo_marketplace_api_key', `value` = '" . $this->db->escape($decodedKey) . "', `serialized` = '0'");
			
			// Enable the module
			$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_status'");
			$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'marketplace_ivo_marketplace', `key` = 'marketplace_ivo_marketplace_status', `value` = '1', `serialized` = '0'");

			// Keep the point already chosen: deleting it on every setup stopped every
			// push until the merchant chose it again. Choose one only when none is
			// saved and IVO lists exactly one.
			$pointQuery = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_merchant_point_id'");
			$savedPointId = $pointQuery->num_rows ? trim((string)$pointQuery->row['value']) : '';
			if ($savedPointId !== '') {
				$pointStatus = 'ready';
			} else {
				$points = $this->fetchMerchantPoints($decodedKey);
				if ($points === null || count($points) === 0) {
					$pointStatus = 'failed';
				} elseif (count($points) === 1) {
					$pointId = $this->pointId($points[0]);
					if ($pointId !== '') {
						$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'marketplace_ivo_marketplace' AND `key` = 'marketplace_ivo_marketplace_merchant_point_id'");
						$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'marketplace_ivo_marketplace', `key` = 'marketplace_ivo_marketplace_merchant_point_id', `value` = '" . $this->db->escape($pointId) . "', `serialized` = '0'");
						$pointStatus = 'ready';
					}
				}
			}
			
			$success = true;
		}
		
		// Build admin URL with user_token. The admin directory may be renamed, so
		// use the admin base URL captured when setup was started.
		$adminBaseUrl = $storedAdminUrl ?: (HTTP_SERVER . 'admin/');
		$adminLink = rtrim($adminBaseUrl, '/') . '/index.php?route=extension/ivo_marketplace/marketplace/ivo_marketplace';
		if (!empty($userToken)) {
			$adminLink .= '&user_token=' . rawurlencode($userToken);
		}

		// Output standalone HTML page (no store templates)
		$this->outputStandalonePage($success, $error, $adminLink, $syncUrl, $text, $pointStatus);
	}
	
	private function outputStandalonePage(bool $success, string $error, string $adminLink, string $syncUrl, array $text, string $pointStatus = 'choose'): void {
		$title = $success ? $text['success_title'] : $text['failed_title'];
		$message = $success 
			? $text['success_message']
			: $error;
		$iconColor = $success ? '#28a745' : '#dc3545';
		$icon = $success 
			? '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $iconColor . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>'
			: '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $iconColor . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';
		$lang = htmlspecialchars($text['lang'], ENT_QUOTES, 'UTF-8');
		$titleEscaped = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
		$messageEscaped = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
		$adminLinkEscaped = htmlspecialchars($adminLink, ENT_QUOTES, 'UTF-8');
		$buttonEscaped = htmlspecialchars($text['admin_button'], ENT_QUOTES, 'UTF-8');
		if (!$success) {
			$syncStatus = '';
		} elseif ($syncUrl !== '') {
			$syncStatus = $text['syncing'];
		} elseif ($pointStatus === 'ready') {
			$syncStatus = $text['point_ready'];
		} elseif ($pointStatus === 'failed') {
			$syncStatus = $text['point_failed'];
		} else {
			$syncStatus = $text['select_point'];
		}
		$syncStatusEscaped = htmlspecialchars($syncStatus, ENT_QUOTES, 'UTF-8');
		$syncUrlJson = json_encode($syncUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		$syncingJson = json_encode($text['syncing'], JSON_UNESCAPED_UNICODE);
		$syncSuccessJson = json_encode($text['sync_success'], JSON_UNESCAPED_UNICODE);
		$syncFailedJson = json_encode($text['sync_failed'], JSON_UNESCAPED_UNICODE);
		
		$html = <<<HTML
<!DOCTYPE html>
<html lang="{$lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVO Marketplace - {$titleEscaped}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #123cd1 0%, #ff3385 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px;
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .icon { margin-bottom: 24px; }
        .sync-status {
            color: #6c757d;
            font-size: 14px;
            line-height: 1.5;
            min-height: 22px;
            margin: -16px 0 28px;
        }
        .sync-status.success { color: #16813a; }
        .sync-status.error { color: #b42318; }
        h1 {
            color: #1a1a2e;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 32px;
        }
        .btn {
            display: inline-block;
            background: #123cd1;
            color: white;
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(18, 60, 209, 0.4);
        }
        .logo {
            margin-bottom: 32px;
            font-size: 28px;
            font-weight: 700;
            color: #123cd1;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">IVO Marketplace</div>
        <div class="icon">{$icon}</div>
        <h1>{$titleEscaped}</h1>
        <p>{$messageEscaped}</p>
        <div id="sync-status" class="sync-status">{$syncStatusEscaped}</div>
        <a href="{$adminLinkEscaped}" class="btn">{$buttonEscaped}</a>
    </div>
    <script>
        (function () {
            var syncUrl = {$syncUrlJson};
            var status = document.getElementById('sync-status');
            if (!syncUrl || !status) {
                return;
            }

            status.textContent = {$syncingJson};
            fetch(syncUrl, { credentials: 'include' })
                .then(function (response) { return response.json(); })
                .then(function (data) {
                    if (data && data.success) {
                        status.className = 'sync-status success';
                        status.textContent = {$syncSuccessJson};
                    } else {
                        status.className = 'sync-status error';
                        status.textContent = (data && data.error) ? data.error : {$syncFailedJson};
                    }
                })
                .catch(function () {
                    status.className = 'sync-status error';
                    status.textContent = {$syncFailedJson};
                });
        })();
    </script>
</body>
</html>
HTML;

		$this->response->setOutput($html);
	}

	/**
	 * The merchant's points as IVO lists them, or null when IVO could not be
	 * asked or did not answer with a list (the reason goes to the log; the
	 * admin settings page shows it to the merchant)
	 */
	private function fetchMerchantPoints(string $apiKey): ?array {
		$apiUrl = getenv('IVO_API_URL') ?: 'https://a.ivo.md';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, rtrim($apiUrl, '/') . '/v1/merchant-api/merchant-points');
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $apiKey, 'Accept: application/json']);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 15);
		$response = curl_exec($ch);
		$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$curlError = curl_error($ch);
		curl_close($ch);

		$data = ($httpCode === 200) ? json_decode((string)$response, true) : null;
		if (!is_array($data)) {
			$this->log->write('IVO Marketplace: setup could not list the merchant points: HTTP ' . $httpCode . ($curlError ? ' (' . $curlError . ')' : '') . ', response: ' . substr((string)$response, 0, 500));
			return null;
		}

		$points = $data['points'] ?? $data['data'] ?? $data;
		return is_array($points) ? array_values(array_filter($points, 'is_array')) : [];
	}

	/**
	 * A point's id as IVO sends it: id, _id, or a Mongo {"$oid": ...}
	 */
	private function pointId(array $point): string {
		$id = $point['id'] ?? $point['_id'] ?? '';
		if (is_array($id)) {
			$id = $id['$oid'] ?? $id['oid'] ?? '';
		}
		return trim((string)$id);
	}

	private function getCallbackText(string $locale): array {
		$locale = strtolower($locale ?: (string)($this->config->get('config_admin_language') ?: $this->config->get('config_language') ?: 'en-gb'));
		if (strpos($locale, 'ro') === 0) {
			return [
				'lang' => 'ro',
				'success_title' => 'Configurare reusita',
				'failed_title' => 'Configurare esuata',
				'success_message' => 'Cheia API IVO Marketplace a fost configurata cu succes.',
				'admin_button' => 'Mergi la panoul de administrare',
				'syncing' => 'Sincronizarea produselor a pornit...',
				'sync_success' => 'Sincronizarea produselor a fost pornita cu succes.',
				'sync_failed' => 'Sincronizarea nu a putut fi pornita automat.',
				'select_point' => 'Selectati un Merchant Point in panoul de administrare, apoi folositi Force Sync.',
				'point_ready' => 'Merchant Point este setat. Folositi Force Sync in panoul de administrare pentru a trimite produsele.',
				'point_failed' => 'Punctele comerciale nu au putut fi incarcate de la IVO. Deschideti panoul de administrare pentru a vedea motivul.',
				'error_missing_token' => 'Cerere invalida: lipseste tokenul de securitate.',
				'error_token_mismatch' => 'Cerere invalida: tokenul de securitate nu corespunde.',
				'error_expired' => 'Cererea a expirat. Porniti din nou procesul de configurare.',
				'error_api_key' => 'Cheia API este obligatorie.'
			];
		}
		if (strpos($locale, 'ru') === 0) {
			return [
				'lang' => 'ru',
				'success_title' => 'Настройка завершена',
				'failed_title' => 'Ошибка настройки',
				'success_message' => 'API-ключ IVO Marketplace успешно настроен.',
				'admin_button' => 'Перейти в панель администратора',
				'syncing' => 'Синхронизация товаров запущена...',
				'sync_success' => 'Синхронизация товаров успешно запущена.',
				'sync_failed' => 'Не удалось запустить синхронизацию автоматически.',
				'select_point' => 'Выберите Merchant Point в панели администратора, затем нажмите Force Sync.',
				'point_ready' => 'Merchant Point выбран. Нажмите Force Sync в панели администратора, чтобы отправить товары.',
				'point_failed' => 'Не удалось загрузить торговые точки из IVO. Откройте панель администратора, чтобы увидеть причину.',
				'error_missing_token' => 'Некорректный запрос: отсутствует токен безопасности.',
				'error_token_mismatch' => 'Некорректный запрос: токен безопасности не совпадает.',
				'error_expired' => 'Срок действия запроса истек. Запустите настройку заново.',
				'error_api_key' => 'API-ключ обязателен.'
			];
		}
		return [
			'lang' => 'en',
			'success_title' => 'Configuration Successful',
			'failed_title' => 'Configuration Failed',
			'success_message' => 'Your IVO Marketplace API key has been successfully configured.',
			'admin_button' => 'Go to Admin Panel',
			'syncing' => 'Product synchronization is starting...',
			'sync_success' => 'Product synchronization started successfully.',
			'sync_failed' => 'Synchronization could not be started automatically.',
			'select_point' => 'Select a Merchant Point in Admin, then use Force Sync.',
			'point_ready' => 'Merchant Point is set. Use Force Sync in Admin to send your products.',
			'point_failed' => 'The merchant points could not be loaded from IVO. Open Admin to see why.',
			'error_missing_token' => 'Invalid request: missing security token.',
			'error_token_mismatch' => 'Invalid request: security token mismatch.',
			'error_expired' => 'Request expired. Please start the setup process again.',
			'error_api_key' => 'API key is required.'
		];
	}
}
