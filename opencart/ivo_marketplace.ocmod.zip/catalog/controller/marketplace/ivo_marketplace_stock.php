<?php
namespace Opencart\Catalog\Controller\Extension\IvoMarketplace\Marketplace;

/**
 * IVO Marketplace - Automatic stock sync (OpenCart 4)
 *
 * Stock changed outside the product form (an import, a quick-edit tool, an
 * ERP writing to the database) fires no OpenCart event, so the plugin never
 * heard of it: 585.md's ring sizes kept their July stock on IVO after the
 * shop's own system set them to 0. OpenCart's scheduler needs a server cron
 * most shops never set up, so the shop's own traffic drives a stock-only walk of the whole catalogue instead:
 * at most once a minute, after the visitor's page has been sent, the next
 * SLICE_PRODUCTS products go to IVO as availability_only items, the same
 * numbers the full sync sends.
 *
 * Registered on: catalog/controller/common/footer/after
 */
class IvoMarketplaceStock extends \Opencart\System\Engine\Controller {

	// Sent to IVO with every call; build.sh keeps it equal to the admin controller's
	public const VERSION = '1.0.27';

	private const SLICE_PRODUCTS = 200;
	private const INTERVAL_SECONDS = 60;

	// Kept apart from marketplace_ivo_marketplace: saving the plugin settings
	// rewrites that whole code and would restart the walk every time
	private const SETTING_CODE = 'ivo_marketplace_stock';

	private string $apiBaseUrl = 'https://a.ivo.md';
	private static bool $scheduled = false;

	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}

	/**
	 * Event: claim the next slice and run it once the page is out
	 */
	public function sync(string &$route, array &$args, mixed &$output): void {
		if (self::$scheduled) {
			return;
		}

		$apiKey = (string)$this->config->get('marketplace_ivo_marketplace_api_key');
		$merchantPointId = (string)$this->config->get('marketplace_ivo_marketplace_merchant_point_id');
		if ($apiKey === '' || $merchantPointId === '') {
			return;
		}

		if (!$this->claimSlot()) {
			return;
		}

		self::$scheduled = true;
		register_shutdown_function([$this, 'runSlice'], $apiKey, $merchantPointId);
	}

	public function runSlice(string $apiKey, string $merchantPointId): void {
		// The visitor's page goes first
		if (function_exists('litespeed_finish_request')) {
			litespeed_finish_request();
		} elseif (function_exists('fastcgi_finish_request')) {
			fastcgi_finish_request();
		}
		ignore_user_abort(true);
		@set_time_limit(120);

		try {
			$after = (int)$this->getValue('ivo_marketplace_stock_after');
			$query = $this->db->query("SELECT `product_id`, `model`, `quantity`, `status` FROM `" . DB_PREFIX . "product` WHERE `product_id` > '" . $after . "' ORDER BY `product_id` ASC LIMIT " . (int)self::SLICE_PRODUCTS);

			foreach (array_chunk($this->stockItems($query->rows, $merchantPointId), 100) as $batch) {
				$result = $this->syncProducts($batch, $apiKey);
				if ($result['code'] < 200 || $result['code'] >= 300) {
					// The same slice is tried again next time
					$this->log->write('IVO Marketplace stock sync: HTTP ' . $result['code'] . ($result['error'] ? ' (' . $result['error'] . ')' : '') . ' for ' . count($batch) . ' item(s) after product ' . $after . ' response=' . substr((string)$result['body'], 0, 500));
					return;
				}
			}

			// A short page is the end of the catalogue: start over
			$last = end($query->rows);
			$this->setValue('ivo_marketplace_stock_after', count($query->rows) < self::SLICE_PRODUCTS ? 0 : (int)$last['product_id']);
		} catch (\Throwable $e) {
			$this->log->write('IVO Marketplace stock sync error: ' . $e->getMessage());
		}
	}

	/**
	 * Stock of these products as the full sync computes it: each size of a
	 * product with options under its own id, and nothing for sale once the
	 * product is disabled or sold out.
	 */
	private function stockItems(array $products, string $merchantPointId): array {
		if (!$products) {
			return [];
		}

		$productIds = [];
		foreach ($products as $product) {
			$productIds[] = (int)$product['product_id'];
		}

		// Same option values, in the same order, as getOptionVariantProducts
		$query = $this->db->query("SELECT pov.`product_id`, pov.`product_option_id`, pov.`product_option_value_id`, pov.`quantity` FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "product_option` po ON (po.`product_option_id` = pov.`product_option_id`) LEFT JOIN `" . DB_PREFIX . "option_value` ov ON (ov.`option_value_id` = pov.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option` o ON (o.`option_id` = pov.`option_id`) WHERE pov.`product_id` IN (" . implode(',', $productIds) . ") AND o.`type` IN ('select', 'radio', 'checkbox', 'image') ORDER BY pov.`product_id` ASC, po.`product_option_id` ASC, ov.`sort_order` ASC, pov.`product_option_value_id` ASC");

		$options = [];
		foreach ($query->rows as $row) {
			$options[(int)$row['product_id']][(int)$row['product_option_id']][] = $row;
		}

		$items = [];
		foreach ($products as $product) {
			$productId = (int)$product['product_id'];
			$quantity = (int)$product['status'] ? max(0, (int)$product['quantity']) : 0;

			if (empty($options[$productId])) {
				$items[] = $this->availabilityItem($product['model'] ? $product['model'] : (string)$productId, $quantity, $merchantPointId);
				continue;
			}

			$combinations = [[]];
			foreach ($options[$productId] as $values) {
				$next = [];
				foreach ($combinations as $combo) {
					foreach ($values as $value) {
						$next[] = array_merge($combo, [$value]);
					}
				}
				$combinations = $next;
			}

			foreach ($combinations as $combo) {
				$ids = [];
				$quantities = [];
				foreach ($combo as $value) {
					$ids[] = (int)$value['product_option_value_id'];
					$quantities[] = max(0, (int)$value['quantity']);
				}
				$items[] = $this->availabilityItem($productId . '-' . implode('-', $ids), $quantity > 0 ? min($quantities) : 0, $merchantPointId);
			}
		}

		return $items;
	}

	private function availabilityItem(string $merchantInternalId, int $availability, string $merchantPointId): array {
		return [
			'merchant_internal_id' => (string)$merchantInternalId,
			'merchant_point_id' => $merchantPointId,
			'availability' => (int)$availability,
			'availability_only' => true
		];
	}

	/**
	 * One visitor a minute runs a slice: the update only matches while the
	 * slot is still due, so concurrent requests cannot both claim it.
	 */
	private function claimSlot(): bool {
		$now = time();
		$where = "`store_id` = '0' AND `code` = '" . self::SETTING_CODE . "' AND `key` = 'ivo_marketplace_stock_next'";

		$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE " . $where);
		if (!$query->num_rows) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = '" . self::SETTING_CODE . "', `key` = 'ivo_marketplace_stock_next', `value` = '" . ($now + self::INTERVAL_SECONDS) . "', `serialized` = '0'");
			return true;
		}

		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '" . ($now + self::INTERVAL_SECONDS) . "' WHERE " . $where . " AND CAST(`value` AS UNSIGNED) <= " . $now);

		return $this->db->countAffected() > 0;
	}

	private function getValue(string $key): ?string {
		$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `code` = '" . self::SETTING_CODE . "' AND `key` = '" . $this->db->escape($key) . "'");
		return $query->num_rows ? $query->row['value'] : null;
	}

	private function setValue(string $key, $value): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `code` = '" . self::SETTING_CODE . "' AND `key` = '" . $this->db->escape($key) . "'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = '" . self::SETTING_CODE . "', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape((string)$value) . "', `serialized` = '0'");
	}

	private function syncProducts(array $products, string $apiKey): array {
		$payload = [
			'mode' => 'async',
			'import_name' => 'api_sync_import_opencart',
			'products' => $products
		];

		$ch = curl_init();
		curl_setopt_array($ch, [
			CURLOPT_URL => $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple',
			CURLOPT_HTTPHEADER => [
				'Authorization: Bearer ' . $apiKey,
				'X-IVO-Plugin: opencart/' . self::VERSION,
				'Accept: application/json',
				'Content-Type: application/json'
			],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($payload),
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_CONNECTTIMEOUT => 10,
			CURLOPT_TIMEOUT => 60
		]);

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$error = curl_error($ch);
		curl_close($ch);

		return ['code' => (int)$httpCode, 'body' => $response, 'error' => $error];
	}
}
