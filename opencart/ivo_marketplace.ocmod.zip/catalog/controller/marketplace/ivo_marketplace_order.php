<?php
/**
 * IVO Marketplace - Order Event Handler
 * 
 * 
 * Syncs product stock to IVO when an order is placed
 */
namespace Opencart\Catalog\Controller\Extension\IvoMarketplace\Marketplace;

class IvoMarketplaceOrder extends \Opencart\System\Engine\Controller {
	
	private string $apiBaseUrl = 'https://a.ivo.md';

	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}
	
	/**
	 * Event: Sync product stock when order is placed
	 * 
	 */
	public function eventOrderComplete(string &$route, array &$args, mixed &$output): void {
		// Check if module is enabled
		if (!$this->config->get('marketplace_ivo_marketplace_status')) {
			return;
		}
		
		$apiKey = $this->config->get('marketplace_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}
		
		$merchantPointId = $this->getMerchantPointId();
		if (!$merchantPointId) {
			return;
		}
		
		// $output contains the order_id from addOrder
		$orderId = $output;
		if (!$orderId) {
			return;
		}
		
		// Load order products
		$this->load->model('checkout/order');
		$orderProducts = $this->model_checkout_order->getProducts($orderId);
		
		if (empty($orderProducts)) {
			return;
		}
		
		// Get currency
		$currency = $this->config->get('config_currency');
		
		// Track processed product IDs to avoid duplicates (like Magento)
		$processedIds = [];
		$productsPayload = [];
		
		$this->load->model('catalog/product');
		
		foreach ($orderProducts as $orderProduct) {
			$productId = $orderProduct['product_id'];
			
			// Avoid processing same product twice (EXACT: like Magento processedSkus)
			if (in_array($productId, $processedIds)) {
				continue;
			}
			$processedIds[] = $productId;
			
			// Get current product data with updated stock
			$product = $this->model_catalog_product->getProduct($productId);
			
			if (!$product) {
				continue;
			}
			
			// EXACT payload from Magento OrderPlaceObserver
			$productsPayload[] = [
				'name' => $product['name'],
				'price' => (float)$product['price'],
				'currency' => $currency,
				'availability' => (int)$product['quantity'],  // Current stock after order
				'merchant_point_id' => $merchantPointId,
				'merchant_internal_id' => $product['model'] ?: (string)$productId
			];
		}
		
		if (!empty($productsPayload)) {
			$this->syncProducts($productsPayload, $apiKey);
		}
	}
	
	/**
	 * Get merchant point ID from config
	 */
	private function getMerchantPointId(): ?string {
		$merchantPointId = $this->config->get('marketplace_ivo_marketplace_merchant_point_id');
		return $merchantPointId ?: null;
	}
	
	/**
	 * Sync products to IVO API
	 * 
	 */
	private function syncProducts(array $products, string $apiKey): array {
		// EXACT payload from Magento Config.php syncProducts()
		$payload = [
			'import_name' => 'api_sync_import_opencart',
			'products' => $products
		];
		
		$ch = curl_init();
		curl_setopt_array($ch, [
			CURLOPT_URL => $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple',
			CURLOPT_HTTPHEADER => [
				'Authorization: Bearer ' . $apiKey,
				'Accept: application/json',
				'Content-Type: application/json'
			],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($payload),
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_TIMEOUT => 30
		]);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		return ['code' => $httpCode, 'response' => json_decode($response, true)];
	}
}
