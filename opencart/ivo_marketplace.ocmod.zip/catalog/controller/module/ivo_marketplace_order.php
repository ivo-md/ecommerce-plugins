<?php
/**
 * IVO Marketplace - Order Event Handler
 * 
 * 
 * Syncs product stock to IVO when an order is placed
 */
namespace Opencart\Catalog\Controller\Extension\IvoMarketplace\Module;

class IvoMarketplaceOrder extends \Opencart\System\Engine\Controller {
	
	private string $apiBaseUrl = 'https://a.ivo.md';
	private ?int $defaultCustomerGroupId = null;
	private ?bool $specialsInDiscounts = null;
	private array $onOrderStockStatuses = [];

	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}
	
	/**
	 * Event: Sync product stock when order is placed
	 * 
	 */
	public function eventOrderComplete(string &$route, array &$args, mixed &$output): void {
		// Check if module is enabled
		if (!$this->config->get('module_ivo_marketplace_status')) {
			return;
		}
		
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}
		
		$merchantPointId = $this->getMerchantPointId();
		if (!$merchantPointId) {
			return;
		}
		
		// $output contains the order_id from addOrder
		$orderId = $output;
		if (!$orderId) {
			return;
		}
		
		// Load order products
		$this->load->model('checkout/order');
		$orderProducts = $this->model_checkout_order->getProducts($orderId);
		
		if (empty($orderProducts)) {
			return;
		}
		
		// Get currency
		$currency = $this->config->get('config_currency');
		
		// Track processed product IDs to avoid duplicates (like Magento)
		$processedIds = [];
		$productsPayload = [];
		
		$this->load->model('catalog/product');
		
		foreach ($orderProducts as $orderProduct) {
			$productId = $orderProduct['product_id'];
			
			// Avoid processing same product twice (EXACT: like Magento processedSkus)
			if (in_array($productId, $processedIds)) {
				continue;
			}
			$processedIds[] = $productId;
			
			// Get current product data with updated stock
			$product = $this->model_catalog_product->getProduct($productId);
			
			if (!$product) {
				continue;
			}
			
			// EXACT payload from Magento OrderPlaceObserver. The price is the
			// one the admin sync sends, so an order never resets a sale price
			$productsPayload[] = [
				'name' => $product['name'],
				'price' => $this->applyPriceModifier($this->getSellingPrice((int)$productId)),
				'currency' => $currency,
				'availability' => $this->getAvailability((int)$productId),  // Current stock after order
				'merchant_point_id' => $merchantPointId,
				'merchant_internal_id' => $product['model'] ?: (string)$productId
			];
		}
		
		if (!empty($productsPayload)) {
			$this->syncProducts($productsPayload, $apiKey);
		}
	}
	
	/**
	 * Get merchant point ID from config
	 */
	private function getMerchantPointId(): ?string {
		$merchantPointId = $this->config->get('module_ivo_marketplace_merchant_point_id');
		return $merchantPointId ?: null;
	}

	/**
	 * Selling price as the admin sync computes it: the special (sale) running
	 * now for the store's default customer group, otherwise the regular price.
	 * Read from the tables, because here the catalog model's price and the
	 * configured customer group are those of the customer placing the order.
	 */
	private function getSellingPrice(int $productId): float {
		$query = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$productId . "'");
		$price = (float)($query->row['price'] ?? 0);

		$special = $this->getActiveSpecial($productId);
		if ($special !== null) {
			if ($special['type'] === 'P') {
				$specialPrice = $price - ($price * ($special['price'] / 100));
			} elseif ($special['type'] === 'S') {
				$specialPrice = $price - $special['price'];
			} else {
				$specialPrice = $special['price'];
			}
			// A special at zero or below would list the product on IVO for free
			if ($specialPrice > 0) {
				return $specialPrice;
			}
		}

		return $price;
	}

	/**
	 * The special running now for the store's default customer group, chosen
	 * the way the storefront chooses it: start/end dates open or current,
	 * lowest priority, then lowest price. OpenCart 4.1+ keeps specials in
	 * product_discount (special = 1, with a fixed/percent/subtract type), 4.0
	 * in product_special (always a fixed price).
	 */
	private function getActiveSpecial(int $productId): ?array {
		if ($this->defaultCustomerGroupId === null) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `key` = 'config_customer_group_id'");
			$this->defaultCustomerGroupId = (int)($query->row['value'] ?? $this->config->get('config_customer_group_id'));
		}
		if ($this->specialsInDiscounts === null) {
			$this->specialsInDiscounts = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product_discount` LIKE 'special'")->num_rows > 0;
		}

		$running = "((`date_start` = '0000-00-00' OR `date_start` < NOW()) AND (`date_end` = '0000-00-00' OR `date_end` > NOW()))";
		if ($this->specialsInDiscounts) {
			$query = $this->db->query("SELECT `price`, `type` FROM `" . DB_PREFIX . "product_discount` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . $this->defaultCustomerGroupId . "' AND `quantity` = '1' AND `special` = '1' AND " . $running . " ORDER BY `priority` ASC, `price` ASC LIMIT 1");
		} else {
			$query = $this->db->query("SELECT `price`, 'F' AS `type` FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . $this->defaultCustomerGroupId . "' AND " . $running . " ORDER BY `priority` ASC, `price` ASC LIMIT 1");
		}

		return $query->num_rows ? ['type' => (string)$query->row['type'], 'price' => (float)$query->row['price']] : null;
	}

	/**
	 * Stock as the admin sync sends it: the quantity, or none while the
	 * stock status only promises the goods
	 */
	private function getAvailability(int $productId): int {
		$query = $this->db->query("SELECT `quantity`, `stock_status_id` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . $productId . "'");
		if (!$query->num_rows || $this->isOnOrderStockStatus((int)$query->row['stock_status_id'])) {
			return 0;
		}

		return (int)$query->row['quantity'];
	}

	/**
	 * Whether the product's stock status says the goods are only promised,
	 * not on hand: pre-order, "2-3 days" and the like. IVO lists real stock
	 * only, so such products go out unavailable whatever their quantity.
	 * Merchants rename and add statuses, so the name decides (any language);
	 * OpenCart's own 2-3 Days (6) and Pre-Order (8) are the fallback.
	 */
	private function isOnOrderStockStatus(int $stockStatusId): bool {
		if ($stockStatusId <= 0) {
			return false;
		}

		if (!isset($this->onOrderStockStatuses[$stockStatusId])) {
			$query = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "stock_status` WHERE `stock_status_id` = '" . $stockStatusId . "'");
			$names = implode(' ', array_column($query->rows, 'name'));

			if (preg_match('/заказ|ожида|телефон|pre-?order|backorder|on order|phone|comand|aștept|astept|telefon|\d\s*(?:дн|ден|day|zi)/iu', $names)) {
				$onOrder = true;
			} elseif (preg_match('/наличи|склад|stock|stoc|disponibil|available/iu', $names)) {
				$onOrder = false;
			} else {
				$onOrder = in_array($stockStatusId, [6, 8], true);
			}
			$this->onOrderStockStatuses[$stockStatusId] = $onOrder;
		}

		return $this->onOrderStockStatuses[$stockStatusId];
	}

	/**
	 * Apply price modifier, as the admin sync does
	 */
	private function applyPriceModifier(float $price): float {
		$modifier = (float)($this->config->get('module_ivo_marketplace_price_modifier') ?? 0);
		if ($modifier === 0.0) {
			return $price;
		}
		$adjustedPrice = $price * (1 + ($modifier / 100));
		return round(max(0.0, $adjustedPrice), 2);
	}
	
	/**
	 * Sync products to IVO API
	 * 
	 */
	private function syncProducts(array $products, string $apiKey): array {
		// EXACT payload from Magento Config.php syncProducts()
		$payload = [
			'import_name' => 'api_sync_import_opencart',
			'products' => $products
		];
		
		$ch = curl_init();
		curl_setopt_array($ch, [
			CURLOPT_URL => $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple',
			CURLOPT_HTTPHEADER => [
				'Authorization: Bearer ' . $apiKey,
				'Accept: application/json',
				'Content-Type: application/json'
			],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($payload),
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_TIMEOUT => 30
		]);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		return ['code' => $httpCode, 'response' => json_decode($response, true)];
	}
}
