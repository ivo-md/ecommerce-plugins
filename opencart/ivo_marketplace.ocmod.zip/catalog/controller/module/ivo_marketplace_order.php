<?php
/**
 * IVO Marketplace - Order Event Handler
 * 
 * 
 * Syncs product stock to IVO when an order is placed
 */
namespace Opencart\Catalog\Controller\Extension\IvoMarketplace\Module;

class IvoMarketplaceOrder extends \Opencart\System\Engine\Controller {

	// Sent to IVO with every call; build.sh keeps it equal to the admin controller's
	public const VERSION = '1.0.27';
	
	private string $apiBaseUrl = 'https://a.ivo.md';
	private ?int $defaultCustomerGroupId = null;
	private ?bool $specialsInDiscounts = null;

	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}
	
	/**
	 * Event: Sync product stock when order is placed
	 * 
	 */
	public function eventOrderComplete(string &$route, array &$args, mixed &$output): void {
		// Check if module is enabled
		// A store with an API key pushes. The status setting is not consulted:
		// saving the settings once deleted it and silently stopped every push.
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}
		
		$merchantPointId = $this->getMerchantPointId();
		if (!$merchantPointId) {
			return;
		}
		
		// $output contains the order_id from addOrder
		$orderId = $output;
		if (!$orderId) {
			return;
		}
		
		// Load order products
		$this->load->model('checkout/order');
		$orderProducts = $this->model_checkout_order->getProducts($orderId);
		
		if (empty($orderProducts)) {
			return;
		}
		
		// Get currency
		$currency = $this->config->get('config_currency');
		
		// Track processed product IDs to avoid duplicates (like Magento)
		$processedIds = [];
		$productsPayload = [];
		
		$this->load->model('catalog/product');
		
		foreach ($orderProducts as $orderProduct) {
			$productId = $orderProduct['product_id'];
			
			// Avoid processing same product twice (EXACT: like Magento processedSkus)
			if (in_array($productId, $processedIds)) {
				continue;
			}
			$processedIds[] = $productId;
			
			// Get current product data with updated stock
			$product = $this->model_catalog_product->getProduct($productId);
			
			if (!$product) {
				continue;
			}
			
			// A native variant is on IVO under its product id, as the admin sync
			// sends it; a product with sizes as one offer per size, each with its
			// own stock under the ID the admin sync gives it
			$masterQuery = $this->db->query("SELECT `master_id` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$productId . "'");
			$isNativeVariant = (int)($masterQuery->row['master_id'] ?? 0) > 0;
			$sizeStock = $isNativeVariant ? [] : $this->getSizeStock((int)$productId, (int)$product['quantity']);
			if ($sizeStock) {
				foreach ($sizeStock as $internalId => $availability) {
					$productsPayload[] = [
						'merchant_internal_id' => (string)$internalId,
						'merchant_point_id' => $merchantPointId,
						'availability' => $availability,
						'availability_only' => true
					];
				}
				continue;
			}

			// EXACT payload from Magento OrderPlaceObserver. The price is the
			// one the admin sync sends, so an order never resets a sale price
			$productsPayload[] = [
				'name' => $product['name'],
				'price' => $this->applyPriceModifier($this->getSellingPrice((int)$productId)),
				'currency' => $currency,
				'availability' => (int)$product['quantity'],  // Current stock after order
				'merchant_point_id' => $merchantPointId,
				'merchant_internal_id' => $isNativeVariant ? (string)$productId : ($product['model'] ?: (string)$productId)
			];
		}
		
		// At most 100 per call (IVO's limit)
		foreach (array_chunk($productsPayload, 100) as $batch) {
			$this->syncProducts($batch, $apiKey);
		}
	}
	
	/**
	 * Stock of each size (option combination) of a product, keyed by the ID
	 * the admin sync gives the variant: the product id and its option value
	 * ids, in getOptionVariantProducts' order. Empty for a product without
	 * options. A size has its own quantity, or none once the product is out.
	 */
	private function getSizeStock(int $productId, int $productQuantity): array {
		$query = $this->db->query("SELECT pov.`product_option_id`, pov.`product_option_value_id`, pov.`quantity` FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "product_option` po ON (po.`product_option_id` = pov.`product_option_id`) LEFT JOIN `" . DB_PREFIX . "option_value` ov ON (ov.`option_value_id` = pov.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option` o ON (o.`option_id` = pov.`option_id`) WHERE pov.`product_id` = '" . (int)$productId . "' AND o.`type` IN ('select', 'radio', 'checkbox', 'image') ORDER BY po.`product_option_id` ASC, ov.`sort_order` ASC, pov.`product_option_value_id` ASC");
		if (empty($query->rows)) {
			return [];
		}

		$groups = [];
		foreach ($query->rows as $row) {
			$groups[(int)$row['product_option_id']][] = $row;
		}

		$combinations = array([]);
		foreach ($groups as $values) {
			$next = [];
			foreach ($combinations as $combo) {
				foreach ($values as $value) {
					$next[] = array_merge($combo, [$value]);
				}
			}
			$combinations = $next;
		}

		$stock = [];
		foreach ($combinations as $combo) {
			$ids = [];
			$quantities = [];
			foreach ($combo as $value) {
				$ids[] = (int)$value['product_option_value_id'];
				$quantities[] = max(0, (int)$value['quantity']);
			}
			$stock[$productId . '-' . implode('-', $ids)] = $productQuantity > 0 ? min($quantities) : 0;
		}

		return $stock;
	}

	/**
	 * Get merchant point ID from config
	 */
	private function getMerchantPointId(): ?string {
		$merchantPointId = $this->config->get('module_ivo_marketplace_merchant_point_id');
		return $merchantPointId ?: null;
	}

	/**
	 * Selling price as the admin sync computes it: the special (sale) running
	 * now for the store's default customer group, otherwise the regular price.
	 * Read from the tables, because here the catalog model's price and the
	 * configured customer group are those of the customer placing the order.
	 */
	private function getSellingPrice(int $productId): float {
		$query = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$productId . "'");
		$price = (float)($query->row['price'] ?? 0);

		$special = $this->getActiveSpecial($productId);
		if ($special !== null) {
			if ($special['type'] === 'P') {
				$specialPrice = $price - ($price * ($special['price'] / 100));
			} elseif ($special['type'] === 'S') {
				$specialPrice = $price - $special['price'];
			} else {
				$specialPrice = $special['price'];
			}
			// A special at zero or below would list the product on IVO for free
			if ($specialPrice > 0) {
				return $specialPrice;
			}
		}

		return $price;
	}

	/**
	 * The special running now for the store's default customer group, chosen
	 * the way the storefront chooses it: start/end dates open or current,
	 * lowest priority, then lowest price. OpenCart 4.1+ keeps specials in
	 * product_discount (special = 1, with a fixed/percent/subtract type), 4.0
	 * in product_special (always a fixed price).
	 */
	private function getActiveSpecial(int $productId): ?array {
		if ($this->defaultCustomerGroupId === null) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `key` = 'config_customer_group_id'");
			$this->defaultCustomerGroupId = (int)($query->row['value'] ?? $this->config->get('config_customer_group_id'));
		}
		if ($this->specialsInDiscounts === null) {
			$this->specialsInDiscounts = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product_discount` LIKE 'special'")->num_rows > 0;
		}

		$running = "((`date_start` = '0000-00-00' OR `date_start` < NOW()) AND (`date_end` = '0000-00-00' OR `date_end` > NOW()))";
		if ($this->specialsInDiscounts) {
			$query = $this->db->query("SELECT `price`, `type` FROM `" . DB_PREFIX . "product_discount` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . $this->defaultCustomerGroupId . "' AND `quantity` = '1' AND `special` = '1' AND " . $running . " ORDER BY `priority` ASC, `price` ASC LIMIT 1");
		} else {
			$query = $this->db->query("SELECT `price`, 'F' AS `type` FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . $this->defaultCustomerGroupId . "' AND " . $running . " ORDER BY `priority` ASC, `price` ASC LIMIT 1");
		}

		return $query->num_rows ? ['type' => (string)$query->row['type'], 'price' => (float)$query->row['price']] : null;
	}

	/**
	 * Apply price modifier, as the admin sync does
	 */
	private function applyPriceModifier(float $price): float {
		$modifier = (float)($this->config->get('module_ivo_marketplace_price_modifier') ?? 0);
		if ($modifier === 0.0) {
			return $price;
		}
		$adjustedPrice = $price * (1 + ($modifier / 100));
		return round(max(0.0, $adjustedPrice), 2);
	}
	
	/**
	 * Sync products to IVO API
	 * 
	 */
	private function syncProducts(array $products, string $apiKey): array {
		// EXACT payload from Magento Config.php syncProducts()
		$payload = [
			'import_name' => 'api_sync_import_opencart',
			'products' => $products
		];
		
		$ch = curl_init();
		curl_setopt_array($ch, [
			CURLOPT_URL => $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple',
			CURLOPT_HTTPHEADER => [
				'Authorization: Bearer ' . $apiKey,
				'X-IVO-Plugin: opencart/' . self::VERSION,
				'Accept: application/json',
				'Content-Type: application/json'
			],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($payload),
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_TIMEOUT => 30
		]);
		
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		return ['code' => $httpCode, 'response' => json_decode($response, true)];
	}
}
