<?php
/**
 * IVO Marketplace - Inbound Stock Webhook (OpenCart 3)
 *
 * Endpoint: index.php?route=extension/module/ivo_marketplace_webhook/stock
 * Auth:     Authorization: Bearer <api_key>   (matches module_ivo_marketplace_api_key)
 * Body:     { "products": [ { "merchant_internal_id": "SKU-or-ID", "availability": 5 }, ... ] }
 *
 * Triggered when a sale on IVO occurs, so the merchant's local OpenCart stock stays in sync.
 */
class ControllerExtensionModuleIvoMarketplaceWebhook extends Controller {

	public function stock() {
		$this->response->addHeader('Content-Type: application/json');

		if (!$this->config->get('module_ivo_marketplace_status')) {
			$this->respond(503, array('success' => false, 'error' => 'Module disabled'));
			return;
		}

		$expected = (string)$this->config->get('module_ivo_marketplace_api_key');
		$bearer = $this->extractBearerToken();
		if ($expected === '' || $bearer === '' || !hash_equals($expected, $bearer)) {
			$this->respond(401, array('success' => false, 'error' => 'Unauthorized'));
			return;
		}

		$raw = file_get_contents('php://input');
		$data = json_decode($raw, true);
		if (!is_array($data) || empty($data['products']) || !is_array($data['products'])) {
			$this->respond(400, array('success' => false, 'error' => 'Invalid payload: expected { products: [...] }'));
			return;
		}

		$updated = array();
		$errors = array();

		foreach ($data['products'] as $item) {
			$ref = isset($item['merchant_internal_id']) ? (string)$item['merchant_internal_id'] : '';
			if ($ref === '' || !array_key_exists('availability', $item)) {
				$errors[] = array('merchant_internal_id' => $ref, 'error' => 'Missing merchant_internal_id or availability');
				continue;
			}
			$delta = (int)$item['availability'];

			$productId = $this->resolveProductId($ref);
			if (!$productId) {
				$errors[] = array('merchant_internal_id' => $ref, 'error' => 'Product not found');
				continue;
			}

			$current_query = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$productId . "'");
			$current_stock = $current_query->num_rows ? (int)$current_query->row['quantity'] : 0;

			$new_stock = max(0, $current_stock + $delta);

			$update_stock = $this->config->has('module_ivo_marketplace_update_stock')
				? $this->config->get('module_ivo_marketplace_update_stock')
				: '1';

			if ($update_stock !== '1') {
				$updated[] = array('merchant_internal_id' => $ref, 'availability' => $new_stock, 'note' => 'Skipped (stock sync disabled)');
				continue;
			}

			try {
				$this->db->query(
					"UPDATE `" . DB_PREFIX . "product` SET `quantity` = '" . (int)$new_stock . "' WHERE `product_id` = '" . (int)$productId . "'"
				);
				$updated[] = array('merchant_internal_id' => $ref, 'availability' => $new_stock);
			} catch (\Throwable $e) {
				$errors[] = array('merchant_internal_id' => $ref, 'error' => $e->getMessage());
			}
		}

		$this->respond(200, array(
			'success' => empty($errors),
			'updated' => $updated,
			'errors'  => $errors,
		));
	}

	/**
	 * merchant_internal_id is product 'model' (SKU) when present, else product_id.
	 */
	private function resolveProductId($ref) {
		$escaped = $this->db->escape($ref);
		$query = $this->db->query(
			"SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `model` = '" . $escaped . "' OR `sku` = '" . $escaped . "' LIMIT 1"
		);
		if ($query->num_rows) {
			return (int)$query->row['product_id'];
		}

		if (ctype_digit($ref)) {
			$query = $this->db->query(
				"SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$ref . "' LIMIT 1"
			);
			if ($query->num_rows) {
				return (int)$query->row['product_id'];
			}
		}

		return null;
	}

	private function extractBearerToken() {
		$header = '';
		if (function_exists('apache_request_headers')) {
			$headers = apache_request_headers();
			foreach ($headers as $k => $v) {
				if (strcasecmp($k, 'Authorization') === 0) { $header = $v; break; }
			}
		}
		if ($header === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) {
			$header = $_SERVER['HTTP_AUTHORIZATION'];
		}
		if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
			$header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
		}
		if ($header === '') {
			return '';
		}
		if (stripos($header, 'Bearer ') === 0) {
			return trim(substr($header, 7));
		}
		return trim($header);
	}

	private function respond($status, $payload) {
		http_response_code($status);
		$this->response->setOutput(json_encode($payload));
	}
}
