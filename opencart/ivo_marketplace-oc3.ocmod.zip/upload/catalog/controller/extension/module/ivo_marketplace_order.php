<?php
/**
 * IVO Marketplace - Order Event Handler (OpenCart 3)
 *
 * Syncs product stock to IVO when an order is placed on the storefront.
 * Registered on: model/checkout/order/addOrder/after
 */
class ControllerExtensionModuleIvoMarketplaceOrder extends Controller {

	private $apiBaseUrl = 'https://a.ivo.md';
	private $defaultCustomerGroupId = null;

	public function __construct($registry) {
		parent::__construct($registry);
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}

	/**
	 * Event: Sync product stock when order is placed
	 */
	public function eventOrderComplete(&$route, &$args, &$output) {
		// A store with an API key pushes. The status setting is not consulted:
		// saving the settings once deleted it and silently stopped every push.
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}

		$merchantPointId = $this->getMerchantPointId();
		if (!$merchantPointId) {
			return;
		}

		// $output contains the order_id returned by addOrder
		$orderId = $output;
		if (!$orderId) {
			return;
		}

		$this->load->model('checkout/order');
		$orderProducts = $this->model_checkout_order->getOrderProducts($orderId);

		if (empty($orderProducts)) {
			return;
		}

		$currency = $this->config->get('config_currency');

		$processedIds = array();
		$productsPayload = array();

		$this->load->model('catalog/product');

		foreach ($orderProducts as $orderProduct) {
			$productId = $orderProduct['product_id'];

			if (in_array($productId, $processedIds)) {
				continue;
			}
			$processedIds[] = $productId;

			$product = $this->model_catalog_product->getProduct($productId);

			if (!$product) {
				continue;
			}

			// A product with sizes is on IVO as one offer per size: each gets its
			// own stock, under the ID the admin sync gives it
			$sizeStock = $this->getSizeStock((int)$productId, (int)$product['quantity']);
			if ($sizeStock) {
				foreach ($sizeStock as $internalId => $availability) {
					$productsPayload[] = array(
						'merchant_internal_id' => $internalId,
						'merchant_point_id' => $merchantPointId,
						'availability' => $availability,
						'availability_only' => true
					);
				}
				continue;
			}

			// The price is the one the admin sync sends, so an order never
			// resets a sale price
			$productsPayload[] = array(
				'name' => $product['name'],
				'price' => $this->applyPriceModifier($this->getSellingPrice((int)$productId)),
				'currency' => $currency,
				'availability' => (int)$product['quantity'],
				'merchant_point_id' => $merchantPointId,
				'merchant_internal_id' => $product['model'] ? $product['model'] : (string)$productId
			);
		}

		// At most 100 per call (IVO's limit)
		foreach (array_chunk($productsPayload, 100) as $batch) {
			$this->syncProducts($batch, $apiKey);
		}
	}

	/**
	 * Stock of each size (option combination) of a product, keyed by the ID
	 * the admin sync gives the variant: the product id and its option value
	 * ids, in getOptionVariantProducts' order. Empty for a product without
	 * options. A size has its own quantity, or none once the product is out.
	 */
	private function getSizeStock($productId, $productQuantity) {
		$query = $this->db->query("SELECT pov.`product_option_id`, pov.`product_option_value_id`, pov.`quantity` FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "product_option` po ON (po.`product_option_id` = pov.`product_option_id`) LEFT JOIN `" . DB_PREFIX . "option_value` ov ON (ov.`option_value_id` = pov.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option` o ON (o.`option_id` = pov.`option_id`) WHERE pov.`product_id` = '" . (int)$productId . "' AND o.`type` IN ('select', 'radio', 'checkbox', 'image') ORDER BY po.`product_option_id` ASC, ov.`sort_order` ASC, pov.`product_option_value_id` ASC");
		if (empty($query->rows)) {
			return array();
		}

		$groups = array();
		foreach ($query->rows as $row) {
			$groups[(int)$row['product_option_id']][] = $row;
		}

		$combinations = array(array());
		foreach ($groups as $values) {
			$next = array();
			foreach ($combinations as $combo) {
				foreach ($values as $value) {
					$next[] = array_merge($combo, array($value));
				}
			}
			$combinations = $next;
		}

		$stock = array();
		foreach ($combinations as $combo) {
			$ids = array();
			$quantities = array();
			foreach ($combo as $value) {
				$ids[] = (int)$value['product_option_value_id'];
				$quantities[] = max(0, (int)$value['quantity']);
			}
			$stock[$productId . '-' . implode('-', $ids)] = $productQuantity > 0 ? min($quantities) : 0;
		}

		return $stock;
	}

	private function getMerchantPointId() {
		$merchantPointId = $this->config->get('module_ivo_marketplace_merchant_point_id');
		return $merchantPointId ? $merchantPointId : null;
	}

	/**
	 * Selling price as the admin sync computes it: the special (sale) running
	 * now for the store's default customer group, chosen the way the
	 * storefront chooses it (start/end dates open or current, lowest priority,
	 * then lowest price), otherwise the regular price. Read from the tables,
	 * because here the catalog model's price and the configured customer
	 * group are those of the customer placing the order.
	 */
	private function getSellingPrice($productId) {
		if ($this->defaultCustomerGroupId === null) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `key` = 'config_customer_group_id'");
			$this->defaultCustomerGroupId = (int)($query->num_rows ? $query->row['value'] : $this->config->get('config_customer_group_id'));
		}

		$query = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . (int)$this->defaultCustomerGroupId . "' AND ((`date_start` = '0000-00-00' OR `date_start` < NOW()) AND (`date_end` = '0000-00-00' OR `date_end` > NOW())) ORDER BY `priority` ASC, `price` ASC LIMIT 1");
		// A special at zero or below would list the product on IVO for free
		if ($query->num_rows && (float)$query->row['price'] > 0) {
			return (float)$query->row['price'];
		}

		$query = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$productId . "'");
		return $query->num_rows ? (float)$query->row['price'] : 0.0;
	}

	/**
	 * Apply price modifier, as the admin sync does
	 */
	private function applyPriceModifier($price) {
		$modifier = (float)($this->config->get('module_ivo_marketplace_price_modifier') ? $this->config->get('module_ivo_marketplace_price_modifier') : 0);
		if ($modifier === 0.0) {
			return $price;
		}
		$adjustedPrice = $price * (1 + ($modifier / 100));
		return round(max(0.0, $adjustedPrice), 2);
	}

	private function syncProducts($products, $apiKey) {
		$payload = array(
			'import_name' => 'api_sync_import_opencart',
			'products' => $products
		);

		$ch = curl_init();
		curl_setopt_array($ch, array(
			CURLOPT_URL => $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple',
			CURLOPT_HTTPHEADER => array(
				'Authorization: Bearer ' . $apiKey,
				'Accept: application/json',
				'Content-Type: application/json'
			),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($payload),
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_TIMEOUT => 30
		));

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		return array('code' => $httpCode, 'response' => json_decode($response, true));
	}
}
