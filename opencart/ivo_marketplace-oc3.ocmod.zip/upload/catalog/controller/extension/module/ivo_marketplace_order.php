<?php
/**
 * IVO Marketplace - Order Event Handler (OpenCart 3)
 *
 * Syncs product stock to IVO when an order is placed on the storefront.
 * Registered on: model/checkout/order/addOrder/after
 */
class ControllerExtensionModuleIvoMarketplaceOrder extends Controller {

	private $apiBaseUrl = 'https://a.ivo.md';

	public function __construct($registry) {
		parent::__construct($registry);
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}

	/**
	 * Event: Sync product stock when order is placed
	 */
	public function eventOrderComplete(&$route, &$args, &$output) {
		if (!$this->config->get('module_ivo_marketplace_status')) {
			return;
		}

		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}

		$merchantPointId = $this->getMerchantPointId();
		if (!$merchantPointId) {
			return;
		}

		// $output contains the order_id returned by addOrder
		$orderId = $output;
		if (!$orderId) {
			return;
		}

		$this->load->model('checkout/order');
		$orderProducts = $this->model_checkout_order->getOrderProducts($orderId);

		if (empty($orderProducts)) {
			return;
		}

		$currency = $this->config->get('config_currency');

		$processedIds = array();
		$productsPayload = array();

		$this->load->model('catalog/product');

		foreach ($orderProducts as $orderProduct) {
			$productId = $orderProduct['product_id'];

			if (in_array($productId, $processedIds)) {
				continue;
			}
			$processedIds[] = $productId;

			$product = $this->model_catalog_product->getProduct($productId);

			if (!$product) {
				continue;
			}

			$productsPayload[] = array(
				'name' => $product['name'],
				'price' => (float)$product['price'],
				'currency' => $currency,
				'availability' => (int)$product['quantity'],
				'merchant_point_id' => $merchantPointId,
				'merchant_internal_id' => $product['model'] ? $product['model'] : (string)$productId
			);
		}

		if (!empty($productsPayload)) {
			$this->syncProducts($productsPayload, $apiKey);
		}
	}

	private function getMerchantPointId() {
		$merchantPointId = $this->config->get('module_ivo_marketplace_merchant_point_id');
		return $merchantPointId ? $merchantPointId : null;
	}

	private function syncProducts($products, $apiKey) {
		$payload = array(
			'import_name' => 'api_sync_import_opencart',
			'products' => $products
		);

		$ch = curl_init();
		curl_setopt_array($ch, array(
			CURLOPT_URL => $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple',
			CURLOPT_HTTPHEADER => array(
				'Authorization: Bearer ' . $apiKey,
				'Accept: application/json',
				'Content-Type: application/json'
			),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($payload),
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_TIMEOUT => 30
		));

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		return array('code' => $httpCode, 'response' => json_decode($response, true));
	}
}
