<?php
/**
 * IVO Marketplace integration for OpenCart 3.0.3.x
 *
 * Ported from the OpenCart 4 extension. Key differences handled here:
 *  - no namespaces (OC3 uses Controller* class names)
 *  - routes use extension/module/ivo_marketplace with /method dispatch
 *  - admin catalog model methods keep the get*Product* prefixes
 *  - OC3 has no master_id/variant product columns, so only option-based
 *    variants are expanded
 *  - events registered with positional addEvent() and unprefixed triggers
 */
class ControllerExtensionModuleIvoMarketplace extends Controller {
	// Plugin version, kept in step with install.json by build.sh
	const VERSION = '1.0.29';
	// Force Sync slices: products read, and payloads gathered, per request
	const SYNC_SLICE_PRODUCTS = 50;
	const SYNC_SLICE_PAYLOADS = 50;


	// IVO Endpoints
	private $setupUrl = 'https://www.ivo.md/merchant/plugin/setup';
	private $apiBaseUrl = 'https://a.ivo.md';
	private $lastSyncError = '';
	// Why the merchant point could not be found: code, HTTP status, cURL error or IVO's message
	private $pointsFailure = null;
	private $measureUnits = array();
	private $activeSpecials = array();

	public function __construct($registry) {
		parent::__construct($registry);
		if ($setupUrl = getenv('IVO_SETUP_URL')) {
			$this->setupUrl = $setupUrl;
		}
		if ($apiUrl = getenv('IVO_API_URL')) {
			$this->apiBaseUrl = $apiUrl;
		}
	}

	/**
	 * Display the main configuration page
	 */
	public function index() {
		$this->load->language('extension/module/ivo_marketplace');

		$this->ensureEventsRegistered();

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/ivo_marketplace', 'user_token=' . $this->session->data['user_token'], true)
		);

		// URLs for actions
		$data['save'] = $this->url->link('extension/module/ivo_marketplace/save', 'user_token=' . $this->session->data['user_token'], true);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		// Check if configured (has API key)
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		$data['configured'] = (bool)$apiKey;
		$data['api_valid'] = false;
		$data['api_error'] = '';
		$data['merchant_info'] = array();
		$data['module_ivo_marketplace_status'] = $this->config->get('module_ivo_marketplace_status');
		$data['module_ivo_marketplace_merchant_point_id'] = $this->config->get('module_ivo_marketplace_merchant_point_id');

		// Setup config values
		if (!$this->config->has('module_ivo_marketplace_price_modifier')) {
			$data['module_ivo_marketplace_price_modifier'] = '0';
		} else {
			$val_modifier = $this->config->get('module_ivo_marketplace_price_modifier');
			$data['module_ivo_marketplace_price_modifier'] = ($val_modifier === '') ? '0' : $val_modifier;
		}

		if (!$this->config->has('module_ivo_marketplace_update_stock')) {
			$data['module_ivo_marketplace_update_stock'] = '1';
		} else {
			$data['module_ivo_marketplace_update_stock'] = $this->config->get('module_ivo_marketplace_update_stock');
		}

		// Masked API key (show first 8 chars)
		if ($apiKey) {
			$data['api_key_masked'] = substr($apiKey, 0, 8) . '••••••••••••••••';

			$merchantInfo = $this->checkApiKey();
			if (isset($merchantInfo['error'])) {
				// The raw answer goes to the log; the page says why in plain words
				$this->log->write('IVO Marketplace: API check failed: ' . $merchantInfo['error']);
				$data['api_error'] = $this->merchantPointError();
			} else {
				$data['api_valid'] = true;
				$data['merchant_info'] = $merchantInfo;
			}
		} else {
			$data['api_key_masked'] = '';
		}

		// URLs for buttons
		$data['configure_url'] = $this->url->link('extension/module/ivo_marketplace/setup', 'user_token=' . $this->session->data['user_token'], true);
		// This URL is embedded in JavaScript, not an HTML attribute. OpenCart 3
		// returns query separators as &amp;, which would make the browser send an
		// "amp;user_token" parameter and cause the JSON endpoint to return HTML.
		$data['sync_url'] = html_entity_decode($this->url->link('extension/module/ivo_marketplace/syncAll', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
		$locale = $this->language->get('code');
		if (strpos($locale, 'ru') === 0) {
			$data['help_guide_url'] = 'https://www.ivo.md/ru/help/merchant-integration/opencart';
		} elseif (strpos($locale, 'en') === 0) {
			$data['help_guide_url'] = 'https://www.ivo.md/en/help/merchant-integration/opencart';
		} else {
			$data['help_guide_url'] = 'https://www.ivo.md/help/merchant-integration/opencart';
		}

		// Fetch merchant points only if API is valid
		$data['merchant_points'] = array();
		$data['merchant_point_warning'] = '';
		if ($data['api_valid']) {
			$data['merchant_points'] = $this->fetchMerchantPoints();

			if (!$data['module_ivo_marketplace_merchant_point_id'] && count($data['merchant_points']) > 1) {
				$data['merchant_point_warning'] = $this->language->get('text_select_point_warning');
			}
		}

		// Check for callback cookies (from catalog callback)
		if (isset($_COOKIE['ivo_callback_success'])) {
			$this->session->data['success'] = $this->language->get('text_success_configured');
			setcookie('ivo_callback_success', '', time() - 3600, '/');
			$data['configured'] = true;
			$merchantInfo = $this->checkApiKey();
			if (!isset($merchantInfo['error'])) {
				$data['api_valid'] = true;
				$data['merchant_info'] = $merchantInfo;
				$data['merchant_points'] = $this->fetchMerchantPoints();
			}
		}

		// Why the points could not be listed: the API check or the points call failed
		$data['merchant_point_error'] = ($data['configured'] && $this->merchantPointsFailed()) ? $this->merchantPointError() : '';

		if (isset($_COOKIE['ivo_callback_error'])) {
			$error = $_COOKIE['ivo_callback_error'];
			if ($error === 'decrypt_failed') {
				$this->session->data['error_warning'] = $this->language->get('error_api_key_decrypt');
			} else {
				$this->session->data['error_warning'] = $this->language->get('error_no_api_key');
			}
			setcookie('ivo_callback_error', '', time() - 3600, '/');
		}

		// Handle success/error messages from session
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}

		// Language variables for template
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_select'] = $this->language->get('text_select');
		$data['text_syncing'] = $this->language->get('text_syncing');
		$data['text_please_configure'] = $this->language->get('text_please_configure');
		$data['text_merchant_name'] = $this->language->get('text_merchant_name');
		$data['text_merchant_status'] = $this->language->get('text_merchant_status');
		$data['text_status_inactive'] = $this->language->get('text_status_inactive');

		$data['entry_api_key'] = $this->language->get('entry_api_key');
		$data['entry_merchant_point'] = $this->language->get('entry_merchant_point');
		$data['entry_price_modifier'] = $this->language->get('entry_price_modifier');
		$data['entry_update_stock'] = $this->language->get('entry_update_stock');
		$data['text_price_modifier_comment'] = $this->language->get('text_price_modifier_comment');
		$data['text_update_stock_comment'] = $this->language->get('text_update_stock_comment');

		$data['error_api_connection'] = $this->language->get('error_api_connection');

		$data['button_configure'] = $this->language->get('button_configure');
		$data['button_reconfigure'] = $this->language->get('button_reconfigure');
		$data['button_force_sync'] = $this->language->get('button_force_sync');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$new_ui_strings = array(
			'text_opencart_bridge', 'text_connect_prompt', 'text_connect_desc',
			'text_configure_conn', 'text_view_guide', 'text_settings', 'text_save_settings',
			'text_reconfigure', 'text_force_sync', 'text_step_account', 'text_step_account_desc',
			'text_step_sync', 'text_step_sync_desc', 'text_step_order', 'text_step_order_desc',
			'text_badge_success', 'text_badge_required', 'text_badge_error', 'text_connection_error', 'text_badge_active', 'text_badge_inactive', 'text_badge_next',
			'text_badge_ready', 'text_connected', 'text_version', 'text_sync_progress'
		);
		foreach ($new_ui_strings as $key) {
			$data[$key] = $this->language->get($key);
		}
		$data['version'] = self::VERSION;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		// OpenCart 3.0.2.0 renders admin pages from templates it compiled once
		// and never re-reads (Developer Settings > Theme cache, on by default),
		// so after an upgrade 585.md kept the old page and its old Force Sync
		// script. This page is always rendered from its file.
		$this->config->set('template_cache', false);

		$this->response->setOutput($this->load->view('extension/module/ivo_marketplace', $data));
	}

	public function save() {
		$this->load->language('extension/module/ivo_marketplace');

		$json = array();

		if (!$this->user->hasPermission('modify', 'extension/module/ivo_marketplace')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			// Preserve the API key
			$settings = $this->request->post;
			$settings['module_ivo_marketplace_api_key'] = $this->config->get('module_ivo_marketplace_api_key');
			// The form has no status field: saving it used to drop the status,
			// which silently switched off product, order and stock pushes.
			// A connected store is an enabled one.
			$settings['module_ivo_marketplace_status'] = $settings['module_ivo_marketplace_api_key'] ? 1 : 0;

			$old_modifier = $this->config->get('module_ivo_marketplace_price_modifier');
			$new_modifier = isset($settings['module_ivo_marketplace_price_modifier']) ? $settings['module_ivo_marketplace_price_modifier'] : '0';
			if ($new_modifier === '') {
				$new_modifier = '0';
			}

			$this->model_setting_setting->editSetting('module_ivo_marketplace', $settings);

			// New prices for the whole catalogue: the page re-sends it slice by
			// slice, as Force Sync does, not inside this request
			if ((float)$old_modifier !== (float)$new_modifier) {
				$json['ivo_resync'] = true;
			}

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Redirect to IVO setup page
	 */
	public function setup() {
		$shopUrl = HTTP_CATALOG;

		$nonce = bin2hex(random_bytes(16));
		$adminUrl = rtrim(HTTP_SERVER, '/') . '/';
		$adminLanguage = (string)($this->config->get('config_admin_language') ? $this->config->get('config_admin_language') : ($this->config->get('config_language') ? $this->config->get('config_language') : 'en-gb'));
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'module_ivo_marketplace' AND `key` = 'module_ivo_marketplace_setup_nonce'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'module_ivo_marketplace', `key` = 'module_ivo_marketplace_setup_nonce', `value` = '" . $this->db->escape($nonce . '|' . time() . '|' . $adminUrl . '|' . $adminLanguage) . "', `serialized` = '0'");

		$returnUrl = HTTP_CATALOG . 'index.php?route=extension/module/ivo_marketplace_callback&token=' . $this->session->data['user_token'] . '&nonce=' . $nonce;

		$params = array(
			'url_shop' => $shopUrl,
			'url_return' => $returnUrl,
			'platform' => 'opencart',
			'version' => VERSION,
			'ip_server' => isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : '127.0.0.1',
			'os_server' => php_uname('s')
		);

		$setupUrl = $this->setupUrl . '?' . http_build_query($params);
		$this->response->redirect($setupUrl);
	}

	/**
	 * Callback from IVO after setup (admin-side)
	 */
	public function callback() {
		if (!$this->user->isLogged()) {
			if (isset($this->request->get['key'])) {
				$this->session->data['ivo_pending_key'] = $this->request->get['key'];
			}
			$this->response->redirect($this->url->link('common/login'));
			return;
		}

		$this->load->language('extension/module/ivo_marketplace');

		if (isset($this->request->get['key'])) {
			$encryptedKey = $this->request->get['key'];
			$apiKey = $this->decryptIvoKey($encryptedKey);

			if ($apiKey) {
				$this->load->model('setting/setting');

				$existingSettings = $this->model_setting_setting->getSetting('module_ivo_marketplace');
				$existingSettings['module_ivo_marketplace_api_key'] = $apiKey;
				$existingSettings['module_ivo_marketplace_status'] = 1;
				// Keep the point already chosen: deleting it on every setup stopped every
				// push until the merchant chose it again. Choose one only when none is
				// saved and IVO lists exactly one.
				$this->config->set('module_ivo_marketplace_api_key', $apiKey);
				$savedPointId = $this->normalizeMerchantPointId(isset($existingSettings['module_ivo_marketplace_merchant_point_id']) ? $existingSettings['module_ivo_marketplace_merchant_point_id'] : '');
				if ($savedPointId === '') {
					$points = $this->fetchMerchantPoints();
					if (count($points) === 1 && isset($points[0])) {
						$pointId = $this->normalizeMerchantPointId(isset($points[0]['id']) ? $points[0]['id'] : (isset($points[0]['_id']) ? $points[0]['_id'] : ''));
						if ($pointId !== '') {
							$existingSettings['module_ivo_marketplace_merchant_point_id'] = $pointId;
						}
					}
				}

				$this->model_setting_setting->editSetting('module_ivo_marketplace', $existingSettings);

				$this->session->data['success'] = $this->language->get('text_success_configured');
			} else {
				$this->session->data['error_warning'] = $this->language->get('error_api_key_decrypt');
			}
		} else {
			$this->session->data['error_warning'] = $this->language->get('error_no_api_key');
		}

		$this->response->redirect($this->url->link('extension/module/ivo_marketplace', 'user_token=' . $this->session->data['user_token'], true));
	}

	private function decryptIvoKey($encryptedKey) {
		$decoded = base64_decode($encryptedKey, true);
		return $decoded !== false ? $decoded : false;
	}

	/**
	 * Check if API key is valid by calling /v1/merchant-api/check
	 */
	private function checkApiKey() {
		$this->pointsFailure = null;
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');

		if (!$apiKey) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'module_ivo_marketplace' AND `key` = 'module_ivo_marketplace_api_key'");
			if ($query->num_rows) {
				$apiKey = $query->row['value'];
			}
		}

		if (!$apiKey) {
			$this->pointsFailure = array('code' => 'no_api_key');
			return array('error' => 'No API key configured');
		}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/check');
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Authorization: Bearer ' . $apiKey,
			'X-IVO-Plugin: opencart3/' . self::VERSION,
			'Accept: application/json'
		));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$curlError = curl_error($ch);
		curl_close($ch);

		$this->log->write('IVO Marketplace: API Check HTTP Code: ' . $httpCode);
		if ($curlError) {
			$this->log->write('IVO Marketplace: API Check CURL Error: ' . $curlError);
			$this->recordPointsFailure($response, $httpCode, $curlError);
			return array('error' => 'cURL error: ' . $curlError);
		}

		if ($httpCode != 200) {
			$this->recordPointsFailure($response, $httpCode, $curlError);
			return array('error' => 'HTTP ' . $httpCode . ' - ' . substr((string)$response, 0, 200));
		}

		$data = json_decode($response, true);
		if (isset($data['merchant_id'])) {
			return $data;
		}

		$this->recordPointsFailure($response, $httpCode, $curlError);
		return array('error' => 'Invalid API response: ' . substr((string)$response, 0, 200));
	}

	/**
	 * Fetch merchant points from IVO API
	 */
	private function fetchMerchantPoints() {
		$this->pointsFailure = null;
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');

		if (!$apiKey) {
			$query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'module_ivo_marketplace' AND `key` = 'module_ivo_marketplace_api_key'");
			if ($query->num_rows) {
				$apiKey = $query->row['value'];
			}
		}

		if (!$apiKey) {
			$this->log->write('IVO Marketplace: No API key found for fetching merchant points');
			$this->pointsFailure = array('code' => 'no_api_key');
			return array();
		}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/merchant-points');
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Authorization: Bearer ' . $apiKey,
			'X-IVO-Plugin: opencart3/' . self::VERSION,
			'Accept: application/json'
		));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$curlError = curl_error($ch);
		curl_close($ch);

		$this->log->write('IVO Marketplace: HTTP Code: ' . $httpCode);
		if ($curlError) {
			$this->log->write('IVO Marketplace: CURL Error: ' . $curlError);
		}

		$data = ($httpCode == 200) ? json_decode((string)$response, true) : null;
		if (is_array($data)) {
			$points = isset($data['points']) ? $data['points'] : (isset($data['data']) ? $data['data'] : $data);
			if (!is_array($points)) {
				$points = array();
			}
			foreach ($points as &$point) {
				if (isset($point['_id']) && !isset($point['id'])) {
					$point['id'] = $point['_id'];
				}
				if (isset($point['id'])) {
					$point['id'] = $this->normalizeMerchantPointId($point['id']);
				}
			}
			unset($point);
			$this->log->write('IVO Marketplace: Found ' . count($points) . ' merchant points');
			if (empty($points)) {
				$this->pointsFailure = array('code' => 'no_points', 'status' => 200, 'detail' => '');
			}
			return $points;
		}

		// Every way this can fail is kept, so the admin reads the real reason
		$this->log->write('IVO Marketplace: Merchant points response: ' . substr((string)$response, 0, 500));
		$this->recordPointsFailure($response, $httpCode, $curlError);
		return array();
	}

	/**
	 * Keep why IVO could not be reached or used, for merchantPointError()
	 */
	private function recordPointsFailure($response, $httpCode, $curlError) {
		$httpCode = (int)$httpCode;
		if ($response === false || $httpCode === 0) {
			$this->pointsFailure = array('code' => 'network', 'status' => 0, 'detail' => (string)$curlError);
			return;
		}

		$data = json_decode((string)$response, true);
		$message = (is_array($data) && isset($data['message']) && is_string($data['message'])) ? $data['message'] : '';
		$codes = array(
			'api_key_invalid' => 'key_invalid',
			'api_key_missing' => 'key_invalid',
			'integration_disabled' => 'integration_disabled',
			'merchant_not_found' => 'merchant_not_found',
		);
		if (isset($codes[$message])) {
			$code = $codes[$message];
		} elseif (is_array($data) && $httpCode !== 200) {
			$code = 'http';
		} else {
			$code = 'unreadable';
		}
		$this->pointsFailure = array('code' => $code, 'status' => $httpCode, 'detail' => $message);
	}

	/**
	 * Why no merchant point could be used, in the admin's language: the
	 * connection error, IVO's refusal, or the setting still to be chosen.
	 */
	private function merchantPointError() {
		$failure = $this->pointsFailure;
		if (!is_array($failure)) {
			$failure = array('code' => $this->config->get('module_ivo_marketplace_api_key') ? 'unknown' : 'no_api_key');
		}

		$host = (string)parse_url($this->apiBaseUrl, PHP_URL_HOST);
		if ($host === '') {
			$host = $this->apiBaseUrl;
		}
		$status = isset($failure['status']) ? (int)$failure['status'] : 0;
		$detail = isset($failure['detail']) ? trim((string)$failure['detail']) : '';

		switch ($failure['code']) {
			case 'network':
				return sprintf($this->language->get('error_point_network'), $host, $detail !== '' ? $detail : 'no response');
			case 'http':
				return sprintf($this->language->get('error_point_http'), $status, $detail !== '' ? ': ' . $detail : '');
			case 'unreadable':
				return sprintf($this->language->get('error_point_unreadable'), $status, $host);
			case 'key_invalid':
			case 'integration_disabled':
			case 'merchant_not_found':
			case 'no_points':
			case 'no_api_key':
				return $this->language->get('error_point_' . $failure['code']);
			case 'choose_point':
				return $this->language->get('error_point_choose');
		}

		return $this->language->get('error_not_configured');
	}

	/**
	 * True when the last call could not reach or use IVO, rather than
	 * finding several points for the admin to choose from
	 */
	private function merchantPointsFailed() {
		return is_array($this->pointsFailure) && $this->pointsFailure['code'] !== 'choose_point';
	}

	/**
	 * Force Sync, one slice per request (see syncSlice): the page calls again
	 * with the returned `after` and `run_id` until `done`.
	 */
	public function syncAll() {
		$this->load->language('extension/module/ivo_marketplace');

		$json = array();

		try {
			if (!$this->user->hasPermission('modify', 'extension/module/ivo_marketplace')) {
				$json['error'] = $this->language->get('error_permission');
			} else {
				$after = isset($this->request->get['after']) ? (int)$this->request->get['after'] : 0;
				$runId = isset($this->request->get['run_id']) ? preg_replace('/[^A-Za-z0-9_]/', '', (string)$this->request->get['run_id']) : '';
				$selectedMerchantPointId = $this->normalizeMerchantPointId(isset($this->request->get['merchant_point_id']) ? $this->request->get['merchant_point_id'] : '');
				if ($selectedMerchantPointId !== '' && $runId === '') {
					$this->saveMerchantPointId($selectedMerchantPointId);
				}

				$slice = $this->syncSlice($after, $runId, $selectedMerchantPointId ? $selectedMerchantPointId : null);
				if ($slice === false) {
					$json['error'] = $this->lastSyncError ? $this->lastSyncError : $this->language->get('error_not_configured');
				} else {
					$json = $slice;
					if ($slice['done']) {
						$json['success'] = $this->language->get('text_sync_success');
					}
				}
			}
		} catch (\Throwable $e) {
			$this->log->write('IVO Marketplace Force Sync Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
			$json['error'] = 'Force sync failed: ' . $e->getMessage();
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function getMerchantPointId() {
		$configId = $this->normalizeMerchantPointId($this->config->get('module_ivo_marketplace_merchant_point_id'));
		if ($configId) {
			return $configId;
		}

		$points = $this->fetchMerchantPoints();

		if (count($points) === 1 && isset($points[0])) {
			$candidate = isset($points[0]['id']) ? $points[0]['id'] : (isset($points[0]['_id']) ? $points[0]['_id'] : null);
			return $this->normalizeMerchantPointId($candidate);
		}
		if (count($points) > 1) {
			$this->pointsFailure = array('code' => 'choose_point');
		}

		return null;
	}

	private function normalizeMerchantPointId($value) {
		if (is_array($value)) {
			if (isset($value['$oid'])) {
				$value = $value['$oid'];
			} elseif (isset($value['oid'])) {
				$value = $value['oid'];
			} elseif (isset($value['id'])) {
				$value = $value['id'];
			} elseif (isset($value['_id'])) {
				$value = $value['_id'];
			} else {
				$value = '';
			}
		}
		return trim((string)$value);
	}

	private function saveMerchantPointId($merchantPointId) {
		$this->load->model('setting/setting');

		$settings = array(
			'module_ivo_marketplace_api_key' => $this->config->get('module_ivo_marketplace_api_key'),
			'module_ivo_marketplace_status' => $this->config->get('module_ivo_marketplace_api_key') ? 1 : 0,
			'module_ivo_marketplace_price_modifier' => $this->config->get('module_ivo_marketplace_price_modifier') ? $this->config->get('module_ivo_marketplace_price_modifier') : '0',
			'module_ivo_marketplace_update_stock' => $this->config->get('module_ivo_marketplace_update_stock') ? $this->config->get('module_ivo_marketplace_update_stock') : '1',
			'module_ivo_marketplace_merchant_point_id' => $merchantPointId
		);

		$this->model_setting_setting->editSetting('module_ivo_marketplace', $settings);
		$this->config->set('module_ivo_marketplace_merchant_point_id', $merchantPointId);
	}

	/**
	 * Prepare product payload for IVO API
	 */
	/**
	 * The ID this product is known by on IVO. Must stay in lockstep with what
	 * full and single-product syncs send, or deletions zero the wrong offer.
	 */
	private function getMerchantInternalId($product) {
		if (!empty($product['_ivo_option_variant'])) {
			return (string)(isset($product['_ivo_variant_internal_id']) ? $product['_ivo_variant_internal_id'] : $product['product_id']);
		}

		return (string)(!empty($product['model']) ? $product['model'] : $product['product_id']);
	}

	private function prepareProductPayload($product, $merchantPointId, $currency) {
		$languageId = (int)$this->config->get('config_language_id');
		$isOptionVariant = !empty($product['_ivo_option_variant']);
		$variantParentId = (int)(isset($product['_ivo_variant_parent_id']) ? $product['_ivo_variant_parent_id'] : 0);
		$variantOptions = isset($product['_ivo_variant_options']) ? $product['_ivo_variant_options'] : array();
		$rawPrice = $isOptionVariant ? (float)(isset($product['_ivo_variant_price']) ? $product['_ivo_variant_price'] : $product['price']) : (float)$product['price'];
		// Sold at the running special (sale) price, otherwise the regular price
		$specialPrice = $this->getSpecialPrice($product);
		$sellingPrice = $specialPrice !== null ? $specialPrice : $rawPrice;
		$availability = $isOptionVariant ? (int)(isset($product['_ivo_variant_quantity']) ? $product['_ivo_variant_quantity'] : $product['quantity']) : (int)$product['quantity'];
		// A disabled product is not for sale in the shop, so not on IVO either
		if (isset($product['status']) && !(int)$product['status']) {
			$availability = 0;
		}
		$merchantInternalId = $this->getMerchantInternalId($product);

		// Build description: product description + attributes
		$descriptionParts = array();

		$this->load->model('catalog/product');
		$productDescriptions = $this->model_catalog_product->getProductDescriptions($product['product_id']);
		if (isset($productDescriptions[$languageId]['description'])) {
			$desc = strip_tags(html_entity_decode($productDescriptions[$languageId]['description'], ENT_QUOTES, 'UTF-8'));
			if ($desc) {
				$descriptionParts[] = $desc;
			}
		}

		$productAttributes = $this->model_catalog_product->getProductAttributes($product['product_id']);
		if (!empty($productAttributes)) {
			foreach ($productAttributes as $attributeGroup) {
				if (isset($attributeGroup['product_attribute_description'][$languageId])) {
					$attrText = isset($attributeGroup['product_attribute_description'][$languageId]['text']) ? $attributeGroup['product_attribute_description'][$languageId]['text'] : '';
					$attrName = '';
					if (!empty($attributeGroup['attribute_id'])) {
						$this->load->model('catalog/attribute');
						$attributeInfo = $this->model_catalog_attribute->getAttribute((int)$attributeGroup['attribute_id']);
						$attrName = isset($attributeInfo['name']) ? $attributeInfo['name'] : '';
					}
					if ($attrName && $attrText) {
						$descriptionParts[] = $attrName . ': ' . $attrText;
					}
				}
			}
		}

		$description = implode("\n\n", $descriptionParts);

		// Get brand (manufacturer)
		$brand = '';
		if (!empty($product['manufacturer_id'])) {
			$this->load->model('catalog/manufacturer');
			$manufacturer = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
			if ($manufacturer && !empty($manufacturer['name'])) {
				$brand = $manufacturer['name'];
			}
		}

		// Get category (with full path)
		$category = '';
		$productCategories = $this->model_catalog_product->getProductCategories($product['product_id']);
		if (!empty($productCategories)) {
			$this->load->model('catalog/category');
			$categoryPaths = array();

			foreach ($productCategories as $productCategory) {
				$categoryId = is_array($productCategory) ? (int)(isset($productCategory['category_id']) ? $productCategory['category_id'] : 0) : (int)$productCategory;
				if ($categoryId <= 0) {
					continue;
				}
				$categoryInfo = $this->model_catalog_category->getCategory($categoryId);

				if ($categoryInfo) {
					$path = $this->getCategoryPath($categoryId, $languageId);
					if ($path) {
						$categoryPaths[] = $path;
					}
				}
			}

			if (!empty($categoryPaths)) {
				usort($categoryPaths, function($a, $b) {
					return substr_count($b, '>') - substr_count($a, '>');
				});
				$category = $categoryPaths[0];
			}
		}

		$payload = array(
			'name' => $product['name'],
			'price' => $this->applyPriceModifier($sellingPrice),
			'currency' => $currency,
			'availability' => $availability,
			'merchant_point_id' => $merchantPointId,
			'merchant_internal_id' => $merchantInternalId
		);

		if ($isOptionVariant) {
			$payload['item_group_id'] = 'opencart-product-' . $variantParentId;
			$payload['item_group_title'] = isset($product['_ivo_variant_parent_name']) ? $product['_ivo_variant_parent_name'] : $product['name'];
			if (!empty($variantOptions)) {
				$payload['variant_options'] = array_values($variantOptions);
				$payload['variant_option'] = implode(' / ', $variantOptions);
			}
		}

		if ($description) {
			$payload['description'] = $description;
		}
		if ($brand) {
			$payload['brand'] = $brand;
		}
		if ($category) {
			$payload['category'] = $category;
		}

		$images = $this->getProductImages($product['product_id']);
		if (!empty($images)) {
			$payload['images'] = $images;
		}

		// While a special sells below it, the regular price goes out as the
		// recommended retail price (PRP), without the price modifier
		if ($specialPrice !== null && $rawPrice > $specialPrice) {
			$payload['retail_price'] = round($rawPrice, 2);
		}

		// Weight and package dimensions, only when set
		$payload = array_merge($payload, $this->getProductMeasures($product));

		return $payload;
	}

	/**
	 * Weight and package dimensions, each with its unit spelled out (IVO
	 * converts units itself). Option variants carry their own weight (parent
	 * weight adjusted by the selected option values); dimensions stay the
	 * parent's. Empty or zero values are left out, and the three dimensions
	 * are sent together or not at all.
	 */
	private function getProductMeasures($product) {
		$measures = array();

		$weight = $this->formatMeasure(isset($product['_ivo_variant_weight']) ? $product['_ivo_variant_weight'] : (isset($product['weight']) ? $product['weight'] : null));
		if ($weight !== null) {
			$weightUnit = $this->getMeasureUnit('weight', (int)(isset($product['weight_class_id']) ? $product['weight_class_id'] : 0));
			if ($weightUnit !== '') {
				$measures['weight'] = $weight . ' ' . $weightUnit;
			}
		}

		$length = $this->formatMeasure(isset($product['length']) ? $product['length'] : null);
		$width = $this->formatMeasure(isset($product['width']) ? $product['width'] : null);
		$height = $this->formatMeasure(isset($product['height']) ? $product['height'] : null);
		if ($length !== null && $width !== null && $height !== null) {
			$lengthUnit = $this->getMeasureUnit('length', (int)(isset($product['length_class_id']) ? $product['length_class_id'] : 0));
			if ($lengthUnit !== '') {
				$measures['length'] = $length . ' ' . $lengthUnit;
				$measures['width'] = $width . ' ' . $lengthUnit;
				$measures['height'] = $height . ' ' . $lengthUnit;
			}
		}

		return $measures;
	}

	/**
	 * Positive measure as a plain decimal string; null when empty, zero or not numeric
	 */
	private function formatMeasure($value) {
		if (!is_numeric($value)) {
			return null;
		}
		$value = round((float)$value, 4);
		if ($value <= 0) {
			return null;
		}
		return rtrim(rtrim(number_format($value, 4, '.', ''), '0'), '.');
	}

	/**
	 * IVO unit (kg, g, lbs, oz / mm, cm, m, in) of a weight or length class,
	 * read from the class's unit and title; '' when it is not recognised.
	 * A product without a class uses the store default.
	 */
	private function getMeasureUnit($type, $classId) {
		if ($classId <= 0) {
			$classId = (int)$this->config->get('config_' . $type . '_class_id');
		}

		if (!isset($this->measureUnits[$type][$classId])) {
			$class = array();
			if ($classId > 0) {
				if ($type === 'weight') {
					$this->load->model('localisation/weight_class');
					$class = $this->model_localisation_weight_class->getWeightClass($classId);
				} else {
					$this->load->model('localisation/length_class');
					$class = $this->model_localisation_length_class->getLengthClass($classId);
				}
			}

			$units = $type === 'weight'
				? array('kg' => 'kg', 'kgs' => 'kg', 'kilogram' => 'kg', 'kilograms' => 'kg', 'кг' => 'kg', 'килограмм' => 'kg',
					'g' => 'g', 'gr' => 'g', 'gram' => 'g', 'grams' => 'g', 'г' => 'g', 'гр' => 'g', 'грамм' => 'g',
					'lb' => 'lbs', 'lbs' => 'lbs', 'pound' => 'lbs', 'pounds' => 'lbs', 'фунт' => 'lbs',
					'oz' => 'oz', 'ounce' => 'oz', 'ounces' => 'oz', 'унция' => 'oz')
				: array('mm' => 'mm', 'millimeter' => 'mm', 'millimetre' => 'mm', 'milimetru' => 'mm', 'мм' => 'mm', 'миллиметр' => 'mm',
					'cm' => 'cm', 'centimeter' => 'cm', 'centimetre' => 'cm', 'centimetru' => 'cm', 'см' => 'cm', 'сантиметр' => 'cm',
					'm' => 'm', 'meter' => 'm', 'metre' => 'm', 'metru' => 'm', 'м' => 'm', 'метр' => 'm',
					'in' => 'in', 'inch' => 'in', 'inches' => 'in', 'дюйм' => 'in');

			$unit = '';
			foreach (array(isset($class['unit']) ? $class['unit'] : '', isset($class['title']) ? $class['title'] : '') as $name) {
				$name = utf8_strtolower(trim(rtrim(trim((string)$name), '.')));
				if (isset($units[$name])) {
					$unit = $units[$name];
					break;
				}
			}
			$this->measureUnits[$type][$classId] = $unit;
		}

		return $this->measureUnits[$type][$classId];
	}

	/**
	 * Apply price modifier
	 */
	private function applyPriceModifier($price) {
		$modifier = (float)($this->config->get('module_ivo_marketplace_price_modifier') ? $this->config->get('module_ivo_marketplace_price_modifier') : 0);
		if ($modifier === 0.0) {
			return $price;
		}
		$adjustedPrice = $price * (1 + ($modifier / 100));
		return round(max(0.0, $adjustedPrice), 2);
	}

	/**
	 * Price while a special (sale) runs for the product, or null when none
	 * does. The special replaces the base price and option deltas stay on top
	 * of it, the way the cart charges them.
	 */
	private function getSpecialPrice($product) {
		$special = $this->getActiveSpecial((int)$product['product_id']);

		// A special at zero or below would list the product on IVO for free
		if ($special === null || $special <= 0) {
			return null;
		}

		return max(0.0, $special + (float)(isset($product['_ivo_variant_price_delta']) ? $product['_ivo_variant_price_delta'] : 0));
	}

	/**
	 * Price of the special running now for the store's default customer
	 * group, chosen the way the storefront chooses it: start/end dates open or
	 * current, lowest priority, then lowest price.
	 */
	private function getActiveSpecial($productId) {
		if (!array_key_exists($productId, $this->activeSpecials)) {
			$query = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$productId . "' AND `customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((`date_start` = '0000-00-00' OR `date_start` < NOW()) AND (`date_end` = '0000-00-00' OR `date_end` > NOW())) ORDER BY `priority` ASC, `price` ASC LIMIT 1");
			$this->activeSpecials[$productId] = $query->num_rows ? (float)$query->row['price'] : null;
		}

		return $this->activeSpecials[$productId];
	}

	/**
	 * Run full products synchronization
	 */
	/**
	 * One slice of a full sync: the next products by id after $afterProductId,
	 * expanded into the payloads IVO receives and sent as one batch.
	 *
	 * The page walks the catalogue slice by slice, so no request runs anywhere
	 * near a shop's PHP or proxy timeout (often 30 s); a whole catalogue in one
	 * request was cut off on 585.md. Every slice carries the same run id and
	 * the last one closes the run, so IVO zeroes what the run never mentioned.
	 * A failed slice stops the walk before that, so a partial run never zeroes
	 * products that merely did not arrive. Paging by product id, not offset,
	 * keeps a product added or deleted mid-run from shifting the pages and
	 * skipping a neighbour.
	 *
	 * Nothing is sent with force_reprocess: that made IVO reset every row and
	 * wait for its import pipeline before writing any stock, so a Force Sync
	 * changed no availability. Products IVO already has get their stock on the
	 * spot; only new ones go through the import.
	 */
	private function syncSlice($afterProductId, $runId, $merchantPointIdOverride = null) {
		$this->lastSyncError = '';
		$merchantPointId = $merchantPointIdOverride ? $merchantPointIdOverride : $this->getMerchantPointId();
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		if (!$merchantPointId || !$apiKey) {
			$this->lastSyncError = $this->merchantPointError();
			return false;
		}

		if ($runId === '') {
			$runId = 'oc3_' . time() . '_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 12);
		}

		// The products the admin catalogue lists (getProducts reads the same)
		$languageId = (int)$this->config->get('config_language_id');
		$from = " FROM `" . DB_PREFIX . "product` p LEFT JOIN `" . DB_PREFIX . "product_description` pd ON (p.`product_id` = pd.`product_id`) WHERE pd.`language_id` = '" . $languageId . "'";
		$query = $this->db->query("SELECT *" . $from . " AND p.`product_id` > '" . (int)$afterProductId . "' ORDER BY p.`product_id` ASC LIMIT " . (int)self::SYNC_SLICE_PRODUCTS);

		$this->load->model('catalog/product');
		$currency = $this->config->get('config_currency');
		$payloads = array();
		$after = (int)$afterProductId;
		$consumed = 0;

		foreach ($query->rows as $product) {
			$after = (int)$product['product_id'];
			$consumed++;

			foreach ($this->expandProductForSync($product) as $item) {
				$payload = $this->prepareProductPayload($item, $merchantPointId, $currency);
				if (!$this->isValidSyncPayload($payload)) {
					$identifier = isset($payload['merchant_internal_id']) ? $payload['merchant_internal_id'] : $product['product_id'];
					$this->log->write('IVO Marketplace: Skipping invalid sync payload for product ' . $identifier . ' (a non-empty name and price >= 0.01 are required)');
					continue;
				}
				$payloads[] = $payload;
			}

			if (count($payloads) >= self::SYNC_SLICE_PAYLOADS) {
				break;
			}
		}

		// One product can have more option combinations than IVO takes in one call
		foreach (array_chunk($payloads, 100) as $batch) {
			if (!$this->syncProductBatch($batch, $apiKey, $runId)) {
				return false;
			}
		}

		$done = $consumed === count($query->rows) && count($query->rows) < self::SYNC_SLICE_PRODUCTS;
		if ($done) {
			$this->completeSyncRun($runId, $apiKey);
		}

		$position = $this->db->query("SELECT COUNT(*) AS total" . $from . " AND p.`product_id` <= '" . $after . "'");
		$total = $this->db->query("SELECT COUNT(*) AS total" . $from);

		return array(
			'done' => $done,
			'after' => $after,
			'run_id' => $runId,
			'position' => (int)$position->row['total'],
			'total' => (int)$total->row['total'],
		);
	}

	/**
	 * Close a full-sync run: products IVO knows from this store that were NOT
	 * part of the run no longer exist here, so their offers go out of stock.
	 */
	private function completeSyncRun($runId, $apiKey) {
		$payload = array(
			'import_name' => 'api_sync_import_opencart',
			'integration_run_id' => $runId
		);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/product/complete-run');
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Authorization: Bearer ' . $apiKey,
			'X-IVO-Plugin: opencart3/' . self::VERSION,
			'Accept: application/json',
			'Content-Type: application/json'
		));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($httpCode < 200 || $httpCode >= 300) {
			$this->log->write('IVO Marketplace Complete Run Failed: HTTP ' . $httpCode . ' response=' . (string)$response);
		}
	}

	private function isValidSyncPayload($payload) {
		return is_array($payload)
			&& isset($payload['name'])
			&& is_string($payload['name'])
			&& trim($payload['name']) !== ''
			&& isset($payload['price'])
			&& is_numeric($payload['price'])
			&& (float)$payload['price'] >= 0.01;
	}

	/**
	 * What one catalogue product sends to IVO: its option combinations, or the
	 * product itself. OpenCart 3 has no master/variant products.
	 */
	private function expandProductForSync($product) {
		if ((int)(isset($product['product_id']) ? $product['product_id'] : 0) <= 0) {
			return array();
		}

		$variants = $this->getOptionVariantProducts($product);

		return !empty($variants) ? $variants : array($product);
	}

	private function getOptionVariantProducts($product) {
		$productId = (int)(isset($product['product_id']) ? $product['product_id'] : 0);
		if ($productId <= 0) {
			return array();
		}

		$languageId = (int)$this->config->get('config_language_id');
		$query = $this->db->query("SELECT pov.*, od.`name` AS option_name, ovd.`name` AS value_name FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "product_option` po ON (po.`product_option_id` = pov.`product_option_id`) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (od.`option_id` = pov.`option_id` AND od.`language_id` = '" . (int)$languageId . "') LEFT JOIN `" . DB_PREFIX . "option_value` ov ON (ov.`option_value_id` = pov.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value_description` ovd ON (ovd.`option_value_id` = pov.`option_value_id` AND ovd.`language_id` = '" . (int)$languageId . "') LEFT JOIN `" . DB_PREFIX . "option` o ON (o.`option_id` = pov.`option_id`) WHERE pov.`product_id` = '" . (int)$productId . "' AND o.`type` IN ('select', 'radio', 'checkbox', 'image') ORDER BY po.`product_option_id` ASC, ov.`sort_order` ASC, pov.`product_option_value_id` ASC");
		if (empty($query->rows)) {
			return array();
		}

		$groups = array();
		foreach ($query->rows as $row) {
			$groupKey = (int)$row['product_option_id'];
			$groups[$groupKey][] = $row;
		}

		$combinations = array(array());
		foreach ($groups as $values) {
			$next = array();
			foreach ($combinations as $combo) {
				foreach ($values as $value) {
					$next[] = array_merge($combo, array($value));
				}
			}
			$combinations = $next;
		}

		$variants = array();
		foreach ($combinations as $combo) {
			$variant = $product;
			$price = (float)$product['price'];
			$weight = (float)(isset($product['weight']) ? $product['weight'] : 0);
			$trackedQuantities = array();
			$labels = array();
			$valueIds = array();

			foreach ($combo as $value) {
				$optionName = trim((string)(isset($value['option_name']) ? $value['option_name'] : ''));
				$valueName = trim((string)(isset($value['value_name']) ? $value['value_name'] : ''));
				$labels[] = trim(($optionName ? $optionName . ': ' : '') . $valueName);
				$valueIds[] = (int)$value['product_option_value_id'];

				$delta = (float)(isset($value['price']) ? $value['price'] : 0);
				if ((isset($value['price_prefix']) ? $value['price_prefix'] : '+') === '-') {
					$price -= $delta;
				} else {
					$price += $delta;
				}
				// Option value weight is in the product's weight class
				$weightDelta = (float)(isset($value['weight']) ? $value['weight'] : 0);
				if ((isset($value['weight_prefix']) ? $value['weight_prefix'] : '+') === '-') {
					$weight -= $weightDelta;
				} else {
					$weight += $weightDelta;
				}
				// The option value's own quantity is the variant's stock, subtract
				// or not, even at 0: in OpenCart the variant's availability wins
				// over the product's.
				$trackedQuantities[] = max(0, (int)(isset($value['quantity']) ? $value['quantity'] : 0));
			}

			$variant['_ivo_option_variant'] = true;
			$variant['_ivo_variant_parent_id'] = $productId;
			$variant['_ivo_variant_parent_name'] = $product['name'];
			$variant['_ivo_variant_options'] = array_values(array_filter($labels));
			$variant['_ivo_variant_price'] = max(0.0, $price);
			// The option deltas alone, for when a special replaces the base price
			$variant['_ivo_variant_price_delta'] = $price - (float)$product['price'];
			$variant['_ivo_variant_weight'] = max(0.0, $weight);
			// The variant's stock is its scarcest option value's. Once the product
			// itself is out (a piece sold on the store drops it to 0 while sizes
			// without subtract keep their numbers), every size is out.
			$variant['_ivo_variant_quantity'] = (int)$product['quantity'] > 0 ? min($trackedQuantities) : 0;
			$variant['_ivo_variant_internal_id'] = $productId . '-' . implode('-', $valueIds);
			if (!empty($variant['_ivo_variant_options'])) {
				$variant['name'] = $product['name'] . ' - ' . implode(' / ', $variant['_ivo_variant_options']);
			}

			$variants[] = $variant;
		}

		return $variants;
	}

	private function syncProductBatch($productsPayload, $apiKey, $integrationRunId = null) {
		$result = $this->syncProducts($productsPayload, $apiKey, 'async', $integrationRunId);
		$code = (int)(isset($result['code']) ? $result['code'] : 0);
		if ($code >= 200 && $code < 300) {
			return true;
		}

		$response = isset($result['response']) ? $result['response'] : array();
		$message = is_array($response) ? (isset($response['message']) ? $response['message'] : (isset($response['error']) ? $response['error'] : '')) : '';
		$details = $this->formatSyncValidationDetails($response, $productsPayload);
		$this->lastSyncError = sprintf($this->language->get('error_sync_failed'), $code);
		if ($message) {
			$this->lastSyncError .= ' ' . $message;
		}
		if ($details) {
			$this->lastSyncError .= ' — ' . $details;
		}
		$this->log->write('IVO Marketplace Sync Batch Failed: HTTP ' . $code . ' response=' . json_encode($response));
		return false;
	}

	private function formatSyncValidationDetails($response, $productsPayload) {
		if (!is_array($response)) {
			return '';
		}

		$parts = array();
		if (isset($response['index'])) {
			$index = (int)$response['index'];
			$label = 'batch item #' . ($index + 1);
			if (isset($productsPayload[$index]) && is_array($productsPayload[$index])) {
				$product = $productsPayload[$index];
				$identifier = isset($product['merchant_internal_id']) ? trim((string)$product['merchant_internal_id']) : '';
				$name = isset($product['name']) ? trim((string)$product['name']) : '';
				if ($identifier !== '') {
					$label = 'product ' . $identifier;
				} elseif ($name !== '') {
					$label = 'product "' . $name . '"';
				}
			}
			$parts[] = $label;
		}

		if (isset($response['errors']) && is_array($response['errors'])) {
			foreach ($response['errors'] as $field => $messages) {
				if (!is_array($messages)) {
					$messages = array($messages);
				}
				$messages = array_values(array_filter(array_map('strval', $messages)));
				if (!empty($messages)) {
					$parts[] = $field . ': ' . implode(', ', $messages);
				}
			}
		}

		return implode('; ', $parts);
	}

	/**
	 * Get product images (main + additional). Returns array of full image URLs.
	 */
	private function getProductImages($productId) {
		$images = array();

		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);

		if (!empty($product['image'])) {
			$images[] = $this->getImageUrl($product['image']);
		}

		$productImages = $this->model_catalog_product->getProductImages($productId);
		foreach ($productImages as $productImage) {
			if (!empty($productImage['image'])) {
				$url = $this->getImageUrl($productImage['image']);
				if ($url && !in_array($url, $images)) {
					$images[] = $url;
				}
			}
		}

		return array_values(array_filter($images));
	}

	private function getImageUrl($imagePath) {
		if (empty($imagePath) || $imagePath === 'no_image.png') {
			return '';
		}

		$baseUrl = $this->config->get('config_url') ? $this->config->get('config_url') : HTTP_CATALOG;
		return rtrim($baseUrl, '/') . '/image/' . $imagePath;
	}

	/**
	 * Get full category path (Parent > Child > Grandchild)
	 */
	private function getCategoryPath($categoryId, $languageId) {
		$this->load->model('catalog/category');

		$path = array();
		$currentId = $categoryId;

		for ($i = 0; $i < 10 && $currentId > 0; $i++) {
			$category = $this->model_catalog_category->getCategory($currentId);
			if (!$category) {
				break;
			}

			$descriptions = $this->model_catalog_category->getCategoryDescriptions($currentId);
			$name = isset($descriptions[$languageId]['name']) ? $descriptions[$languageId]['name'] : (isset($category['name']) ? $category['name'] : '');

			if ($name) {
				array_unshift($path, $name);
			}

			$currentId = (int)(isset($category['parent_id']) ? $category['parent_id'] : 0);
		}

		return implode(' > ', $path);
	}

	/**
	 * Send products to IVO API
	 */
	private function syncProducts($productsData, $apiKey, $mode = 'async', $integrationRunId = null) {
		$payload = array(
			'mode' => $mode,
			'import_name' => 'api_sync_import_opencart',
			'products' => $productsData
		);
		if ($integrationRunId) {
			$payload['integration_run_id'] = $integrationRunId;
		}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->apiBaseUrl . '/v1/merchant-api/product/sync-multiple');
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Authorization: Bearer ' . $apiKey,
			'X-IVO-Plugin: opencart3/' . self::VERSION,
			'Accept: application/json',
			'Content-Type: application/json'
		));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);

		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		return array('code' => $httpCode, 'response' => json_decode($response, true));
	}

	/**
	 * Get product IVO status (for product edit page tab)
	 */
	public function getProductStatus() {
		$this->load->language('extension/module/ivo_marketplace');

		$json = array();

		$productId = isset($this->request->get['product_id']) ? $this->request->get['product_id'] : null;

		if (!$productId) {
			$json['error'] = 'Product ID required';
		} else {
			$apiKey = $this->config->get('module_ivo_marketplace_api_key');

			if (!$apiKey) {
				$json['error'] = $this->language->get('text_not_configured');
			} else {
				$this->load->model('catalog/product');
				$product = $this->model_catalog_product->getProduct($productId);

				if ($product) {
					$sku = $product['model'] ? $product['model'] : (string)$productId;

					$ivoData = $this->getProductInfoFromIvo($sku, $apiKey);

					if ($ivoData && isset($ivoData['status']) && $ivoData['status'] === 'success' && isset($ivoData['product'])) {
						$json['status'] = 'success';
						$json['name'] = isset($ivoData['product']['name']) ? $ivoData['product']['name'] : array();
						$json['urls'] = isset($ivoData['product']['urls']) ? $ivoData['product']['urls'] : array();
						$json['url'] = isset($ivoData['product']['url']) ? $ivoData['product']['url'] : '';
					} else if ($ivoData && isset($ivoData['status']) && $ivoData['status'] === 'error' && isset($ivoData['message'])) {
						$json['status'] = 'error';
						$json['message'] = $ivoData['message'];
					} else {
						$json['status'] = 'error';
						$json['message'] = 'not_imported';
					}
				} else {
					$json['error'] = 'Product not found';
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Sync a single product to IVO (from product edit page)
	 */
	public function syncProduct() {
		$this->load->language('extension/module/ivo_marketplace');

		$json = array();

		$productId = isset($this->request->get['product_id']) ? $this->request->get['product_id'] : null;

		if (!$productId) {
			$json['error'] = 'Product ID required';
		} else if (!$this->user->hasPermission('modify', 'extension/module/ivo_marketplace')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			$apiKey = $this->config->get('module_ivo_marketplace_api_key');
			$merchantPointId = $this->getMerchantPointId();

			if (!$apiKey || !$merchantPointId) {
				$json['error'] = $this->merchantPointError();
			} else {
				$this->load->model('catalog/product');
				$product = $this->model_catalog_product->getProduct($productId);

				if ($product) {
					$currency = $this->config->get('config_currency');

					if ((float)$product['price'] < 0.01) {
						$json['error'] = $this->language->get('error_no_price');
					} else {
						$productsData = array();
						foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
							$productsData[] = $this->prepareProductPayload($syncProduct, $merchantPointId, $currency);
						}

						$result = $this->syncProducts($productsData, $apiKey);

						if ($result['code'] >= 200 && $result['code'] < 300) {
							$json['success'] = $this->language->get('text_product_synced');
						} else {
							$json['error'] = sprintf($this->language->get('error_sync_failed'), $result['code']);
						}
					}
				} else {
					$json['error'] = 'Product not found';
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function getProductAndVariantsForSync($product) {
		$productId = (int)(isset($product['product_id']) ? $product['product_id'] : 0);

		if ($productId > 0) {
			$variants = $this->getOptionVariantProducts($product);
			if (!empty($variants)) {
				return $variants;
			}
		}

		return $productId > 0 ? array($product) : array();
	}

	/**
	 * Get product info from IVO by SKU
	 */
	private function getProductInfoFromIvo($sku, $apiKey) {
		$payload = array(
			'import_name' => 'api_sync_import_opencart',
			'merchant_internal_id' => $sku
		);

		$url = $this->apiBaseUrl . '/v1/merchant-api/product/info-by-sku';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Authorization: Bearer ' . $apiKey,
			'X-IVO-Plugin: opencart3/' . self::VERSION,
			'Accept: application/json',
			'Content-Type: application/json'
		));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);

		$response = curl_exec($ch);
		curl_close($ch);

		if ($response) {
			return json_decode($response, true);
		}

		return null;
	}

	/**
	 * Install the module - register permissions and events
	 */
	public function install() {
		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/ivo_marketplace');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/ivo_marketplace');

		$this->load->model('setting/event');

		// Remove any stale events first (idempotent install)
		$this->uninstall();

		// NOTE: OpenCart 3 stores event triggers with the application prefix
		// (admin/ or catalog/). The startup/event controller strips that prefix
		// before registering, so the trigger matched at runtime is unprefixed.

		// Add IVO Marketplace to the admin menu (view/before so $data['menus'] is mutable)
		$this->model_setting_event->addEvent('ivo_marketplace_menu', 'admin/view/common/column_left/before', 'extension/module/ivo_marketplace/eventColumnLeft', 1, 0);

		// Sync product on edit
		$this->model_setting_event->addEvent('ivo_marketplace_product_save', 'admin/model/catalog/product/editProduct/after', 'extension/module/ivo_marketplace/eventProductSave', 1, 1);

		// Sync product on create
		$this->model_setting_event->addEvent('ivo_marketplace_product_add', 'admin/model/catalog/product/addProduct/after', 'extension/module/ivo_marketplace/eventProductAdd', 1, 1);

		// Configuration notification banner
		$this->model_setting_event->addEvent('ivo_marketplace_admin_notification', 'admin/view/common/header/after', 'extension/module/ivo_marketplace/eventAdminNotification', 1, 0);

		// Product edit page tab
		$this->model_setting_event->addEvent('ivo_marketplace_product_tab', 'admin/view/catalog/product_form/after', 'extension/module/ivo_marketplace/eventProductTab', 1, 1);

		// Order completion (storefront) -> sync stock to IVO
		$this->model_setting_event->addEvent('ivo_marketplace_order_complete', 'catalog/model/checkout/order/addOrder/after', 'extension/module/ivo_marketplace_order/eventOrderComplete', 1, 1);

		// Product delete -> zero stock on IVO (/before, so the product and its
		// variants can still be read for their internal IDs)
		$this->model_setting_event->addEvent('ivo_marketplace_product_delete', 'admin/model/catalog/product/deleteProduct/before', 'extension/module/ivo_marketplace/eventProductDelete', 1, 1);

		// Storefront traffic walks the catalogue's stock to IVO (stock changed
		// outside the product form fires no event)
		$this->model_setting_event->addEvent('ivo_marketplace_stock_sync', 'catalog/controller/common/footer/after', 'extension/module/ivo_marketplace_stock/sync', 1, 0);
	}

	/**
	 * Installs added after the first release miss events that install() has
	 * since learned to register, and an upgrade by zip never runs install()
	 * again. Re-checked on every admin page (see eventColumnLeft), so an
	 * upgraded extension heals itself without a reinstall.
	 */
	private function ensureEventsRegistered() {
		static $checked = false;
		if ($checked) {
			return;
		}
		$checked = true;

		$events = array(
			'ivo_marketplace_product_delete' => array('admin/model/catalog/product/deleteProduct/before', 'extension/module/ivo_marketplace/eventProductDelete', 1),
			'ivo_marketplace_stock_sync' => array('catalog/controller/common/footer/after', 'extension/module/ivo_marketplace_stock/sync', 0)
		);

		$query = $this->db->query("SELECT `code` FROM `" . DB_PREFIX . "event` WHERE `code` IN ('" . implode("', '", array_keys($events)) . "')");
		$present = array();
		foreach ($query->rows as $row) {
			$present[$row['code']] = true;
		}

		$this->load->model('setting/event');
		foreach ($events as $code => $event) {
			if (!isset($present[$code])) {
				$this->model_setting_event->addEvent($code, $event[0], $event[1], 1, $event[2]);
			}
		}
	}

	/**
	 * Uninstall the module - remove events
	 */
	public function uninstall() {
		$this->load->model('setting/event');

		$this->model_setting_event->deleteEventByCode('ivo_marketplace_menu');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_save');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_add');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_admin_notification');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_tab');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_order_complete');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_product_delete');
		$this->model_setting_event->deleteEventByCode('ivo_marketplace_stock_sync');
	}

	/**
	 * Event: add IVO Marketplace item into the admin Marketing menu
	 */
	public function eventColumnLeft(&$route, &$data) {
		$this->ensureEventsRegistered();

		if (!isset($data['menus']) || !is_array($data['menus'])) {
			return;
		}

		if (!$this->user->hasPermission('access', 'extension/module/ivo_marketplace')) {
			return;
		}

		$this->load->language('extension/module/ivo_marketplace');

		foreach ($data['menus'] as &$menu) {
			if (isset($menu['id']) && $menu['id'] == 'menu-marketing') {
				$menu['children'][] = array(
					'name'     => $this->language->get('heading_title'),
					'href'     => $this->url->link('extension/module/ivo_marketplace', 'user_token=' . $this->session->data['user_token'], true),
					'children' => array()
				);
				break;
			}
		}
		unset($menu);
	}

	/**
	 * Event: Sync product when created
	 */
	public function eventProductAdd(&$route, &$args, &$output) {
		// A store with an API key pushes. The status setting is not consulted:
		// saving the settings once deleted it and silently stopped every push.
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		$merchantPointId = $this->getMerchantPointId();

		if (!$apiKey || !$merchantPointId) {
			return;
		}

		$productId = $output ? $output : null;
		if (!$productId) {
			return;
		}

		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);

		if (!$product) {
			return;
		}

		$currency = $this->config->get('config_currency');

		// Expand variants (option combinations) so the product is synced as a
		// main product + variants group, not as a single stand-alone product.
		$productsData = array();
		foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
			$payload = $this->prepareProductPayload($syncProduct, $merchantPointId, $currency);
			if ($this->isValidSyncPayload($payload)) {
				$productsData[] = $payload;
			}
		}

		// At most 100 per call (IVO's limit); a rejected push is logged, not dropped
		foreach (array_chunk($productsData, 100) as $batch) {
			$this->syncProductBatch($batch, $apiKey);
		}
	}

	/**
	 * Event: Sync product when saved
	 */
	public function eventProductSave(&$route, &$args, &$output) {
		// A store with an API key pushes. The status setting is not consulted:
		// saving the settings once deleted it and silently stopped every push.
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		$merchantPointId = $this->getMerchantPointId();

		if (!$apiKey || !$merchantPointId) {
			return;
		}

		$productId = isset($args[0]) ? $args[0] : null;
		if (!$productId) {
			return;
		}

		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);

		if (!$product) {
			return;
		}

		$currency = $this->config->get('config_currency');

		// Expand variants (option combinations) so the product is synced as a
		// main product + variants group, not as a single stand-alone product.
		$productsData = array();
		foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
			$payload = $this->prepareProductPayload($syncProduct, $merchantPointId, $currency);
			if ($this->isValidSyncPayload($payload)) {
				$productsData[] = $payload;
			}
		}

		// At most 100 per call (IVO's limit); a rejected push is logged, not dropped
		foreach (array_chunk($productsData, 100) as $batch) {
			$this->syncProductBatch($batch, $apiKey);
		}
	}

	/**
	 * Event: Zero stock on IVO when a product is deleted.
	 *
	 * Fires on deleteProduct/BEFORE: the product and its option variants are
	 * still readable, so their merchant internal IDs can be collected. The
	 * push is availability-only — the server updates rows and offers it
	 * already knows and never creates anything from it.
	 */
	public function eventProductDelete(&$route, &$args, &$output = null) {
		// A store with an API key pushes. The status setting is not consulted:
		// saving the settings once deleted it and silently stopped every push.
		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		$merchantPointId = $this->getMerchantPointId();

		if (!$apiKey || !$merchantPointId) {
			return;
		}

		$productId = isset($args[0]) ? (int)$args[0] : 0;
		if ($productId <= 0) {
			return;
		}

		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($productId);

		if (!$product) {
			return;
		}

		$internalIds = array();
		foreach ($this->getProductAndVariantsForSync($product) as $syncProduct) {
			$internalIds[] = $this->getMerchantInternalId($syncProduct);
		}
		$internalIds[] = $this->getMerchantInternalId($product);

		$productsData = array();
		foreach (array_unique(array_filter($internalIds)) as $internalId) {
			$productsData[] = array(
				'availability_only' => true,
				'availability' => 0,
				'merchant_internal_id' => $internalId,
				'merchant_point_id' => $merchantPointId
			);
		}

		if (empty($productsData)) {
			return;
		}

		$this->syncProducts($productsData, $apiKey);
	}

	/**
	 * Event: Show notification on admin pages if not configured
	 */
	public function eventAdminNotification(&$route, &$data, &$output) {
		if (isset($this->request->get['route']) && strpos($this->request->get['route'], 'ivo_marketplace') !== false) {
			return;
		}

		if (!empty($this->request->server['HTTP_X_REQUESTED_WITH']) &&
			strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			return;
		}

		$apiKey = $this->config->get('module_ivo_marketplace_api_key');

		if (!$apiKey) {
			$this->load->language('extension/module/ivo_marketplace');

			$configureUrl = $this->url->link('extension/module/ivo_marketplace', 'user_token=' . $this->session->data['user_token'], true);
			$message = $this->language->get('text_please_configure');
			$configureText = $this->language->get('button_configure');

			$notification = '
			<script>
			document.addEventListener("DOMContentLoaded", function() {
				var content = document.getElementById("content");
				if (content) {
					var alert = document.createElement("div");
					alert.className = "alert alert-warning alert-dismissible";
					alert.style.margin = "15px";
					alert.style.marginBottom = "0";
					alert.innerHTML = \'<i class="fa fa-exclamation-triangle"></i> <strong>IVO Marketplace:</strong> ' . addslashes($message) . ' <a href="' . $configureUrl . '" class="alert-link">' . $configureText . '</a> <button type="button" class="close" data-dismiss="alert">&times;</button>\';
					content.insertBefore(alert, content.firstChild);
				}
			});
			</script>';

			$output = $output . $notification;
		}
	}

	/**
	 * Event: Add IVO tab to product edit page (Bootstrap 3 markup)
	 */
	public function eventProductTab(&$route, &$data, &$output) {
		if (!isset($this->request->get['product_id'])) {
			return;
		}

		$apiKey = $this->config->get('module_ivo_marketplace_api_key');
		if (!$apiKey) {
			return;
		}

		$this->load->language('extension/module/ivo_marketplace');

		$productId = $this->request->get['product_id'];
		$statusUrl = html_entity_decode($this->url->link('extension/module/ivo_marketplace/getProductStatus', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $productId, true), ENT_QUOTES, 'UTF-8');
		$syncUrl = html_entity_decode($this->url->link('extension/module/ivo_marketplace/syncProduct', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $productId, true), ENT_QUOTES, 'UTF-8');

		$tabTitle = $this->language->get('tab_ivo_marketplace');
		$textLoading = $this->language->get('text_loading');
		$textViewOnIvo = $this->language->get('text_view_on_ivo');
		$textProductVisible = $this->language->get('text_product_visible');
		$textConnectionError = $this->language->get('text_connection_error');
		$buttonForceSync = $this->language->get('button_force_sync');
		$textSyncing = $this->language->get('text_syncing');
		$adminLang = substr((string)$this->config->get('config_admin_language'), 0, 2);

		// Tab link + content (Bootstrap 3)
		$tabLink = '<li><a href="#tab-ivo" data-toggle="tab"><i class="fa fa-shopping-cart"></i> ' . $tabTitle . '</a></li>';

		$tabContent = '
		<div class="tab-pane" id="tab-ivo">
			<div id="ivo-status-container" style="padding: 15px; background: #f8f8f8; border: 1px solid #d1d1d1; border-radius: 5px;">
				<div id="ivo-loading" class="text-center" style="padding: 20px;">
					<i class="fa fa-spinner fa-spin fa-2x"></i>
					<p style="margin-top:10px;">' . $textLoading . '</p>
				</div>
				<div id="ivo-status-content" style="display:none;">
					<h3 id="ivo-status-header" style="margin-top:0"></h3>
					<p id="ivo-status-description"></p>
					<div id="ivo-view-btn-container" style="display:none; margin-top:15px;">
						<a id="ivo-product-url" href="#" target="_blank" style="background-color:#eb5202;color:white;padding:10px 20px;text-decoration:none;border-radius:3px;font-weight:bold;display:inline-block;">' . $textViewOnIvo . '</a>
					</div>
				</div>
				<div id="ivo-error" class="alert alert-danger" style="display:none;"></div>
				<div style="margin-top:15px; padding-top:10px; border-top:1px dashed #ccc;">
					<button type="button" id="btn-ivo-sync" class="btn btn-default"><i class="fa fa-refresh"></i> ' . $buttonForceSync . '</button>
					<span id="ivo-sync-status" style="margin-left:10px; font-weight:bold;"></span>
				</div>
			</div>
		</div>';

		$script = '
		<script>
		$(document).ready(function() {
			var statusUrl = ' . json_encode($statusUrl) . ';
			var syncUrl = ' . json_encode($syncUrl) . ';
			var adminLang = ' . json_encode($adminLang) . ';
			var loaded = false;

			var messageDescriptions = {
				"not_imported": ' . json_encode($this->language->get('text_not_imported')) . ',
				"queued": ' . json_encode($this->language->get('text_queued')) . ',
				"processing": ' . json_encode($this->language->get('text_processing')) . ',
				"pending_approval": ' . json_encode($this->language->get('text_pending_approval')) . ',
				"import_error": ' . json_encode($this->language->get('text_import_error')) . ',
				"skipped_no_match": ' . json_encode($this->language->get('text_too_generic')) . ',
				"too_generic": ' . json_encode($this->language->get('text_too_generic')) . ',
				"unauthorized_category": ' . json_encode($this->language->get('text_not_authorized')) . ',
				"offer_deleted": ' . json_encode($this->language->get('text_offer_deleted')) . ',
				"offer_not_found": ' . json_encode($this->language->get('text_not_synced')) . '
			};

			$(\'a[href="#tab-ivo"]\').on("shown.bs.tab", function() {
				if (!loaded) { loadIvoStatus(); loaded = true; }
			});

			function loadIvoStatus() {
				$.ajax({
					url: statusUrl, type: "GET", dataType: "json",
					success: function(json) {
						$("#ivo-loading").hide();
						if (json.error) {
							$("#ivo-error").html(json.error).show();
							$("#ivo-status-content").show();
							return;
						}
						$("#ivo-status-content").show();
						if (json.status === "success") {
							$("#ivo-status-header").html(' . json_encode($this->language->get('text_status')) . ' + \': <span style="font-weight:bold;color:#28a745;">' . addslashes($this->language->get('text_status_active')) . '</span>\');
							$("#ivo-status-description").html(' . json_encode($textProductVisible) . ');
							var targetUrl = null, btnText = ' . json_encode($textViewOnIvo) . ';
							if (json.urls && json.urls[adminLang]) { targetUrl = json.urls[adminLang]; btnText += " (" + adminLang.toUpperCase() + ")"; }
							else if (json.urls && json.urls["en"]) { targetUrl = json.urls["en"]; btnText += " (EN)"; }
							else if (json.url) { targetUrl = json.url; }
							if (targetUrl) { $("#ivo-product-url").attr("href", targetUrl).html(btnText); $("#ivo-view-btn-container").show(); }
						} else {
							var message = json.message || "unknown";
							var color = "#dc3545", statusLabel = ' . json_encode($this->language->get('text_status_error')) . ';
							if (message === "queued" || message === "processing" || message === "pending_approval") { color = "#ffc107"; statusLabel = ' . json_encode($this->language->get('text_status_pending')) . '; }
							else if (message === "not_imported") { color = "#6c757d"; statusLabel = ' . json_encode($this->language->get('text_status_not_synced')) . '; }
							$("#ivo-status-header").html(' . json_encode($this->language->get('text_status')) . ' + \': <span style="font-weight:bold;color:\' + color + \';">\' + statusLabel + \'</span>\');
							$("#ivo-status-description").html(messageDescriptions[message] || (' . json_encode($this->language->get('text_unknown_status')) . ' + ": " + message));
						}
					},
					error: function() {
						$("#ivo-loading").hide();
						$("#ivo-error").html(' . json_encode($textConnectionError) . ').show();
					}
				});
			}

			$("#btn-ivo-sync").on("click", function() {
				var btn = $(this);
				btn.prop("disabled", true).html(\'<i class="fa fa-spinner fa-spin"></i> ' . addslashes($textSyncing) . '\');
				$("#ivo-sync-status").html("");
				$.ajax({
					url: syncUrl, type: "GET", dataType: "json",
					success: function(json) {
						btn.prop("disabled", false).html(\'<i class="fa fa-refresh"></i> ' . addslashes($buttonForceSync) . '\');
						if (json.success) {
							$("#ivo-sync-status").html(\'<span class="text-success"><i class="fa fa-check"></i> \' + json.success + \'</span> <span style="color:#666;">' . addslashes($this->language->get('text_refreshing_status')) . '</span>\');
							setTimeout(function() {
								loaded = false;
								$("#ivo-loading").show();
								$("#ivo-status-content").hide();
								$("#ivo-error").hide();
								loadIvoStatus(); loaded = true;
								$("#ivo-sync-status").html("");
							}, 5000);
						} else if (json.error) {
							$("#ivo-sync-status").html(\'<span class="text-danger"><i class="fa fa-times"></i> \' + json.error + \'</span>\');
						}
					},
					error: function() {
						btn.prop("disabled", false).html(\'<i class="fa fa-refresh"></i> ' . addslashes($buttonForceSync) . '\');
						$("#ivo-sync-status").html(\'<span class="text-danger"><i class="fa fa-times"></i> ' . addslashes($textConnectionError) . '</span>\');
					}
				});
			});
		});
		</script>';

		// Inject tab link right after the last main tab (Design)
		$output = preg_replace(
			'/(<li><a href="#tab-design" data-toggle="tab">[^<]*<\/a><\/li>)/s',
			'$1' . $tabLink,
			$output,
			1
		);

		// Inject tab content right before the Design tab pane (keeps it inside the main .tab-content)
		$output = preg_replace(
			'/(<div class="tab-pane" id="tab-design">)/s',
			$tabContent . '$1',
			$output,
			1
		);

		// Inject script before </body>
		if (strpos($output, '</body>') !== false) {
			$output = str_replace('</body>', $script . '</body>', $output);
		} else {
			$output .= $script;
		}
	}
}
