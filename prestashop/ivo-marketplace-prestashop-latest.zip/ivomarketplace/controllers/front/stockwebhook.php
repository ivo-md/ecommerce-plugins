<?php
/**
 * IVO Marketplace - Inbound Stock Webhook
 *
 * Endpoint: POST /index.php?fc=module&module=ivomarketplace&controller=stockwebhook
 * Auth:     Authorization: Bearer <api_key>     (matches IVO_MARKETPLACE_API_KEY)
 * Body:     { "products": [ { "merchant_internal_id": "REF-or-ID", "availability": 5 }, ... ] }
 *
 * Triggered when a sale on IVO occurs, so the merchant's local PrestaShop stock stays in sync.
 */
class IvoMarketplaceStockWebhookModuleFrontController extends ModuleFrontController
{
    /** Skip PrestaShop template rendering. */
    public function run()
    {
        $this->respondJson($this->handle());
    }

    private function handle(): array
    {
        // Method check
        if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            return [405, ['success' => false, 'error' => 'Method not allowed']];
        }

        // Auth
        $expected = (string) Configuration::get(IvoMarketplace::CONFIG_API_KEY);
        $bearer = $this->extractBearerToken();
        if ($expected === '' || $bearer === '' || !hash_equals($expected, $bearer)) {
            return [401, ['success' => false, 'error' => 'Unauthorized']];
        }

        // Body
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data['products']) || !is_array($data['products'])) {
            return [400, ['success' => false, 'error' => 'Invalid payload: expected { products: [...] }']];
        }

        $updated = [];
        $errors = [];

        foreach ($data['products'] as $item) {
            $ref = isset($item['merchant_internal_id']) ? (string) $item['merchant_internal_id'] : '';
            if ($ref === '' || !array_key_exists('availability', $item)) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => 'Missing merchant_internal_id or availability'];
                continue;
            }
            $delta = (int) $item['availability'];

            $productId = $this->resolveProductId($ref);
            if (!$productId) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => 'Product not found'];
                continue;
            }

            try {
                // Fetch real-time local stock
                $currentStock = (int) StockAvailable::getQuantityAvailableByProduct((int)$productId, 0);
                
                // Calculate new absolute stock, bounded at 0
                $newStock = max(0, $currentStock + $delta);

                // Update database only if merchant enabled it
                $updateStockConfig = Configuration::get(IvoMarketplace::CONFIG_UPDATE_STOCK);
                if ($updateStockConfig !== '0') {
                    StockAvailable::setQuantity((int) $productId, 0, $newStock);
                }

                $updated[] = ['merchant_internal_id' => $ref, 'availability' => $newStock];
            } catch (\Throwable $e) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => $e->getMessage()];
            }
        }

        return [200, [
            'success' => empty($errors),
            'updated' => $updated,
            'errors'  => $errors,
        ]];
    }

    /**
     * merchant_internal_id is product reference when present, else product id.
     */
    private function resolveProductId(string $ref): ?int
    {
        $escaped = pSQL($ref);
        $sql = 'SELECT id_product FROM `' . _DB_PREFIX_ . 'product` WHERE `reference` = "' . $escaped . '" LIMIT 1';
        $row = Db::getInstance()->getRow($sql);
        if ($row && !empty($row['id_product'])) {
            return (int) $row['id_product'];
        }

        if (ctype_digit($ref)) {
            $sql = 'SELECT id_product FROM `' . _DB_PREFIX_ . 'product` WHERE `id_product` = ' . (int) $ref . ' LIMIT 1';
            $row = Db::getInstance()->getRow($sql);
            if ($row && !empty($row['id_product'])) {
                return (int) $row['id_product'];
            }
        }

        return null;
    }

    private function extractBearerToken(): string
    {
        $header = '';
        if (function_exists('apache_request_headers')) {
            foreach (apache_request_headers() as $k => $v) {
                if (strcasecmp($k, 'Authorization') === 0) { $header = $v; break; }
            }
        }
        if ($header === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $header = $_SERVER['HTTP_AUTHORIZATION'];
        }
        if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        }
        if ($header === '') {
            return '';
        }
        if (stripos($header, 'Bearer ') === 0) {
            return trim(substr($header, 7));
        }
        return trim($header);
    }

    private function respondJson(array $statusAndBody): void
    {
        list($status, $body) = $statusAndBody;
        http_response_code((int) $status);
        header('Content-Type: application/json');
        echo json_encode($body);
        exit;
    }
}
