<?php
/**
 * IVO Marketplace - Inbound Stock Webhook
 *
 * Endpoint: POST /index.php?fc=module&module=ivomarketplace&controller=stockwebhook
 * Auth:     Authorization: Bearer <api_key>     (matches IVO_MARKETPLACE_API_KEY)
 * Body:     { "products": [ { "merchant_internal_id": "REF-or-ID", "availability": 5 }, ... ] }
 *           availability is a delta; the id is a product's or a combination's
 *
 * Triggered when a sale on IVO occurs, so the merchant's local PrestaShop stock stays in sync.
 */
class IvoMarketplaceStockWebhookModuleFrontController extends ModuleFrontController
{
    /** Skip PrestaShop template rendering. */
    public function run()
    {
        $this->respondJson($this->handle());
    }

    private function handle(): array
    {
        // Method check
        if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            return [405, ['success' => false, 'error' => 'Method not allowed']];
        }

        // Auth
        $expected = (string) Configuration::get(IvoMarketplace::CONFIG_API_KEY);
        $bearer = $this->extractBearerToken();
        if ($expected === '' || $bearer === '' || !hash_equals($expected, $bearer)) {
            return [401, ['success' => false, 'error' => 'Unauthorized']];
        }

        // Body
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data['products']) || !is_array($data['products'])) {
            return [400, ['success' => false, 'error' => 'Invalid payload: expected { products: [...] }']];
        }

        $updated = [];
        $errors = [];

        foreach ($data['products'] as $item) {
            $ref = isset($item['merchant_internal_id']) ? (string) $item['merchant_internal_id'] : '';
            if ($ref === '' || !array_key_exists('availability', $item)) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => 'Missing merchant_internal_id or availability'];
                continue;
            }
            $delta = (int) $item['availability'];

            $target = $this->resolveStockTarget($ref);
            if (!$target) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => 'Product not found'];
                continue;
            }
            list($productId, $productAttributeId) = $target;

            // A product with combinations keeps its stock per combination; its
            // total row is PrestaShop's sum of them, never written directly
            if ($productAttributeId === 0 && $this->module->hasCombinations($productId)) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => 'Product has combinations; send the combination\'s id'];
                continue;
            }

            try {
                // Fetch real-time local stock
                $currentStock = (int) StockAvailable::getQuantityAvailableByProduct($productId, $productAttributeId);
                
                // Calculate new absolute stock, bounded at 0
                $newStock = max(0, $currentStock + $delta);

                // Update database only if merchant enabled it. A combination's
                // write also recomputes the product total.
                $updateStockConfig = Configuration::get(IvoMarketplace::CONFIG_UPDATE_STOCK);
                if ($updateStockConfig !== '0') {
                    StockAvailable::setQuantity($productId, $productAttributeId, $newStock);
                }

                $updated[] = ['merchant_internal_id' => $ref, 'availability' => $newStock];
            } catch (\Throwable $e) {
                $errors[] = ['merchant_internal_id' => $ref, 'error' => $e->getMessage()];
            }
        }

        return [200, [
            'success' => empty($errors),
            'updated' => $updated,
            'errors'  => $errors,
        ]];
    }

    /**
     * [id_product, id_product_attribute] an IVO id stands for, as
     * IvoMarketplace::getMerchantInternalId() gives them: a combination's own
     * reference, then "<id_product>-<id_product_attribute>", then a product's
     * reference or id (id_product_attribute 0). Null when nothing matches.
     */
    private function resolveStockTarget(string $ref): ?array
    {
        $db = Db::getInstance();

        // A reference only counts when the sync sends it as the combination's
        // id: one copied from the product or shared by two combinations does not
        $rows = $db->executeS(
            'SELECT pa.`id_product`, pa.`id_product_attribute`, p.`reference` AS product_reference'
            . ' FROM `' . _DB_PREFIX_ . 'product_attribute` pa'
            . ' INNER JOIN `' . _DB_PREFIX_ . 'product` p ON (p.`id_product` = pa.`id_product`)'
            . ' WHERE pa.`reference` = "' . pSQL($ref) . '"'
            . ' ORDER BY pa.`id_product_attribute` ASC'
        );
        foreach (is_array($rows) ? $rows : [] as $row) {
            $ids = $this->module->getCombinationInternalIds((int) $row['id_product'], $row['product_reference']);
            if (($ids[(int) $row['id_product_attribute']] ?? '') === $ref) {
                return [(int) $row['id_product'], (int) $row['id_product_attribute']];
            }
        }

        if (preg_match('/^(\d+)-(\d+)$/', $ref, $m)) {
            $exists = $db->getValue(
                'SELECT 1 FROM `' . _DB_PREFIX_ . 'product_attribute`'
                . ' WHERE `id_product` = ' . (int) $m[1] . ' AND `id_product_attribute` = ' . (int) $m[2]
            );
            if ($exists) {
                return [(int) $m[1], (int) $m[2]];
            }
        }

        $productId = $this->resolveProductId($ref);
        return $productId ? [$productId, 0] : null;
    }

    /**
     * merchant_internal_id is product reference when present, else product id.
     */
    private function resolveProductId(string $ref): ?int
    {
        // No LIMIT here: getRow() appends its own, and a second one is an SQL error
        $escaped = pSQL($ref);
        $sql = 'SELECT id_product FROM `' . _DB_PREFIX_ . 'product` WHERE `reference` = "' . $escaped . '"';
        $row = Db::getInstance()->getRow($sql);
        if ($row && !empty($row['id_product'])) {
            return (int) $row['id_product'];
        }

        if (ctype_digit($ref)) {
            $sql = 'SELECT id_product FROM `' . _DB_PREFIX_ . 'product` WHERE `id_product` = ' . (int) $ref;
            $row = Db::getInstance()->getRow($sql);
            if ($row && !empty($row['id_product'])) {
                return (int) $row['id_product'];
            }
        }

        return null;
    }

    private function extractBearerToken(): string
    {
        $header = '';
        if (function_exists('apache_request_headers')) {
            foreach (apache_request_headers() as $k => $v) {
                if (strcasecmp($k, 'Authorization') === 0) { $header = $v; break; }
            }
        }
        if ($header === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $header = $_SERVER['HTTP_AUTHORIZATION'];
        }
        if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        }
        if ($header === '') {
            return '';
        }
        if (stripos($header, 'Bearer ') === 0) {
            return trim(substr($header, 7));
        }
        return trim($header);
    }

    private function respondJson(array $statusAndBody): void
    {
        list($status, $body) = $statusAndBody;
        http_response_code((int) $status);
        header('Content-Type: application/json');
        echo json_encode($body);
        exit;
    }
}
