<?php
/**
 * Front Controller for IVO Marketplace Callback
 * Handles API key callback from IVO setup
 */

class IvoMarketplaceCallbackModuleFrontController extends ModuleFrontController
{
    /**
     * Override run() to completely bypass PrestaShop template system
     * Output standalone HTML page like OpenCart does
     */
    public function run()
    {
        // Get parameters
        $nonce = Tools::getValue('nonce');
        $encryptedKey = Tools::getValue('key');
        
        $success = false;
        $error = '';
        $pointsError = '';
        $pointsNote = '';

        // Validate nonce
        $storedNonce = Configuration::get(IvoMarketplace::CONFIG_SETUP_NONCE);
        $parts = $storedNonce ? explode('|', $storedNonce) : [];

        // This page speaks the language the admin had when setup started
        $this->useLanguage($parts[2] ?? '');

        if (!$storedNonce) {
            $error = $this->module->l('Invalid request: missing security token');
        } else {
            $storedNonceValue = $parts[0] ?? '';
            $storedTime = (int)($parts[1] ?? 0);

            // Delete the nonce immediately (one-time use)
            Configuration::deleteByName(IvoMarketplace::CONFIG_SETUP_NONCE);

            if (empty($nonce) || empty($storedNonceValue)) {
                $error = $this->module->l('Invalid request: missing security token');
            } elseif (!hash_equals($storedNonceValue, $nonce)) {
                $error = $this->module->l('Invalid request: security token mismatch');
            } elseif (time() - $storedTime > 600) { // 10 minutes expiry
                $error = $this->module->l('Request expired. Please start the setup process again.');
            } elseif (empty($encryptedKey)) {
                $error = $this->module->l('API Key is required');
            } else {
                // Decode the API key
                $decodedKey = base64_decode($encryptedKey, true);
                if ($decodedKey === false) {
                    $decodedKey = $encryptedKey; // Use as-is if not base64
                }
                
                // Save API key and mark as configured
                Configuration::updateValue(IvoMarketplace::CONFIG_API_KEY, $decodedKey);
                Configuration::updateValue(IvoMarketplace::CONFIG_CONFIGURED, true);
                
                // Keep the point already chosen: every push goes to it, and
                // setting up again must not move the offers to another point.
                // Choose one only when none is stored and IVO lists exactly one.
                // The lookup still runs, so a failure is shown on this page.
                $storedPointId = trim((string) Configuration::get(IvoMarketplace::CONFIG_MERCHANT_POINT_ID));
                $points = $this->module->fetchMerchantPoints($decodedKey);
                if ($this->module->merchantPointsFailed()) {
                    $pointsError = $this->module->merchantPointError();
                } elseif ($storedPointId === '') {
                    if (count($points) === 1) {
                        $onlyPoint = reset($points);
                        if (!empty($onlyPoint['id'])) {
                            Configuration::updateValue(IvoMarketplace::CONFIG_MERCHANT_POINT_ID, (string) $onlyPoint['id']);
                        }
                    } elseif (count($points) > 1) {
                        $pointsNote = $this->module->l('Choose the Merchant Point in the IVO Marketplace settings and save them.');
                    }
                }

                $success = true;
            }
        }
        
        // Build admin URL - find admin directory dynamically
        $adminFolder = $this->findAdminDirectory();
        $adminLink = _PS_BASE_URL_ . __PS_BASE_URI__ . $adminFolder . '/index.php?controller=AdminModules&configure=ivomarketplace&token=' . Tools::getAdminTokenLite('AdminModules');
        
        // Output standalone HTML page (no store templates)
        $this->outputStandalonePage($success, $error, $adminLink, $pointsError, $pointsNote);
    }

    /**
     * Translate this page into the language captured when setup started
     * (stored with the nonce), else the shop's default language. The front
     * office language is the visitor's, not the admin's.
     */
    private function useLanguage($iso)
    {
        $iso = preg_replace('/[^a-z]/', '', strtolower((string) $iso));
        $langId = $iso !== '' ? (int) Language::getIdByIso($iso) : 0;
        if (!$langId) {
            $langId = (int) Configuration::get('PS_LANG_DEFAULT');
        }
        if ($langId && (!isset($this->context->language->id) || (int) $this->context->language->id !== $langId)) {
            $language = new Language($langId);
            if (Validate::isLoadedObject($language)) {
                $this->context->language = $language;
            }
        }
    }

    /**
     * Find PrestaShop admin directory
     */
    private function findAdminDirectory()
    {
        // Try _PS_ADMIN_DIR_ constant first
        if (defined('_PS_ADMIN_DIR_')) {
            return basename(_PS_ADMIN_DIR_);
        }
        
        // Scan for admin folder with init.php
        $rootDir = _PS_ROOT_DIR_;
        foreach (scandir($rootDir) as $dir) {
            if (strpos($dir, 'admin') === 0 
                && is_dir($rootDir . '/' . $dir) 
                && file_exists($rootDir . '/' . $dir . '/init.php')) {
                return $dir;
            }
        }
        
        return 'admin';
    }

    /**
     * Output standalone HTML page
     */
    private function outputStandalonePage($success, $error, $adminLink, $pointsError = '', $pointsNote = '')
    {
        // Every text comes from the module's l(), which already escapes it for HTML
        $title = $success
            ? $this->module->l('Configuration Successful')
            : $this->module->l('Configuration Failed');
        $message = $success
            ? $this->module->l('Your IVO Marketplace API Key has been successfully configured.')
            : $error;
        $button = $this->module->l('Go to Admin Panel');
        $lang = htmlspecialchars((string) ($this->context->language->iso_code ?? 'en'), ENT_QUOTES, 'UTF-8');
        $adminLink = htmlspecialchars($adminLink, ENT_QUOTES, 'UTF-8');
        // Why no merchant point could be set, or that one is still to be chosen
        $pointsNotice = '';
        if ($success && $pointsError !== '') {
            $pointsNotice = '<p class="points-error">' . $pointsError . '</p>';
        } elseif ($success && $pointsNote !== '') {
            $pointsNotice = '<p class="points-note">' . $pointsNote . '</p>';
        }
        $iconColor = $success ? '#28a745' : '#dc3545';
        $icon = $success 
            ? '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $iconColor . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>'
            : '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $iconColor . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';

        echo <<<HTML
<!DOCTYPE html>
<html lang="{$lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVO Marketplace - {$title}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #123cd1 0%, #ff3385 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px;
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .icon { margin-bottom: 24px; }
        h1 {
            color: #1a1a2e;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 32px;
        }
        .btn {
            display: inline-block;
            background: #123cd1;
            color: white;
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(18, 60, 209, 0.4);
        }
        p.points-error {
            color: #dc3545;
            font-weight: 600;
            margin-top: -16px;
        }
        p.points-note {
            color: #b45309;
            font-weight: 600;
            margin-top: -16px;
        }
        .logo {
            margin-bottom: 32px;
            font-size: 28px;
            font-weight: 700;
            color: #123cd1;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">IVO Marketplace</div>
        <div class="icon">{$icon}</div>
        <h1>{$title}</h1>
        <p>{$message}</p>
        {$pointsNotice}
        <a href="{$adminLink}" class="btn">{$button}</a>
    </div>
</body>
</html>
HTML;
        exit;
    }
}
