<?php
/**
 * Front Controller for IVO Marketplace Callback
 * Handles API key callback from IVO setup
 */

class IvoMarketplaceCallbackModuleFrontController extends ModuleFrontController
{
    /**
     * Override run() to completely bypass PrestaShop template system
     * Output standalone HTML page like OpenCart does
     */
    public function run()
    {
        // Get parameters
        $nonce = Tools::getValue('nonce');
        $encryptedKey = Tools::getValue('key');
        
        $success = false;
        $error = '';
        
        // Validate nonce
        $storedNonce = Configuration::get(IvoMarketplace::CONFIG_SETUP_NONCE);
        
        if (!$storedNonce) {
            $error = 'Invalid request: missing security token';
        } else {
            $parts = explode('|', $storedNonce);
            $storedNonceValue = $parts[0] ?? '';
            $storedTime = (int)($parts[1] ?? 0);
            
            // Delete the nonce immediately (one-time use)
            Configuration::deleteByName(IvoMarketplace::CONFIG_SETUP_NONCE);
            
            if (empty($nonce) || empty($storedNonceValue)) {
                $error = 'Invalid request: missing security token';
            } elseif (!hash_equals($storedNonceValue, $nonce)) {
                $error = 'Invalid request: security token mismatch';
            } elseif (time() - $storedTime > 600) { // 10 minutes expiry
                $error = 'Request expired. Please start the setup process again.';
            } elseif (empty($encryptedKey)) {
                $error = 'API Key is required';
            } else {
                // Decode the API key
                $decodedKey = base64_decode($encryptedKey, true);
                if ($decodedKey === false) {
                    $decodedKey = $encryptedKey; // Use as-is if not base64
                }
                
                // Save API key and mark as configured
                Configuration::updateValue(IvoMarketplace::CONFIG_API_KEY, $decodedKey);
                Configuration::updateValue(IvoMarketplace::CONFIG_CONFIGURED, true);
                
                // Automatically fetch and set the default merchant point ID
                $apiUrl = getenv('IVO_API_URL') ?: 'https://a.ivo.md';
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/merchant-points');
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Authorization: Bearer ' . $decodedKey,
                    'Accept: application/json'
                ]);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                $response = curl_exec($ch);
                curl_close($ch);
                
                $firstPointId = '';
                if ($response) {
                    $pointsData = json_decode($response, true);
                    $points = $pointsData['points'] ?? $pointsData['data'] ?? $pointsData ?? [];
                    if (is_array($points)) {
                        if (isset($points['data']) && is_array($points['data']) && count($points['data']) > 0) {
                            $firstPointId = $points['data'][0]['id'] ?? $points['data'][0]['_id'] ?? '';
                        } elseif (isset($points[0])) {
                            $firstPointId = $points[0]['id'] ?? $points[0]['_id'] ?? '';
                        }
                    }
                }
                if ($firstPointId) {
                    Configuration::updateValue(IvoMarketplace::CONFIG_MERCHANT_POINT_ID, $firstPointId);
                }
                
                $success = true;
            }
        }
        
        // Build admin URL - find admin directory dynamically
        $adminFolder = $this->findAdminDirectory();
        $adminLink = _PS_BASE_URL_ . __PS_BASE_URI__ . $adminFolder . '/index.php?controller=AdminModules&configure=ivomarketplace&token=' . Tools::getAdminTokenLite('AdminModules');
        
        // Output standalone HTML page (no store templates)
        $this->outputStandalonePage($success, $error, $adminLink);
    }

    /**
     * Find PrestaShop admin directory
     */
    private function findAdminDirectory()
    {
        // Try _PS_ADMIN_DIR_ constant first
        if (defined('_PS_ADMIN_DIR_')) {
            return basename(_PS_ADMIN_DIR_);
        }
        
        // Scan for admin folder with init.php
        $rootDir = _PS_ROOT_DIR_;
        foreach (scandir($rootDir) as $dir) {
            if (strpos($dir, 'admin') === 0 
                && is_dir($rootDir . '/' . $dir) 
                && file_exists($rootDir . '/' . $dir . '/init.php')) {
                return $dir;
            }
        }
        
        return 'admin';
    }

    /**
     * Output standalone HTML page
     */
    private function outputStandalonePage($success, $error, $adminLink)
    {
        $title = $success ? 'Configuration Successful' : 'Configuration Failed';
        $message = $success 
            ? 'Your IVO Marketplace API Key has been successfully configured.'
            : htmlspecialchars($error);
        $iconColor = $success ? '#28a745' : '#dc3545';
        $icon = $success 
            ? '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $iconColor . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>'
            : '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $iconColor . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';

        echo <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVO Marketplace - {$title}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #123cd1 0%, #ff3385 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px;
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .icon { margin-bottom: 24px; }
        h1 {
            color: #1a1a2e;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 32px;
        }
        .btn {
            display: inline-block;
            background: #123cd1;
            color: white;
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(18, 60, 209, 0.4);
        }
        .logo {
            margin-bottom: 32px;
            font-size: 28px;
            font-weight: 700;
            color: #123cd1;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">IVO Marketplace</div>
        <div class="icon">{$icon}</div>
        <h1>{$title}</h1>
        <p>{$message}</p>
        <a href="{$adminLink}" class="btn">Go to Admin Panel</a>
    </div>
</body>
</html>
HTML;
        exit;
    }
}
