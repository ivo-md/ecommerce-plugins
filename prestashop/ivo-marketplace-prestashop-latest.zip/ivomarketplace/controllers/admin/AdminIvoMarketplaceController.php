<?php
/**
 * Admin Controller for IVO Marketplace
 * Handles AJAX actions: syncAll, syncProduct, getProductStatus
 * 
 * 
 */

class AdminIvoMarketplaceController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        
        if (!$this->module->active) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminDashboard'));
        }
    }

    /**
     * Main display
     */
    public function initContent()
    {
        parent::initContent();
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules') . '&configure=' . $this->module->name);
    }

    /**
     * Handle AJAX actions
     */
    public function ajaxProcess()
    {
        $action = Tools::getValue('action');
        
        switch ($action) {
            case 'syncAll':
                $this->ajaxSyncAll();
                break;
            case 'syncProduct':
                $this->ajaxSyncProduct();
                break;
            case 'getProductStatus':
                $this->ajaxGetProductStatus();
                break;
            case 'getSetupUrl':
                $this->ajaxGetSetupUrl();
                break;
            default:
                $this->ajaxDie(json_encode(['error' => 'Unknown action']));
        }
    }

    /**
     * AJAX: Get setup URL (generates nonce at click time, not page load)
     */
    private function ajaxGetSetupUrl()
    {
        header('Content-Type: application/json');
        
        $setupUrl = $this->module->getSetupUrl();
        
        echo json_encode([
            'success' => true,
            'url' => $setupUrl,
        ]);
        exit;
    }

    /**
     * AJAX: Sync all products
     * 
     */
    public function ajaxSyncAll()
    {
        header('Content-Type: application/json');
        
        $result = $this->module->syncAllProducts();
        
        // EXACT response format from OpenCart
        if (isset($result['error'])) {
            echo json_encode(['error' => $result['error']]);
        } else {
            echo json_encode(['success' => $result['success']]);
        }
        exit;
    }

    /**
     * AJAX: Sync single product
     * 
     */
    public function ajaxSyncProduct()
    {
        header('Content-Type: application/json');
        
        $productId = (int) Tools::getValue('product_id');
        
        if (!$productId) {
            echo json_encode(['error' => 'Product ID required']);
            exit;
        }
        
        $product = new Product($productId);
        
        if (!Validate::isLoadedObject($product)) {
            echo json_encode(['error' => 'Product not found']);
            exit;
        }
        
        $merchantPointId = $this->module->getMerchantPointId();
        
        if (!$merchantPointId) {
            // EXACT message from OpenCart error_not_configured
            echo json_encode(['error' => $this->module->l('Unable to fetch Merchant Point ID. Please check API Key configuration.')]);
            exit;
        }
        
        $payload = $this->module->prepareProductPayload($product, $merchantPointId);
        
        if (!$payload) {
            echo json_encode(['error' => $this->module->l('Could not prepare payload or Merchant Point ID missing')]);
            exit;
        }
        
        if ((float) $product->price < 0.01) {
            echo json_encode(['error' => $this->module->l('Product cannot be synced. Please ensure it has a valid price.')]);
            exit;
        }
        
        $apiKey = Configuration::get(IvoMarketplace::CONFIG_API_KEY);
        $result = $this->module->syncProducts([$payload], $apiKey);
        
        if ($result['code'] >= 200 && $result['code'] < 300) {
            // EXACT message from OpenCart text_product_synced
            echo json_encode(['success' => $this->module->l('Product synced successfully!')]);
        } else {
            // EXACT format from OpenCart error_sync_failed
            echo json_encode(['error' => sprintf($this->module->l('Sync failed. API Code: %s'), $result['code'])]);
        }
        exit;
    }

    /**
     * AJAX: Get product IVO status
     * 
     * 
     * Response format :
     * Success: { status: "success", urls: {...}, url: "..." }
     * Error: { status: "error", message: "code" }
     */
    public function ajaxGetProductStatus()
    {
        header('Content-Type: application/json');
        
        $productId = (int) Tools::getValue('product_id');
        
        if (!$productId) {
            echo json_encode(['error' => 'Product ID required']);
            exit;
        }
        
        $product = new Product($productId);
        
        if (!Validate::isLoadedObject($product)) {
            echo json_encode(['error' => 'Product not found']);
            exit;
        }
        
        $apiKey = Configuration::get(IvoMarketplace::CONFIG_API_KEY);
        
        if (!$apiKey) {
            echo json_encode(['error' => $this->module->l('Not configured.')]);
            exit;
        }
        
        $sku = $product->reference ?: (string) $productId;
        $ivoData = $this->module->getProductIvoInfo($sku, $apiKey);
        
        // API response format - 
        // Success: { status: "success", product: {...}, offer: {...} }
        // Error: { status: "error", message: "code" }
        if ($ivoData && isset($ivoData['status']) && $ivoData['status'] === 'success' && isset($ivoData['product'])) {
            // Success - offer found
            echo json_encode([
                'status' => 'success',
                'name' => $ivoData['product']['name'] ?? [],
                'urls' => $ivoData['product']['urls'] ?? [],
                'url' => $ivoData['product']['url'] ?? '',
            ]);
        } elseif ($ivoData && isset($ivoData['status']) && $ivoData['status'] === 'error' && isset($ivoData['message'])) {
            // Error status with message code from API
            echo json_encode([
                'status' => 'error',
                'message' => $ivoData['message'],
            ]);
        } else {
            // No response or invalid response - treat as not imported
            echo json_encode([
                'status' => 'error',
                'message' => 'not_imported',
            ]);
        }
        exit;
    }
}
