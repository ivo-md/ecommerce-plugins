<?php
/**
 * IVO Marketplace Module for PrestaShop
 * 
 * EXACT functionality match with Magento, OpenCart, and WooCommerce extensions
 * 
 * @author IVO Team
 * @copyright 2024 IVO
 * @license GPL-2.0+
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class IvoMarketplace extends Module
{
    // IVO Endpoints
    const SETUP_URL = 'https://www.ivo.md/merchant/plugin/setup';
    const API_BASE_URL = 'https://a.ivo.md';
    
    // Config keys - similar to Magento CONFIG_PATH_*
    const CONFIG_API_KEY = 'IVO_MARKETPLACE_API_KEY';
    const CONFIG_CONFIGURED = 'IVO_MARKETPLACE_CONFIGURED';
    const CONFIG_MERCHANT_POINT_ID = 'IVO_MARKETPLACE_MERCHANT_POINT_ID';
    const CONFIG_SETUP_NONCE = 'IVO_MARKETPLACE_SETUP_NONCE';
    const CONFIG_PRICE_MODIFIER = 'IVO_MARKETPLACE_PRICE_MODIFIER';
    const CONFIG_UPDATE_STOCK = 'IVO_MARKETPLACE_UPDATE_STOCK';

    public function __construct()
    {
        $this->name = 'ivomarketplace';
        $this->tab = 'market_place';
        $this->version = '1.0.6';
        $this->author = 'IVO Team';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('IVO Marketplace');
        $this->description = $this->l('Sync your products with IVO Marketplace. Sell on Moldova\'s largest marketplace directly from your PrestaShop store.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall IVO Marketplace?');
    }

    /**
     * Install module
     */
    public function install()
    {
        return parent::install()
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('displayAdminProductsExtra')
            && $this->registerHook('actionProductUpdate')
            && $this->registerHook('actionProductAdd')
            && $this->registerHook('actionProductDelete')
            && $this->registerHook('actionUpdateQuantity')
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('actionOrderStatusPostUpdate')
            && $this->registerHook('displayDashboardTop')
            && $this->installTab();
    }

    /**
     * Uninstall module
     */
    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallTab()
            && Configuration::deleteByName(self::CONFIG_API_KEY)
            && Configuration::deleteByName(self::CONFIG_CONFIGURED)
            && Configuration::deleteByName(self::CONFIG_MERCHANT_POINT_ID)
            && Configuration::deleteByName(self::CONFIG_SETUP_NONCE)
            && Configuration::deleteByName(self::CONFIG_PRICE_MODIFIER)
            && Configuration::deleteByName(self::CONFIG_UPDATE_STOCK);
    }

    /**
     * Install admin tab (menu item)
     */
    private function installTab()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminIvoMarketplace';
        $tab->name = [];
        
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'IVO Marketplace';
        }
        
        // Place under Marketing menu (IMPROVE > Marketing)
        $parentId = (int) Tab::getIdFromClassName('Marketing');
        if (!$parentId) {
            // Fallback to IMPROVE if Marketing doesn't exist
            $parentId = (int) Tab::getIdFromClassName('IMPROVE');
        }
        $tab->id_parent = $parentId;
        $tab->module = $this->name;
        
        return $tab->add();
    }

    /**
     * Uninstall admin tab
     */
    private function uninstallTab()
    {
        $id_tab = (int) Tab::getIdFromClassName('AdminIvoMarketplace');
        if ($id_tab) {
            $tab = new Tab($id_tab);
            return $tab->delete();
        }
        return true;
    }

    /**
     * Module configuration page
     */
    public function getContent()
    {
        $output = '';

        // Installs upgraded in place miss hooks that install() has since
        // learned to register; heal on the config page instead of requiring
        // a reinstall.
        if (!$this->isRegisteredInHook('actionProductDelete')) {
            $this->registerHook('actionProductDelete');
        }

        // Handle form submission
        if (Tools::isSubmit('submit' . $this->name)) {
            $merchantPointId = Tools::getValue(self::CONFIG_MERCHANT_POINT_ID);
            Configuration::updateValue(self::CONFIG_MERCHANT_POINT_ID, $merchantPointId);

            $modifier = Tools::getValue(self::CONFIG_PRICE_MODIFIER);
            $old_modifier = Configuration::get(self::CONFIG_PRICE_MODIFIER);
            Configuration::updateValue(self::CONFIG_PRICE_MODIFIER, $modifier ?? '0');

            $update_stock = Tools::getValue(self::CONFIG_UPDATE_STOCK);
            Configuration::updateValue(self::CONFIG_UPDATE_STOCK, $update_stock ?? '1');

            if ((float)$old_modifier !== (float)$modifier) {
                $this->syncAllProducts();
            }

            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }
        
        return $output . $this->renderConfigForm();
    }

    /**
     * Render configuration form
     *
     */
    private function renderConfigForm()
    {
        $configured = (bool) Configuration::get(self::CONFIG_CONFIGURED);
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $apiKeyMasked = $apiKey ? substr($apiKey, 0, 8) . '••••••••••••••••' : '';
        $merchantPointId = Configuration::get(self::CONFIG_MERCHANT_POINT_ID);
        $priceModifier = Configuration::get(self::CONFIG_PRICE_MODIFIER);
        if ($priceModifier === false || $priceModifier === null) {
            $priceModifier = '0';
        }
        $updateStock = Configuration::get(self::CONFIG_UPDATE_STOCK);
        if ($updateStock === false || $updateStock === null) {
            $updateStock = '1';
        }
        // URL to get setup URL via AJAX (nonce generated on click, not page load)
        $setupAjaxUrl = $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=getSetupUrl&ajax=1';
        
        // Check API validity if configured
        $apiValid = false;
        $apiError = '';
        $merchantInfo = [];
        $merchantPoints = [];
        
        if ($configured) {
            $merchantInfo = $this->checkApiKey();
            if ($merchantInfo !== false) {
                if (isset($merchantInfo['error'])) {
                    $apiError = $merchantInfo['error'];
                } else {
                    $apiValid = true;
                    $merchantPoints = $this->fetchMerchantPoints();
                    
                    // Auto-select if only 1 merchant point and none selected
                    if (empty($merchantPointId) && count($merchantPoints) === 1) {
                        $merchantPointId = $merchantPoints[0]['id'];
                        Configuration::updateValue(self::CONFIG_MERCHANT_POINT_ID, $merchantPointId);
                    }
                }
            } else {
                $apiError = $this->l('Unknown API error');
            }
        }
        
        // Warning if no merchant point selected
        $merchantPointWarning = '';
        if ($apiValid && empty($merchantPointId) && count($merchantPoints) > 1) {
            $merchantPointWarning = $this->l('Please select a Merchant Point. The plugin will not sync products until a merchant point is selected.');
        }
        
        $this->context->smarty->assign([
            'module_dir' => $this->_path,
            'configured' => $configured,
            'api_key_masked' => $apiKeyMasked,
            'api_valid' => $apiValid,
            'api_error' => $apiError,
            'merchant_info' => $merchantInfo,
            'merchant_points' => $merchantPoints,
            'merchant_point_id' => $merchantPointId,
            'merchant_point_warning' => $merchantPointWarning,
            'price_modifier' => $priceModifier,
            'update_stock' => (bool)$updateStock,
            'setup_ajax_url' => $setupAjaxUrl,
            'sync_url' => $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=syncAll&ajax=1',
            'current_url' => AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules'),
            'config_merchant_point_id' => self::CONFIG_MERCHANT_POINT_ID,
            'config_price_modifier' => self::CONFIG_PRICE_MODIFIER,
            'config_update_stock' => self::CONFIG_UPDATE_STOCK,
            'module_name' => $this->name,
            // Translations
            'text_edit' => $this->l('Edit IVO Marketplace'),
            'text_please_configure' => $this->l('IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.'),
            
            // New UI translation strings
            'text_connected' => $this->l('Connected'),
            'text_status_inactive' => $this->l('Not connected'),
            'text_bridge' => $this->l('PrestaShop bridge'),
            'text_connect_prompt' => $this->l('Connect your store to IVO.md.'),
            'text_connect_desc' => $this->l('Authorize your marketplace account, choose what gets synced, then let PrestaShop and IVO work together.'),
            'text_configure_conn' => $this->l('Configure connection'),
            'text_view_guide' => $this->l('View setup guide'),
            'text_settings' => $this->l('Settings'),
            'text_step_account' => $this->l('Account access'),
            'text_step_account_desc' => $this->l('Add your IVO API key and merchant identifier.'),
            'text_badge_success' => $this->l('Success'),
            'text_badge_required' => $this->l('Required'),
            'text_step_sync' => $this->l('Product sync'),
            'text_step_sync_desc' => $this->l('Map categories, prices, stock, and images.'),
            'text_badge_active' => $this->l('Active'),
            'text_badge_inactive' => $this->l('Inactive'),
            'text_badge_next' => $this->l('Next'),
            'text_step_order' => $this->l('Update stock'),
            'text_step_order_desc' => $this->l('Automatically sync stock between your store and IVO.'),
            'text_badge_ready' => $this->l('Ready'),
            'help_guide_url' => 'https://www.ivo.md/help/merchant-integration/prestashop',
            
            'text_api_key' => $this->l('API Key'),
            'text_merchant_point' => $this->l('Merchant Point'),
            'text_price_modifier' => $this->l('Price Modifier (%)'),
            'text_price_modifier_help' => $this->l('Adjust product prices synced to IVO. Enter a percentage to increase or decrease (e.g. +10 or -5). Use 0 for no adjustment.'),
            'text_update_stock' => $this->l('Update stock on sale'),
            'text_update_stock_help' => $this->l('Automatically deduct local stock when an order is placed on IVO.'),
            'text_select' => $this->l('--- Select ---'),
            'button_configure' => $this->l('Configure'),
            'button_reconfigure' => $this->l('Reconfigure'),
            'button_force_sync' => $this->l('Force Sync with IVO'),
            'button_save' => $this->l('Save'),
            'text_syncing' => $this->l('Syncing...'),
            'text_sync_success' => $this->l('Products synchronization started successfully.'),
        ]);
        
        return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    /**
     * Get setup URL
     *
     */
    public function getSetupUrl()
    {
        $shopUrl = Tools::getShopDomainSsl(true);
        
        // Generate a security nonce and store it temporarily
        $nonce = bin2hex(random_bytes(16));
        Configuration::updateValue(self::CONFIG_SETUP_NONCE, $nonce . '|' . time());
        
        $returnUrl = $this->context->link->getModuleLink($this->name, 'callback', ['nonce' => $nonce]);
        
        $params = [
            'url_shop' => $shopUrl,
            'url_return' => $returnUrl,
            'platform' => 'prestashop',
            'version' => _PS_VERSION_,
            'ip_server' => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
            'os_server' => php_uname('s'),
        ];
        
        $setupUrl = getenv('IVO_SETUP_URL') ?: self::SETUP_URL;
        return $setupUrl . '?' . http_build_query($params);
    }

    /**
     * Decrypt IVO API key
     *
     */
    public function decryptIvoKey($encryptedKey)
    {
        $encryptedKey = trim($encryptedKey);
        
        // User Requirement: "The callback key is simply Base64 encoded"
        $decoded = base64_decode($encryptedKey, true);
        
        // Validation: If valid UTF-8/ASCII string, use it.
        if ($decoded !== false && ctype_print($decoded)) {
            return $decoded;
        }
        
        // Fallback: return raw input
        return $encryptedKey;
    }

    /**
     * Save API key from callback
     */
    public function saveApiKey($apiKey)
    {
        Configuration::updateValue(self::CONFIG_API_KEY, $apiKey);
        Configuration::updateValue(self::CONFIG_CONFIGURED, 1);
    }

    /**
     * Check if API key is valid by calling /v1/merchant-api/check
     *
     */
    public function checkApiKey()
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        
        if (!$apiKey) {
            return ['error' => $this->l('No API key configured')];
        }
        
        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/check');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        if ($curlError) {
            return ['error' => 'cURL error: ' . $curlError];
        }
        
        if ($httpCode !== 200) {
            return ['error' => 'HTTP ' . $httpCode . ' - ' . substr($response, 0, 200)];
        }
        
        $data = json_decode($response, true);
        if (isset($data['merchant_id'])) {
            return $data;
        }
        
        return ['error' => $this->l('Invalid API response') . ': ' . substr($response, 0, 200)];
    }

    /**
     * Fetch merchant points from IVO API
     *
     */
    public function fetchMerchantPoints()
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        
        if (!$apiKey) {
            return [];
        }
        
        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/merchant-points');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            // Handle different response formats
            $points = $data['points'] ?? $data['data'] ?? $data ?? [];
            foreach ($points as &$point) {
                if (isset($point['_id']) && !isset($point['id'])) {
                    $point['id'] = $point['_id'];
                }
            }
            return $points;
        }
        
        return [];
    }

    /**
     * Get Merchant Point ID
     *
     */
    public function getMerchantPointId()
    {
        // First check config
        $configId = Configuration::get(self::CONFIG_MERCHANT_POINT_ID);
        if ($configId) {
            return $configId;
        }
        
        // Fetch from API if not in config
        $points = $this->fetchMerchantPoints();
        // EXACT structure from Magento: { "data": [ { "id": "...", ... } ] }
        if (isset($points['data']) && is_array($points['data']) && count($points['data']) > 0) {
            return $points['data'][0]['id'] ?? $points['data'][0]['_id'] ?? null;
        }
        // Also handle { "points": [...] } format
        if (isset($points[0])) {
            return $points[0]['id'] ?? $points[0]['_id'] ?? null;
        }
        
        return null;
    }

    /**
     * Sync products to IVO API
     *
     */
    public function syncProducts($productsData, $apiKey = null, $mode = 'async', $integrationRunId = null)
    {
        if (!$apiKey) {
            $apiKey = Configuration::get(self::CONFIG_API_KEY);
        }

        if (!$apiKey) {
            return ['code' => 0, 'response' => null];
        }

        // EXACT payload from Magento Config.php syncProducts()
        $payload = [
            'mode' => $mode,
            'import_name' => 'api_sync_import_prestashop', // Similar to Magento's "api_sync_import_magento"
            'products' => $productsData,
        ];
        if ($integrationRunId) {
            $payload['integration_run_id'] = $integrationRunId;
        }
        
        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/product/sync-multiple');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // EXACT return format from Magento
        return ['code' => $httpCode, 'response' => json_decode($response, true)];
    }

    /**
     * Get product IVO info by SKU
     *
     */
    public function getProductIvoInfo($sku, $apiKey = null)
    {
        if (!$apiKey) {
            $apiKey = Configuration::get(self::CONFIG_API_KEY);
        }
        
        if (!$apiKey) {
            return null;
        }
        
        // EXACT payload from Magento Config.php getProductIvoInfo()
        $payload = [
            'import_name' => 'api_sync_import_prestashop',
            'merchant_internal_id' => $sku,
        ];
        
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        $url = $apiUrl . '/v1/merchant-api/product/info-by-sku';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        if ($response) {
            return json_decode($response, true);
        }
        
        return null;
    }

    /**
     * Prepare product payload for sync
     * Includes: name, price, currency, availability, merchant_point_id, merchant_internal_id,
     *           description (short_description + description + features), brand, category
     */
    public function prepareProductPayload($product, $merchantPointId = null)
    {
        if (!$merchantPointId) {
            $merchantPointId = $this->getMerchantPointId();
        }
        
        if (!$merchantPointId) {
            return null;
        }
        
        $currency = Currency::getDefaultCurrency();
        $langId = $this->context->language->id ?: Configuration::get('PS_LANG_DEFAULT');
        
        // Build description: short_description + description + features
        $descriptionParts = [];
        
        // Short description
        $shortDesc = $product->description_short[$langId] ?? $product->description_short[Configuration::get('PS_LANG_DEFAULT')] ?? '';
        if ($shortDesc) {
            $descriptionParts[] = strip_tags($shortDesc);
        }
        
        // Full description
        $fullDesc = $product->description[$langId] ?? $product->description[Configuration::get('PS_LANG_DEFAULT')] ?? '';
        if ($fullDesc) {
            $descriptionParts[] = strip_tags($fullDesc);
        }
        
        // Product features (attributes in PrestaShop terminology)
        $features = Product::getFrontFeaturesStatic($langId, $product->id);
        if (!empty($features)) {
            foreach ($features as $feature) {
                $featureName = $feature['name'] ?? '';
                $featureValue = $feature['value'] ?? '';
                if ($featureName && $featureValue) {
                    $descriptionParts[] = $featureName . ': ' . $featureValue;
                }
            }
        }
        
        $description = implode("\n\n", $descriptionParts);
        
        // Get brand (manufacturer)
        $brand = '';
        if ($product->id_manufacturer) {
            $manufacturer = new Manufacturer($product->id_manufacturer, $langId);
            if (Validate::isLoadedObject($manufacturer) && $manufacturer->name) {
                $brand = $manufacturer->name;
            }
        }
        
        // Get category (with full path)
        $category = '';
        $defaultCategoryId = $product->id_category_default;
        if ($defaultCategoryId) {
            $categoryObj = new Category($defaultCategoryId, $langId);
            if (Validate::isLoadedObject($categoryObj)) {
                // Get full path by traversing parents
                $pathParts = [];
                $currentCategory = $categoryObj;
                
                // Max 10 levels to prevent infinite loops
                for ($i = 0; $i < 10 && Validate::isLoadedObject($currentCategory) && $currentCategory->id > 2; $i++) {
                    $catName = $currentCategory->name;
                    if ($catName) {
                        array_unshift($pathParts, $catName);
                    }
                    if ($currentCategory->id_parent > 2) {
                        $currentCategory = new Category($currentCategory->id_parent, $langId);
                    } else {
                        break;
                    }
                }
                
                $category = implode(' > ', $pathParts);
            }
        }
        
        $payload = [
            'name' => $product->name[$langId] ?? $product->name[Configuration::get('PS_LANG_DEFAULT')],
            'price' => $this->applyPriceModifier((float) $product->price),
            'currency' => $currency->iso_code,
            // A deactivated product is not purchasable in the shop, so it must
            // not stay purchasable on IVO either.
            'availability' => $product->active ? (int) StockAvailable::getQuantityAvailableByProduct($product->id) : 0,
            'merchant_point_id' => $merchantPointId,
            'merchant_internal_id' => $product->reference ?: (string) $product->id,
        ];
        
        // Add optional fields only if they have values
        if ($description) {
            $payload['description'] = $description;
        }
        if ($brand) {
            $payload['brand'] = $brand;
        }
        if ($category) {
            $payload['category'] = $category;
        }
        
        // Get product images
        $images = $this->getProductImages($product);
        if (!empty($images)) {
            $payload['images'] = $images;
        }
        
        return $payload;
    }

    /**
     * Apply price modifier to a given price
     */
    private function applyPriceModifier($price)
    {
        $modifier = (float) Configuration::get(self::CONFIG_PRICE_MODIFIER);
        if ($modifier === 0.0) {
            return $price;
        }
        $adjustedPrice = $price * (1 + ($modifier / 100));
        return round(max(0.0, $adjustedPrice), 2);
    }

    /**
     * Get product images (cover + gallery)
     * Returns array of full image URLs
     */
    private function getProductImages($product)
    {
        $images = [];
        $link = new Link();
        
        // Get all product images
        $productImages = Image::getImages($this->context->language->id, $product->id);
        
        foreach ($productImages as $img) {
            $imageUrl = $link->getImageLink(
                $product->link_rewrite[$this->context->language->id] ?? $product->link_rewrite[Configuration::get('PS_LANG_DEFAULT')],
                $img['id_image'],
                ImageType::getFormattedName('large')
            );
            if ($imageUrl) {
                // Ensure full URL
                if (strpos($imageUrl, 'http') !== 0) {
                    $imageUrl = 'http://' . $imageUrl;
                }
                $images[] = $imageUrl;
            }
        }
        
        return $images;
    }

    /**
     * Sync all products to IVO
     *
     */
    public function syncAllProducts()
    {
        $merchantPointId = $this->getMerchantPointId();
        
        if (!$merchantPointId) {
            // EXACT message from Magento: "Unable to fetch Merchant Point ID. Please check API Key configuration."
            return ['error' => $this->l('Unable to fetch Merchant Point ID. Please check API Key configuration.')];
        }
        
        // Get all products
        $products = Product::getProducts($this->context->language->id, 0, 0, 'id_product', 'ASC', false, true);
        
        $currency = Currency::getDefaultCurrency();
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        
        // Prepare products for sync (max 100 per batch)
        $productsPayload = [];
        
        // A full sync enumerates the complete catalog, so it can also tell
        // IVO what no longer exists: every batch carries the same run id, and
        // complete-run afterwards zeroes everything the run did not mention.
        $runId = 'ps_' . time() . '_' . substr(md5(uniqid((string) mt_rand(), true)), 0, 12);
        $allBatchesOk = true;
        $sentAny = false;

        foreach ($products as $productData) {
            $product = new Product($productData['id_product']);

            // Use helper to prepare payload with description, brand, category
            $payload = $this->prepareProductPayload($product, $merchantPointId);
            if ($payload) {
                $productsPayload[] = $payload;
            }

            // Batch sync at 100 products
            if (count($productsPayload) >= 100) {
                $result = $this->syncProducts($productsPayload, $apiKey, 'async', $runId);
                $sentAny = true;
                if ($result['code'] < 200 || $result['code'] >= 300) {
                    $allBatchesOk = false;
                }
                $productsPayload = [];
            }
        }

        // Sync remaining products
        if (!empty($productsPayload)) {
            $result = $this->syncProducts($productsPayload, $apiKey, 'async', $runId);
            $sentAny = true;
            if ($result['code'] < 200 || $result['code'] >= 300) {
                $allBatchesOk = false;
            }
        }

        // Only a run that delivered every batch may declare missing products
        // gone; after a partial run, zeroing would hit products that merely
        // failed to arrive.
        if ($sentAny && $allBatchesOk) {
            $this->completeSyncRun($runId, $apiKey);
        }

        // EXACT message from Magento: "Products synchronization started successfully."
        return ['success' => $this->l('Products synchronization started successfully.')];
    }

    /**
     * Close a full-sync run: products IVO knows from this store that were NOT
     * part of the run no longer exist here, so their offers go out of stock.
     */
    public function completeSyncRun($runId, $apiKey = null)
    {
        if (!$apiKey) {
            $apiKey = Configuration::get(self::CONFIG_API_KEY);
        }

        if (!$apiKey || !$runId) {
            return ['code' => 0, 'response' => null];
        }

        $payload = [
            'import_name' => 'api_sync_import_prestashop',
            'integration_run_id' => $runId,
        ];

        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/product/complete-run');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return ['code' => $httpCode, 'response' => json_decode($response, true)];
    }

    /**
     * Hook: displayBackOfficeHeader
     * Add CSS/JS to admin
     */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name || Tools::getValue('controller') == 'AdminIvoMarketplace') {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
            $this->context->controller->addJS($this->_path . 'views/js/admin.js');
        }
        
        // Product edit page
        if (Tools::getValue('controller') == 'AdminProducts' && Tools::getValue('id_product')) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
            $this->context->controller->addJS($this->_path . 'views/js/admin.js');
        }
    }

    /**
     * Hook: displayAdminProductsExtra
     * Add IVO tab to product edit page
     *
     */
    public function hookDisplayAdminProductsExtra($params)
    {
        // Check if configured
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            return '';
        }
        
        $productId = (int) Tools::getValue('id_product');
        if (!$productId) {
            return '';
        }
        
        $product = new Product($productId);
        $sku = $product->reference ?: (string) $productId;
        
        // Get current language ISO code for URL preference
        $langIso = substr($this->context->language->iso_code, 0, 2);
        
        $this->context->smarty->assign([
            'product_id' => $productId,
            'product_sku' => $sku,
            'status_url' => $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=getProductStatus&ajax=1&product_id=' . $productId,
            'sync_url' => $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=syncProduct&ajax=1&product_id=' . $productId,
            'language_iso' => $langIso,
        ]);
        
        return $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
    }

    /**
     * Hook: actionProductUpdate
     * Sync product on save ProductSaveObserver
     */
    public function hookActionProductUpdate($params)
    {
        $this->syncProductOnSave($params);
    }

    /**
     * Hook: actionProductAdd
     * Sync product on create
     */
    public function hookActionProductAdd($params)
    {
        $this->syncProductOnSave($params);
    }

    /**
     * Hook: actionUpdateQuantity
     * Sync product when stock quantity is updated
     * In PrestaShop 9, stock is updated separately from the product save,
     * so actionProductUpdate fires before the new quantity is persisted.
     */
    public function hookActionUpdateQuantity($params)
    {
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            return;
        }

        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $merchantPointId = $this->getMerchantPointId();

        if (!$apiKey || !$merchantPointId) {
            return;
        }

        $productId = (int) ($params['id_product'] ?? 0);
        if (!$productId) {
            return;
        }

        $product = new Product($productId);
        if (!Validate::isLoadedObject($product)) {
            return;
        }

        $payload = $this->prepareProductPayload($product, $merchantPointId);
        if ($payload) {
            // Override availability with the quantity passed by the hook,
            // which is the already-persisted new stock value
            $payload['availability'] = (int) ($params['quantity'] ?? $payload['availability']);
            $this->syncProducts([$payload], $apiKey);
        }
    }

    /**
     * Sync product on save
     *
     */
    private function syncProductOnSave($params)
    {
        // Check if configured
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            return;
        }
        
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $merchantPointId = $this->getMerchantPointId();
        
        if (!$apiKey || !$merchantPointId) {
            return;
        }
        
        $product = isset($params['product']) ? $params['product'] : null;
        if (!$product) {
            return;
        }
        
        $payload = $this->prepareProductPayload($product, $merchantPointId);
        if ($payload) {
            $this->syncProducts([$payload], $apiKey);
        }
    }

    /**
     * Hook: actionProductDelete
     *
     * A deleted product disappears from every future sync, so nothing would
     * ever zero its IVO offer. Push the zero now, while the product's
     * reference can still be read. The push is availability-only — the
     * server updates rows and offers it already knows and never creates
     * anything from it.
     */
    public function hookActionProductDelete($params)
    {
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            return;
        }

        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $merchantPointId = $this->getMerchantPointId();

        if (!$apiKey || !$merchantPointId) {
            return;
        }

        $product = isset($params['product']) ? $params['product'] : null;
        $productId = isset($params['id_product']) ? (int) $params['id_product'] : 0;
        if (!$product && $productId > 0) {
            $product = new Product($productId);
        }

        if (!$product || !Validate::isLoadedObject($product)) {
            return;
        }

        $internalId = $product->reference ?: (string) $product->id;
        if ($internalId === '') {
            return;
        }

        $this->syncProducts([[
            'availability_only' => true,
            'availability' => 0,
            'merchant_internal_id' => $internalId,
            'merchant_point_id' => $merchantPointId,
        ]], $apiKey);
    }

    /**
     * Hook: actionValidateOrder
     * Sync stock on order OrderPlaceObserver
     */
    public function hookActionValidateOrder($params)
    {
        $this->syncStockOnOrder($params['order']);
    }

    /**
     * Hook: actionOrderStatusPostUpdate
     * Sync stock on order status change
     */
    public function hookActionOrderStatusPostUpdate($params)
    {
        $order = new Order($params['id_order']);
        $this->syncStockOnOrder($order);
    }

    /**
     * Sync stock after order
     *
     */
    private function syncStockOnOrder($order)
    {
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            return;
        }
        
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $merchantPointId = $this->getMerchantPointId();
        
        if (!$apiKey || !$merchantPointId) {
            return;
        }
        
        $currency = new Currency($order->id_currency);
        $processedSkus = [];
        $productsPayload = [];
        
        $orderProducts = $order->getProducts();
        
        foreach ($orderProducts as $orderProduct) {
            $product = new Product($orderProduct['product_id']);
            $sku = $product->reference ?: (string) $orderProduct['product_id'];
            
            // Avoid processing same SKU twice
            if (in_array($sku, $processedSkus)) {
                continue;
            }
            $processedSkus[] = $sku;
            
            // Use helper to prepare payload with description, brand, category
            $payload = $this->prepareProductPayload($product, $merchantPointId);
            if ($payload) {
                $productsPayload[] = $payload;
            }
        }
        
        if (!empty($productsPayload)) {
            $this->syncProducts($productsPayload, $apiKey);
        }
    }

    /**
     * Hook: displayDashboardTop
     * Show warning if not configured
     *
     */
    public function hookDisplayDashboardTop()
    {
        // Skip if on IVO config page
        if (Tools::getValue('configure') == $this->name) {
            return '';
        }
        
        // Check if configured
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            $configureUrl = $this->context->link->getAdminLink('AdminModules') . '&configure=' . $this->name;
            
            $this->context->smarty->assign([
                'message' => $this->l('IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.'),
                'configure_url' => $configureUrl,
                'button_configure' => $this->l('Configure'),
            ]);
            
            return $this->display(__FILE__, 'views/templates/admin/notification.tpl');
        }
        
        return '';
    }
}
