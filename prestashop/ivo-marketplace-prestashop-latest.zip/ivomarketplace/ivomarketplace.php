<?php
/**
 * IVO Marketplace Module for PrestaShop
 * 
 * EXACT functionality match with Magento, OpenCart, and WooCommerce extensions
 * 
 * @author IVO Team
 * @copyright 2024 IVO
 * @license GPL-2.0+
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class IvoMarketplace extends Module
{
    // IVO Endpoints
    const SETUP_URL = 'https://www.ivo.md/merchant/plugin/setup';
    const API_BASE_URL = 'https://a.ivo.md';
    
    // Config keys - similar to Magento CONFIG_PATH_*
    const CONFIG_API_KEY = 'IVO_MARKETPLACE_API_KEY';
    const CONFIG_CONFIGURED = 'IVO_MARKETPLACE_CONFIGURED';
    const CONFIG_MERCHANT_POINT_ID = 'IVO_MARKETPLACE_MERCHANT_POINT_ID';
    const CONFIG_SETUP_NONCE = 'IVO_MARKETPLACE_SETUP_NONCE';
    const CONFIG_PRICE_MODIFIER = 'IVO_MARKETPLACE_PRICE_MODIFIER';
    const CONFIG_UPDATE_STOCK = 'IVO_MARKETPLACE_UPDATE_STOCK';
    // Set when the whole catalogue must be re-sent (new price modifier);
    // the configuration page runs the sliced Force Sync until it is cleared
    const CONFIG_RESYNC_PENDING = 'IVO_MARKETPLACE_RESYNC_PENDING';

    // Force Sync: products read and sent per request
    const SYNC_SLICE_PRODUCTS = 50;
    // A product sends one item per combination: a slice stops taking
    // products once it holds this many items
    const SYNC_SLICE_PAYLOADS = 50;
    // IVO refuses a whole sync-multiple call holding more items
    const SYNC_BATCH_MAX = 100;

    const HOOKS = [
        'displayBackOfficeHeader',
        'displayAdminProductsExtra',
        'actionProductUpdate',
        'actionProductAdd',
        'actionProductDelete',
        'actionObjectCombinationDeleteAfter',
        'actionUpdateQuantity',
        'actionValidateOrder',
        'actionOrderStatusPostUpdate',
        'displayDashboardTop',
    ];

    // Combinations deleted during this request, zeroed on IVO in one push
    // when it ends (see hookActionObjectCombinationDeleteAfter)
    private static $deletedCombinationItems = [];

    public function __construct()
    {
        $this->name = 'ivomarketplace';
        $this->tab = 'market_place';
        $this->version = '1.0.9';
        $this->author = 'IVO Team';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('IVO Marketplace');
        $this->description = $this->l('Sync your products with IVO Marketplace. Sell on Moldova\'s largest marketplace directly from your PrestaShop store.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall IVO Marketplace?');
    }

    /**
     * Install module
     */
    public function install()
    {
        return parent::install()
            && $this->registerHook(self::HOOKS)
            && $this->installTab();
    }

    /**
     * Uninstall module
     */
    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallTab()
            && Configuration::deleteByName(self::CONFIG_API_KEY)
            && Configuration::deleteByName(self::CONFIG_CONFIGURED)
            && Configuration::deleteByName(self::CONFIG_MERCHANT_POINT_ID)
            && Configuration::deleteByName(self::CONFIG_SETUP_NONCE)
            && Configuration::deleteByName(self::CONFIG_PRICE_MODIFIER)
            && Configuration::deleteByName(self::CONFIG_UPDATE_STOCK)
            && Configuration::deleteByName(self::CONFIG_RESYNC_PENDING);
    }

    /**
     * Install admin tab (menu item)
     */
    private function installTab()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminIvoMarketplace';
        $tab->name = [];
        
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'IVO Marketplace';
        }
        
        // Place under Marketing menu (IMPROVE > Marketing)
        $parentId = (int) Tab::getIdFromClassName('Marketing');
        if (!$parentId) {
            // Fallback to IMPROVE if Marketing doesn't exist
            $parentId = (int) Tab::getIdFromClassName('IMPROVE');
        }
        $tab->id_parent = $parentId;
        $tab->module = $this->name;
        
        return $tab->add();
    }

    /**
     * Uninstall admin tab
     */
    private function uninstallTab()
    {
        $id_tab = (int) Tab::getIdFromClassName('AdminIvoMarketplace');
        if ($id_tab) {
            $tab = new Tab($id_tab);
            return $tab->delete();
        }
        return true;
    }

    /**
     * Module configuration page
     */
    public function getContent()
    {
        $output = '';

        // Installs upgraded in place miss hooks that install() has since
        // learned to register (actionUpdateQuantity, actionProductDelete,
        // actionObjectCombinationDeleteAfter); heal on the config page
        // instead of requiring a reinstall.
        foreach (self::HOOKS as $hookName) {
            if (!$this->isRegisteredInHook($hookName)) {
                $this->registerHook($hookName);
            }
        }

        // Handle form submission
        if (Tools::isSubmit('submit' . $this->name)) {
            // The select posts '' when the live list of points could not be
            // fetched; that must not wipe the point every push depends on
            $merchantPointId = trim((string) Tools::getValue(self::CONFIG_MERCHANT_POINT_ID));
            if ($merchantPointId !== '') {
                Configuration::updateValue(self::CONFIG_MERCHANT_POINT_ID, $merchantPointId);
            }

            $modifier = Tools::getValue(self::CONFIG_PRICE_MODIFIER);
            $old_modifier = Configuration::get(self::CONFIG_PRICE_MODIFIER);
            Configuration::updateValue(self::CONFIG_PRICE_MODIFIER, $modifier ?? '0');

            $update_stock = Tools::getValue(self::CONFIG_UPDATE_STOCK);
            Configuration::updateValue(self::CONFIG_UPDATE_STOCK, $update_stock ?? '1');

            // New prices for the whole catalogue: the page re-sends it slice by
            // slice, as Force Sync does, not inside this request
            if ((float)$old_modifier !== (float)$modifier) {
                Configuration::updateValue(self::CONFIG_RESYNC_PENDING, 1);
            }

            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }
        
        return $output . $this->renderConfigForm();
    }

    /**
     * Render configuration form
     *
     */
    private function renderConfigForm()
    {
        $configured = (bool) Configuration::get(self::CONFIG_CONFIGURED);
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $apiKeyMasked = $apiKey ? substr($apiKey, 0, 8) . '••••••••••••••••' : '';
        $merchantPointId = Configuration::get(self::CONFIG_MERCHANT_POINT_ID);
        $priceModifier = Configuration::get(self::CONFIG_PRICE_MODIFIER);
        if ($priceModifier === false || $priceModifier === null) {
            $priceModifier = '0';
        }
        $updateStock = Configuration::get(self::CONFIG_UPDATE_STOCK);
        if ($updateStock === false || $updateStock === null) {
            $updateStock = '1';
        }
        // URL to get setup URL via AJAX (nonce generated on click, not page load)
        $setupAjaxUrl = $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=getSetupUrl&ajax=1';
        
        // Check API validity if configured
        $apiValid = false;
        $apiError = '';
        $merchantInfo = [];
        $merchantPoints = [];
        
        if ($configured) {
            $merchantInfo = $this->checkApiKey();
            if ($merchantInfo !== false) {
                if (isset($merchantInfo['error'])) {
                    $apiError = $merchantInfo['error'];
                } else {
                    $apiValid = true;
                    $merchantPoints = $this->fetchMerchantPoints();
                    
                    // Auto-select if only 1 merchant point and none selected
                    if (empty($merchantPointId) && count($merchantPoints) === 1) {
                        $merchantPointId = $merchantPoints[0]['id'];
                        Configuration::updateValue(self::CONFIG_MERCHANT_POINT_ID, $merchantPointId);
                    }
                }
            } else {
                $apiError = $this->l('Unknown API error');
            }
        }
        
        // Warning if no merchant point selected
        $merchantPointWarning = '';
        if ($apiValid && empty($merchantPointId) && count($merchantPoints) > 1) {
            $merchantPointWarning = $this->l('Please select a Merchant Point. The plugin will not sync products until a merchant point is selected.');
        }

        // A saved point the live list lacks (the fetch failed) is still
        // rendered as selected, so saving the form keeps it
        $merchantPointListed = false;
        foreach ($merchantPoints as $point) {
            if (is_array($point) && isset($point['id']) && is_scalar($point['id']) && (string) $point['id'] === (string) $merchantPointId) {
                $merchantPointListed = true;
                break;
            }
        }

        $this->context->smarty->assign([
            'module_dir' => $this->_path,
            'configured' => $configured,
            'api_key_masked' => $apiKeyMasked,
            'api_valid' => $apiValid,
            'api_error' => $apiError,
            'merchant_info' => $merchantInfo,
            'merchant_points' => $merchantPoints,
            'merchant_point_id' => $merchantPointId,
            'merchant_point_listed' => $merchantPointListed,
            'merchant_point_warning' => $merchantPointWarning,
            'auto_sync' => (bool) Configuration::get(self::CONFIG_RESYNC_PENDING),
            'price_modifier' => $priceModifier,
            'update_stock' => (bool)$updateStock,
            'setup_ajax_url' => $setupAjaxUrl,
            'sync_url' => $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=syncAll&ajax=1',
            'current_url' => AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules'),
            'config_merchant_point_id' => self::CONFIG_MERCHANT_POINT_ID,
            'config_price_modifier' => self::CONFIG_PRICE_MODIFIER,
            'config_update_stock' => self::CONFIG_UPDATE_STOCK,
            'module_name' => $this->name,
            // Translations
            'text_edit' => $this->l('Edit IVO Marketplace'),
            'text_please_configure' => $this->l('IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.'),
            
            // New UI translation strings
            'text_connected' => $this->l('Connected'),
            'text_status_inactive' => $this->l('Not connected'),
            'text_bridge' => $this->l('PrestaShop bridge'),
            'text_connect_prompt' => $this->l('Connect your store to IVO.md.'),
            'text_connect_desc' => $this->l('Authorize your marketplace account, choose what gets synced, then let PrestaShop and IVO work together.'),
            'text_configure_conn' => $this->l('Configure connection'),
            'text_view_guide' => $this->l('View setup guide'),
            'text_settings' => $this->l('Settings'),
            'text_step_account' => $this->l('Account access'),
            'text_step_account_desc' => $this->l('Add your IVO API key and merchant identifier.'),
            'text_badge_success' => $this->l('Success'),
            'text_badge_required' => $this->l('Required'),
            'text_step_sync' => $this->l('Product sync'),
            'text_step_sync_desc' => $this->l('Map categories, prices, stock, and images.'),
            'text_badge_active' => $this->l('Active'),
            'text_badge_inactive' => $this->l('Inactive'),
            'text_badge_next' => $this->l('Next'),
            'text_step_order' => $this->l('Update stock'),
            'text_step_order_desc' => $this->l('Automatically sync stock between your store and IVO.'),
            'text_badge_ready' => $this->l('Ready'),
            'help_guide_url' => 'https://www.ivo.md/help/merchant-integration/prestashop',
            
            'text_api_key' => $this->l('API Key'),
            'text_merchant_point' => $this->l('Merchant Point'),
            'text_price_modifier' => $this->l('Price Modifier (%)'),
            'text_price_modifier_help' => $this->l('Adjust product prices synced to IVO. Enter a percentage to increase or decrease (e.g. +10 or -5). Use 0 for no adjustment.'),
            'text_update_stock' => $this->l('Update stock on sale'),
            'text_update_stock_help' => $this->l('Automatically deduct local stock when an order is placed on IVO.'),
            'text_select' => $this->l('--- Select ---'),
            'button_configure' => $this->l('Configure'),
            'button_reconfigure' => $this->l('Reconfigure'),
            'button_force_sync' => $this->l('Force Sync with IVO'),
            'button_save' => $this->l('Save'),
            'text_syncing' => $this->l('Syncing...'),
            'text_sync_success' => $this->l('Products synchronization started successfully.'),
            'text_sync_progress' => $this->l('Synced %s of %s products...'),
        ]);
        
        return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    /**
     * Get setup URL
     *
     */
    public function getSetupUrl()
    {
        $shopUrl = Tools::getShopDomainSsl(true);
        
        // Generate a security nonce and store it temporarily
        $nonce = bin2hex(random_bytes(16));
        Configuration::updateValue(self::CONFIG_SETUP_NONCE, $nonce . '|' . time());
        
        $returnUrl = $this->context->link->getModuleLink($this->name, 'callback', ['nonce' => $nonce]);
        
        $params = [
            'url_shop' => $shopUrl,
            'url_return' => $returnUrl,
            'platform' => 'prestashop',
            'version' => _PS_VERSION_,
            'ip_server' => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
            'os_server' => php_uname('s'),
        ];
        
        $setupUrl = getenv('IVO_SETUP_URL') ?: self::SETUP_URL;
        return $setupUrl . '?' . http_build_query($params);
    }

    /**
     * Decrypt IVO API key
     *
     */
    public function decryptIvoKey($encryptedKey)
    {
        $encryptedKey = trim($encryptedKey);
        
        // User Requirement: "The callback key is simply Base64 encoded"
        $decoded = base64_decode($encryptedKey, true);
        
        // Validation: If valid UTF-8/ASCII string, use it.
        if ($decoded !== false && ctype_print($decoded)) {
            return $decoded;
        }
        
        // Fallback: return raw input
        return $encryptedKey;
    }

    /**
     * Save API key from callback
     */
    public function saveApiKey($apiKey)
    {
        Configuration::updateValue(self::CONFIG_API_KEY, $apiKey);
        Configuration::updateValue(self::CONFIG_CONFIGURED, 1);
    }

    /**
     * Check if API key is valid by calling /v1/merchant-api/check
     *
     */
    public function checkApiKey()
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        
        if (!$apiKey) {
            return ['error' => $this->l('No API key configured')];
        }
        
        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/check');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        if ($curlError) {
            return ['error' => 'cURL error: ' . $curlError];
        }
        
        if ($httpCode !== 200) {
            return ['error' => 'HTTP ' . $httpCode . ' - ' . substr($response, 0, 200)];
        }
        
        $data = json_decode($response, true);
        if (isset($data['merchant_id'])) {
            return $data;
        }
        
        return ['error' => $this->l('Invalid API response') . ': ' . substr($response, 0, 200)];
    }

    /**
     * Fetch merchant points from IVO API
     *
     */
    public function fetchMerchantPoints()
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        
        if (!$apiKey) {
            return [];
        }
        
        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/merchant-points');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            // Handle different response formats
            $points = $data['points'] ?? $data['data'] ?? $data ?? [];
            foreach ($points as &$point) {
                if (isset($point['_id']) && !isset($point['id'])) {
                    $point['id'] = $point['_id'];
                }
            }
            return $points;
        }
        
        return [];
    }

    /**
     * Get Merchant Point ID
     *
     */
    public function getMerchantPointId()
    {
        // First check config
        $configId = Configuration::get(self::CONFIG_MERCHANT_POINT_ID);
        if ($configId) {
            return $configId;
        }
        
        // Nothing saved: the account's point stands in only when it has exactly
        // one. With several, the first one was an arbitrary choice and pushes
        // landed on a point the merchant never picked.
        $points = $this->fetchMerchantPoints();
        if (is_array($points) && count($points) === 1) {
            $point = reset($points);
            return $point['id'] ?? $point['_id'] ?? null;
        }

        return null;
    }

    /**
     * Sync products to IVO API
     *
     */
    public function syncProducts($productsData, $apiKey = null, $mode = 'async', $integrationRunId = null)
    {
        if (!$apiKey) {
            $apiKey = Configuration::get(self::CONFIG_API_KEY);
        }

        if (!$apiKey) {
            return ['code' => 0, 'response' => null];
        }

        // EXACT payload from Magento Config.php syncProducts()
        $payload = [
            'mode' => $mode,
            'import_name' => 'api_sync_import_prestashop', // Similar to Magento's "api_sync_import_magento"
            'products' => $productsData,
        ];
        if ($integrationRunId) {
            $payload['integration_run_id'] = $integrationRunId;
        }
        
        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/product/sync-multiple');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        
        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        // IVO refuses the whole call when one item is invalid, so a failure
        // here loses every product in it: it must leave a trace
        if ($curlError !== '' || $httpCode < 200 || $httpCode >= 300) {
            $firstId = isset($productsData[0]['merchant_internal_id']) ? (string) $productsData[0]['merchant_internal_id'] : '';
            $this->logIvo(sprintf(
                'IVO Marketplace: push of %d product(s)%s failed: %s',
                count($productsData),
                $firstId !== '' ? ' (first: ' . $firstId . ')' : '',
                $curlError !== '' ? 'cURL error ' . $curlError : 'HTTP ' . $httpCode . ' ' . $this->truncateForLog($response)
            ), 3);
        }
        
        // EXACT return format from Magento
        return [
            'code' => $httpCode,
            'response' => is_string($response) ? json_decode($response, true) : null,
            'error' => $curlError,
        ];
    }

    /**
     * Back office log (Advanced Parameters > Logs), object type IvoMarketplace.
     * Logging never breaks the save or order it reports on.
     */
    public function logIvo($message, $severity, $objectId = null, $allowDuplicate = true)
    {
        // PrestaShop refuses log messages holding < > { } (Validate::isMessage),
        // which every JSON body does
        $message = strtr((string) $message, ['<' => '[', '>' => ']', '{' => '(', '}' => ')']);

        try {
            PrestaShopLogger::addLog($message, (int) $severity, null, 'IvoMarketplace', $objectId ? (int) $objectId : null, $allowDuplicate);
        } catch (\Throwable $e) {
            // nowhere left to report to
        }
    }

    private function truncateForLog($body)
    {
        $body = trim((string) $body);
        return mb_strlen($body, 'UTF-8') > 500 ? mb_substr($body, 0, 500, 'UTF-8') . '...' : $body;
    }

    /**
     * Get product IVO info by SKU
     *
     */
    public function getProductIvoInfo($sku, $apiKey = null)
    {
        if (!$apiKey) {
            $apiKey = Configuration::get(self::CONFIG_API_KEY);
        }
        
        if (!$apiKey) {
            return null;
        }
        
        // EXACT payload from Magento Config.php getProductIvoInfo()
        $payload = [
            'import_name' => 'api_sync_import_prestashop',
            'merchant_internal_id' => $sku,
        ];
        
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        $url = $apiUrl . '/v1/merchant-api/product/info-by-sku';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        if ($response) {
            return json_decode($response, true);
        }
        
        return null;
    }

    /**
     * The id IVO knows an offer of this shop by: a product's reference, else
     * its id; for a combination, see getCombinationInternalIds(). Sync, stock,
     * order and delete pushes, the stock webhook and the product tab all go
     * through here, so a sale or a deletion reaches the offer the sync made.
     */
    public function getMerchantInternalId($product, $idProductAttribute = 0)
    {
        $idProductAttribute = (int) $idProductAttribute;
        if ($idProductAttribute <= 0) {
            return $product->reference ?: (string) $product->id;
        }

        $ids = $this->getCombinationInternalIds($product->id, $product->reference);
        return isset($ids[$idProductAttribute]) ? $ids[$idProductAttribute] : (int) $product->id . '-' . $idProductAttribute;
    }

    /**
     * Ids of all of a product's combinations, keyed by id_product_attribute:
     * the combination's own reference, else "<id_product>-<id_product_attribute>".
     * A reference copied from the product (PrestaShop's demo data and many
     * imports put the product's on every combination) or shared with another
     * combination is not its own: it would put several sizes on one IVO offer.
     * $goneRows: combinations already deleted from the database
     * (id_product_attribute, reference), still counted.
     */
    public function getCombinationInternalIds($productId, $productReference, array $goneRows = [])
    {
        $rows = Db::getInstance()->executeS(
            'SELECT `id_product_attribute`, `reference` FROM `' . _DB_PREFIX_ . 'product_attribute`'
            . ' WHERE `id_product` = ' . (int) $productId
            . ' ORDER BY `id_product_attribute` ASC',
            true,
            false
        );
        $rows = array_merge(is_array($rows) ? $rows : [], $goneRows);

        $productReference = trim((string) $productReference);
        $uses = [];
        foreach ($rows as $row) {
            $reference = trim((string) $row['reference']);
            $uses[$reference] = isset($uses[$reference]) ? $uses[$reference] + 1 : 1;
        }

        $ids = [];
        foreach ($rows as $row) {
            $reference = trim((string) $row['reference']);
            $ids[(int) $row['id_product_attribute']] = $reference !== '' && $reference !== $productReference && $uses[$reference] === 1
                ? $reference
                : (int) $productId . '-' . (int) $row['id_product_attribute'];
        }

        return $ids;
    }

    /**
     * A product's combinations in this shop, each with its IVO id, its option
     * labels ("Size: M") in the shop's attribute group order, its attribute
     * values, and its price and weight impacts. Empty without combinations.
     */
    public function getProductCombinations($product, $langId)
    {
        $defaultLangId = (int) Configuration::get('PS_LANG_DEFAULT');
        $rows = Db::getInstance()->executeS(
            'SELECT pa.`id_product_attribute`, product_attribute_shop.`price`, product_attribute_shop.`weight`,'
            // Names missing in the admin's language fall back to the shop's default language
            . ' COALESCE(NULLIF(agl.`public_name`, ""), NULLIF(agld.`public_name`, ""), NULLIF(agl.`name`, ""), agld.`name`) AS group_name,'
            . ' COALESCE(NULLIF(al.`name`, ""), ald.`name`) AS value_name'
            . ' FROM `' . _DB_PREFIX_ . 'product_attribute` pa'
            . Shop::addSqlAssociation('product_attribute', 'pa')
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_combination` pac ON (pac.`id_product_attribute` = pa.`id_product_attribute`)'
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'attribute` a ON (a.`id_attribute` = pac.`id_attribute`)'
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'attribute_group` ag ON (ag.`id_attribute_group` = a.`id_attribute_group`)'
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'attribute_group_lang` agl ON (agl.`id_attribute_group` = ag.`id_attribute_group` AND agl.`id_lang` = ' . (int) $langId . ')'
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'attribute_group_lang` agld ON (agld.`id_attribute_group` = ag.`id_attribute_group` AND agld.`id_lang` = ' . $defaultLangId . ')'
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'attribute_lang` al ON (al.`id_attribute` = a.`id_attribute` AND al.`id_lang` = ' . (int) $langId . ')'
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'attribute_lang` ald ON (ald.`id_attribute` = a.`id_attribute` AND ald.`id_lang` = ' . $defaultLangId . ')'
            . ' WHERE pa.`id_product` = ' . (int) $product->id
            . ' ORDER BY pa.`id_product_attribute` ASC, ag.`position` ASC, ag.`id_attribute_group` ASC'
        );
        if (empty($rows) || !is_array($rows)) {
            return [];
        }

        $ids = $this->getCombinationInternalIds($product->id, $product->reference);
        $combinations = [];
        foreach ($rows as $row) {
            $ipa = (int) $row['id_product_attribute'];
            if (!isset($combinations[$ipa])) {
                $combinations[$ipa] = [
                    'id_product_attribute' => $ipa,
                    'merchant_internal_id' => isset($ids[$ipa]) ? $ids[$ipa] : (int) $product->id . '-' . $ipa,
                    'price_impact' => (float) $row['price'],
                    'weight_impact' => (float) $row['weight'],
                    'values' => [],
                    'options' => [],
                ];
            }
            $group = trim((string) $row['group_name']);
            $value = trim((string) $row['value_name']);
            if ($value !== '') {
                $combinations[$ipa]['values'][] = $value;
                $combinations[$ipa]['options'][] = $group !== '' ? $group . ': ' . $value : $value;
            }
        }

        return array_values($combinations);
    }

    /**
     * Everything one product sends to IVO: one item per combination, or the
     * product itself when it has none. A product with combinations is not
     * sent as a whole: IVO holds each combination as its own offer, grouped
     * under the product. Items IVO would refuse (no name, price under 0.01)
     * are left out and logged, except that a combination which does not sell
     * anyway still has its offer zeroed. Null without a merchant point.
     */
    public function prepareProductPayloads($product, $merchantPointId = null)
    {
        if (!$merchantPointId) {
            $merchantPointId = $this->getMerchantPointId();
        }

        if (!$merchantPointId) {
            return null;
        }

        $langId = $this->context->language->id ?: Configuration::get('PS_LANG_DEFAULT');
        $combinations = $this->getProductCombinations($product, $langId);

        if (empty($combinations)) {
            $payload = $this->prepareProductPayload($product, $merchantPointId);
            if (!$this->isValidSyncPayload($payload)) {
                $this->logSkippedPayload($product->id, $payload);
                return [];
            }
            return [$payload];
        }

        $payloads = [];
        foreach ($combinations as $combination) {
            $payload = $this->prepareProductPayload($product, $merchantPointId, $combination);
            if ($this->isValidSyncPayload($payload)) {
                $payloads[] = $payload;
            } elseif ((int) $payload['availability'] <= 0) {
                $payloads[] = $this->availabilityItem($payload['merchant_internal_id'], 0, $merchantPointId);
            } else {
                $this->logSkippedPayload($product->id, $payload);
            }
        }

        return $payloads;
    }

    /**
     * An item that only sets the stock of an offer IVO already holds; IVO
     * never creates anything from it
     */
    private function availabilityItem($merchantInternalId, $availability, $merchantPointId)
    {
        return [
            'availability_only' => true,
            'availability' => (int) $availability,
            'merchant_internal_id' => (string) $merchantInternalId,
            'merchant_point_id' => $merchantPointId,
        ];
    }

    /**
     * Real stock of a product (its total) or of one of its combinations.
     * A deactivated product is not purchasable in the shop, so it must not
     * stay purchasable on IVO either. Overselling ("allow orders when out of
     * stock") is not stock.
     */
    private function getAvailability($product, $idProductAttribute = null)
    {
        return $product->active ? max(0, (int) StockAvailable::getQuantityAvailableByProduct($product->id, $idProductAttribute)) : 0;
    }

    /**
     * Prepare product payload for sync: the product itself, or one of its
     * combinations (an entry of getProductCombinations()) as a variant of it.
     * Includes: name, price (tax included, with active discounts), retail_price (while
     *           discounted), currency, availability, merchant_point_id, merchant_internal_id,
     *           description (short_description + description + features), brand, category
     */
    public function prepareProductPayload($product, $merchantPointId = null, $combination = null)
    {
        if (!$merchantPointId) {
            $merchantPointId = $this->getMerchantPointId();
        }
        
        if (!$merchantPointId) {
            return null;
        }
        
        $currency = Currency::getDefaultCurrency();
        $langId = $this->context->language->id ?: Configuration::get('PS_LANG_DEFAULT');
        
        // Build description: short_description + description + features
        $descriptionParts = [];
        
        // Short description
        $shortDesc = $product->description_short[$langId] ?? $product->description_short[Configuration::get('PS_LANG_DEFAULT')] ?? '';
        if ($shortDesc) {
            $descriptionParts[] = strip_tags($shortDesc);
        }
        
        // Full description
        $fullDesc = $product->description[$langId] ?? $product->description[Configuration::get('PS_LANG_DEFAULT')] ?? '';
        if ($fullDesc) {
            $descriptionParts[] = strip_tags($fullDesc);
        }
        
        // Product features (attributes in PrestaShop terminology)
        $features = Product::getFrontFeaturesStatic($langId, $product->id);
        if (!empty($features)) {
            foreach ($features as $feature) {
                $featureName = $feature['name'] ?? '';
                $featureValue = $feature['value'] ?? '';
                if ($featureName && $featureValue) {
                    $descriptionParts[] = $featureName . ': ' . $featureValue;
                }
            }
        }
        
        $description = implode("\n\n", $descriptionParts);
        
        // Get brand (manufacturer)
        $brand = '';
        if ($product->id_manufacturer) {
            $manufacturer = new Manufacturer($product->id_manufacturer, $langId);
            if (Validate::isLoadedObject($manufacturer) && $manufacturer->name) {
                $brand = $manufacturer->name;
            }
        }
        
        // Get category (with full path)
        $category = '';
        $defaultCategoryId = $product->id_category_default;
        if ($defaultCategoryId) {
            $categoryObj = new Category($defaultCategoryId, $langId);
            if (Validate::isLoadedObject($categoryObj)) {
                // Get full path by traversing parents
                $pathParts = [];
                $currentCategory = $categoryObj;
                
                // Max 10 levels to prevent infinite loops
                for ($i = 0; $i < 10 && Validate::isLoadedObject($currentCategory) && $currentCategory->id > 2; $i++) {
                    $catName = $currentCategory->name;
                    if ($catName) {
                        array_unshift($pathParts, $catName);
                    }
                    if ($currentCategory->id_parent > 2) {
                        $currentCategory = new Category($currentCategory->id_parent, $langId);
                    } else {
                        break;
                    }
                }
                
                $category = implode(' > ', $pathParts);
            }
        }
        
        // A combination is priced with its own impact and specific prices; the
        // product alone (null) is priced as PrestaShop prices it
        $idProductAttribute = $combination ? (int) $combination['id_product_attribute'] : null;
        $prices = $this->getProductPrices($product, $idProductAttribute, $combination ? $combination['price_impact'] : 0.0);

        // A name missing or left empty in the admin's language falls back to
        // the shop's default language
        $name = $this->getLocalizedValue($product->name, $langId);
        if ($name === '') {
            $name = $this->getLocalizedValue($product->name, (int) Configuration::get('PS_LANG_DEFAULT'));
        }
        $productName = $name;
        if ($combination && !empty($combination['values']) && $name !== '') {
            $name .= ' - ' . implode(', ', $combination['values']);
        }

        $payload = [
            'name' => $name,
            // Rounded to cents as the shop displays it: percentage discounts
            // on tax-included prices leave sub-cent tails
            'price' => $this->applyPriceModifier(round($prices['price'], 2)),
            'currency' => $currency->iso_code,
            // A combination's own stock: IVO holds each one as its own offer.
            // A product without combinations sends its total.
            'availability' => $this->getAvailability($product, $idProductAttribute),
            'merchant_point_id' => $merchantPointId,
            'merchant_internal_id' => $combination ? $combination['merchant_internal_id'] : $this->getMerchantInternalId($product),
        ];

        // The combinations of one product are variants of one IVO product
        if ($combination) {
            $payload['item_group_id'] = 'prestashop-product-' . (int) $product->id;
            $payload['item_group_title'] = $productName;
            if (!empty($combination['options'])) {
                $payload['variant_options'] = $combination['options'];
                $payload['variant_option'] = implode(' / ', $combination['options']);
            }
        }
        
        // Add optional fields only if they have values
        if ($description) {
            $payload['description'] = $description;
        }
        if ($brand) {
            $payload['brand'] = $brand;
        }
        if ($category) {
            $payload['category'] = $category;
        }
        
        // Get product images
        $images = $this->getProductImages($product, $idProductAttribute);
        if (!empty($images)) {
            $payload['images'] = $images;
        }
        
        // Weight and package dimensions, only when set
        $payload = array_merge($payload, $this->getProductMeasures($product, $combination ? $combination['weight_impact'] : 0.0));

        // While a discount is active, the regular price is IVO's recommended
        // retail price; it skips the price modifier
        if ($prices['regular'] > $prices['price']) {
            $payload['retail_price'] = round($prices['regular'], 2);
        }

        return $payload;
    }

    /**
     * Trimmed value of a multilang field for one language; '' when missing
     */
    private function getLocalizedValue($field, $langId)
    {
        if (is_array($field)) {
            return isset($field[$langId]) ? trim((string) $field[$langId]) : '';
        }
        // A product loaded for one language holds plain strings
        return trim((string) $field);
    }

    /**
     * Tax-included prices as an anonymous shopper sees them in the shop's
     * default country and currency: 'price' with active specific prices
     * (discounts), 'regular' without them. $idProductAttribute prices one
     * combination (null: PrestaShop's default one). When PrestaShop cannot
     * price the product, falls back to the base price plus $priceImpact plus
     * the product's tax rate, and no discount is known ('regular' 0).
     */
    private function getProductPrices($product, $idProductAttribute = null, $priceImpact = 0.0)
    {
        $context = Context::getContext();
        $saved = [$context->customer, $context->cart, $context->country, $context->currency];
        $price = 0.0;
        $regular = 0.0;

        try {
            // getPriceStatic reads the customer group, tax country and currency
            // from the global context: order hooks fill it with the buyer's cart
            // and customer, and without a cart or employee (cron) it throws
            $context->customer = new Customer();
            $context->cart = new Cart();
            $context->country = new Country((int) Configuration::get('PS_COUNTRY_DEFAULT'));
            $defaultCurrency = Currency::getDefaultCurrency();
            if ($defaultCurrency) {
                $context->currency = $defaultCurrency;
            }

            // Prices are cached per request and a product save does not clear them
            if (method_exists('Product', 'flushPriceCache')) {
                Product::flushPriceCache();
            }

            $price = (float) Product::getPriceStatic((int) $product->id, true, $idProductAttribute, 6, null, false, true);
            $regular = (float) Product::getPriceStatic((int) $product->id, true, $idProductAttribute, 6, null, false, false);
        } catch (\Throwable $e) {
            $price = 0.0;
        } finally {
            list($context->customer, $context->cart, $context->country, $context->currency) = $saved;
        }

        if ($price <= 0) {
            $taxRate = Configuration::get('PS_TAX') ? (float) $product->getTaxesRate() : 0.0;
            return ['price' => round(((float) $product->price + (float) $priceImpact) * (1 + $taxRate / 100), 6), 'regular' => 0.0];
        }

        return ['price' => $price, 'regular' => $regular];
    }

    /**
     * Weight and package dimensions, each with its unit spelled out (IVO
     * converts units itself). PrestaShop's depth is the package length.
     * A combination weighs the product's weight plus its $weightImpact;
     * dimensions stay the product's. Empty or zero values are left out, and
     * the three dimensions are sent together or not at all.
     */
    private function getProductMeasures($product, $weightImpact = 0.0)
    {
        $measures = [];

        $weight = $this->formatMeasure((float) $product->weight + (float) $weightImpact);
        $weightUnit = $this->normalizeMeasureUnit(Configuration::get('PS_WEIGHT_UNIT'), [
            'kg' => 'kg', 'kgs' => 'kg', 'кг' => 'kg',
            'g' => 'g', 'gr' => 'g', 'г' => 'g', 'гр' => 'g',
            'lb' => 'lbs', 'lbs' => 'lbs',
            'oz' => 'oz',
        ]);
        if ($weight !== null && $weightUnit !== '') {
            $measures['weight'] = $weight . ' ' . $weightUnit;
        }

        $length = $this->formatMeasure($product->depth);
        $width = $this->formatMeasure($product->width);
        $height = $this->formatMeasure($product->height);
        $dimensionUnit = $this->normalizeMeasureUnit(Configuration::get('PS_DIMENSION_UNIT'), [
            'mm' => 'mm', 'мм' => 'mm',
            'cm' => 'cm', 'см' => 'cm',
            'm' => 'm', 'м' => 'm',
            'in' => 'in', 'inch' => 'in',
        ]);
        if ($length !== null && $width !== null && $height !== null && $dimensionUnit !== '') {
            $measures['length'] = $length . ' ' . $dimensionUnit;
            $measures['width'] = $width . ' ' . $dimensionUnit;
            $measures['height'] = $height . ' ' . $dimensionUnit;
        }

        return $measures;
    }

    /**
     * Positive measure as a plain decimal string; null when empty, zero or not numeric
     */
    private function formatMeasure($value)
    {
        if (!is_numeric($value)) {
            return null;
        }
        $value = round((float) $value, 4);
        if ($value <= 0) {
            return null;
        }
        return rtrim(rtrim(number_format($value, 4, '.', ''), '0'), '.');
    }

    /**
     * Map the shop's free-text unit (Localization > Localization) to an IVO unit; '' when unknown
     */
    private function normalizeMeasureUnit($unit, array $units)
    {
        $unit = mb_strtolower(trim(rtrim(trim((string) $unit), '.')), 'UTF-8');
        return $units[$unit] ?? '';
    }

    /**
     * Apply price modifier to a given price
     */
    private function applyPriceModifier($price)
    {
        $modifier = (float) Configuration::get(self::CONFIG_PRICE_MODIFIER);
        if ($modifier === 0.0) {
            return $price;
        }
        $adjustedPrice = $price * (1 + ($modifier / 100));
        return round(max(0.0, $adjustedPrice), 2);
    }

    /**
     * Get product images (cover + gallery)
     * Returns array of full image URLs. A combination shows the images
     * assigned to it (a colour's photos) when it has any, else the product's.
     */
    private function getProductImages($product, $idProductAttribute = null)
    {
        $images = [];
        $link = new Link();
        
        $productImages = $idProductAttribute ? Image::getImages($this->context->language->id, $product->id, $idProductAttribute) : [];
        if (empty($productImages)) {
            // Get all product images
            $productImages = Image::getImages($this->context->language->id, $product->id);
        }
        
        foreach ($productImages as $img) {
            $imageUrl = $link->getImageLink(
                $product->link_rewrite[$this->context->language->id] ?? $product->link_rewrite[Configuration::get('PS_LANG_DEFAULT')],
                $img['id_image'],
                ImageType::getFormattedName('large')
            );
            if ($imageUrl) {
                // Ensure full URL
                if (strpos($imageUrl, 'http') !== 0) {
                    $imageUrl = 'http://' . $imageUrl;
                }
                $images[] = $imageUrl;
            }
        }
        
        return $images;
    }

    /**
     * One slice of a Force Sync: the next active products of this shop by id
     * after $afterProductId, sent with the run id. The page calls again with
     * the returned `after` and `run_id` until `done`.
     *
     * The whole catalogue in one request ran into the shop's PHP or proxy
     * timeout (often 30 s). Every slice carries the same run id and the last
     * one closes the run, so IVO zeroes what the run never mentioned; a failed
     * batch stops the walk before that, so a partial run never zeroes products
     * that merely did not arrive. Paging by product id, not offset, keeps a
     * product added or deleted mid-run from shifting the pages.
     *
     * Returns ['error' => ...] or ['done', 'after', 'run_id', 'position', 'total'].
     */
    public function syncSlice($afterProductId, $runId)
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        $merchantPointId = $apiKey ? $this->getMerchantPointId() : null;
        if (!$apiKey || !$merchantPointId) {
            // EXACT message from Magento: "Unable to fetch Merchant Point ID. Please check API Key configuration."
            return ['error' => $this->l('Unable to fetch Merchant Point ID. Please check API Key configuration.')];
        }

        if ($runId === '') {
            $runId = 'ps_' . time() . '_' . substr(md5(uniqid((string) mt_rand(), true)), 0, 12);
        }

        // The products Product::getProducts(..., $only_active = true) lists:
        // active in the context shop
        $from = ' FROM `' . _DB_PREFIX_ . 'product` p'
            . Shop::addSqlAssociation('product', 'p')
            . ' LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (p.`id_product` = pl.`id_product`' . Shop::addSqlRestrictionOnLang('pl') . ')'
            . ' WHERE pl.`id_lang` = ' . (int) ($this->context->language->id ?: Configuration::get('PS_LANG_DEFAULT'))
            . ' AND product_shop.`active` = 1';
        $rows = Db::getInstance()->executeS(
            'SELECT p.`id_product`' . $from
            . ' AND p.`id_product` > ' . (int) $afterProductId
            . ' ORDER BY p.`id_product` ASC LIMIT ' . (int) self::SYNC_SLICE_PRODUCTS
        );
        if (!is_array($rows)) {
            $rows = [];
        }

        $after = (int) $afterProductId;
        $consumed = 0;
        $productsPayload = [];
        foreach ($rows as $row) {
            $after = (int) $row['id_product'];
            $consumed++;
            $payloads = $this->prepareProductPayloads(new Product($after), $merchantPointId);
            if (!empty($payloads)) {
                $productsPayload = array_merge($productsPayload, $payloads);
            }
            // Products with many combinations would make the request long:
            // the rest of the page waits for the next slice
            if (count($productsPayload) >= self::SYNC_SLICE_PAYLOADS) {
                break;
            }
        }

        // One product can have more combinations than IVO takes in one call
        foreach (array_chunk($productsPayload, self::SYNC_BATCH_MAX) as $batch) {
            $result = $this->syncProducts($batch, $apiKey, 'async', $runId);
            if ($result['code'] < 200 || $result['code'] >= 300) {
                return ['error' => $this->describeSyncFailure($result)];
            }
        }

        $done = $consumed === count($rows) && count($rows) < self::SYNC_SLICE_PRODUCTS;
        $response = [
            'done' => $done,
            'after' => $after,
            'run_id' => $runId,
            'position' => (int) Db::getInstance()->getValue('SELECT COUNT(*)' . $from . ' AND p.`id_product` <= ' . $after),
            'total' => (int) Db::getInstance()->getValue('SELECT COUNT(*)' . $from),
        ];

        if ($done) {
            $this->completeSyncRun($runId, $apiKey);
            // Every price went out with this run, the pending re-send included
            Configuration::updateValue(self::CONFIG_RESYNC_PENDING, 0);
            // EXACT message from Magento: "Products synchronization started successfully."
            $response['success'] = $this->l('Products synchronization started successfully.');
        }

        return $response;
    }

    /**
     * IVO refuses a whole sync-multiple call when one item lacks a name or a
     * price of at least 0.01, so such products are left out rather than
     * costing every product sent with them.
     */
    public function isValidSyncPayload($payload)
    {
        return is_array($payload)
            && isset($payload['name'])
            && is_string($payload['name'])
            && trim($payload['name']) !== ''
            && isset($payload['price'])
            && is_numeric($payload['price'])
            && (float) $payload['price'] >= 0.01;
    }

    public function logSkippedPayload($productId, $payload)
    {
        $internalId = is_array($payload) && isset($payload['merchant_internal_id']) ? (string) $payload['merchant_internal_id'] : '';
        // Logged once per product or combination: a priceless product would
        // otherwise add a line on every save and every Force Sync
        $this->logIvo(sprintf(
            'IVO Marketplace: product %d%s not sent to IVO: a name and a price of at least 0.01 are required.',
            (int) $productId,
            $internalId !== '' ? ' (' . $internalId . ')' : ''
        ), 2, $productId, false);
    }

    /**
     * Message for a failed batch: the API code plus what IVO or cURL said
     */
    private function describeSyncFailure($result)
    {
        $message = sprintf($this->l('Sync failed. API Code: %s'), $result['code']);

        $detail = '';
        if (!empty($result['error'])) {
            $detail = $result['error'];
        } elseif (is_array($result['response']) && isset($result['response']['message']) && is_string($result['response']['message'])) {
            $detail = $result['response']['message'];
        }

        return $detail !== '' ? $message . ' ' . htmlspecialchars($detail, ENT_QUOTES, 'UTF-8') : $message;
    }

    /**
     * Close a full-sync run: products IVO knows from this store that were NOT
     * part of the run no longer exist here, so their offers go out of stock.
     */
    public function completeSyncRun($runId, $apiKey = null)
    {
        if (!$apiKey) {
            $apiKey = Configuration::get(self::CONFIG_API_KEY);
        }

        if (!$apiKey || !$runId) {
            return ['code' => 0, 'response' => null];
        }

        $payload = [
            'import_name' => 'api_sync_import_prestashop',
            'integration_run_id' => $runId,
        ];

        $ch = curl_init();
        $apiUrl = getenv('IVO_API_URL') ?: self::API_BASE_URL;
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '/v1/merchant-api/product/complete-run');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        // Products deleted from the shop keep their stock on IVO until a
        // later run closes
        if ($curlError !== '' || $httpCode < 200 || $httpCode >= 300) {
            $this->logIvo(sprintf(
                'IVO Marketplace: complete-run for %s failed: %s',
                $runId,
                $curlError !== '' ? 'cURL error ' . $curlError : 'HTTP ' . $httpCode . ' ' . $this->truncateForLog($response)
            ), 3);
        }

        return ['code' => $httpCode, 'response' => is_string($response) ? json_decode($response, true) : null];
    }

    /**
     * Hook: displayBackOfficeHeader
     * Add CSS/JS to admin
     */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name || Tools::getValue('controller') == 'AdminIvoMarketplace') {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
            $this->context->controller->addJS($this->_path . 'views/js/admin.js');
        }
        
        // Product edit page
        if (Tools::getValue('controller') == 'AdminProducts' && Tools::getValue('id_product')) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
            $this->context->controller->addJS($this->_path . 'views/js/admin.js');
        }
    }

    /**
     * Hook: displayAdminProductsExtra
     * Add IVO tab to product edit page
     *
     */
    public function hookDisplayAdminProductsExtra($params)
    {
        // Check if configured
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            return '';
        }
        
        $productId = (int) Tools::getValue('id_product');
        if (!$productId) {
            return '';
        }
        
        $product = new Product($productId);
        $sku = $this->getMerchantInternalId($product);
        
        // Get current language ISO code for URL preference
        $langIso = substr($this->context->language->iso_code, 0, 2);
        
        $this->context->smarty->assign([
            'product_id' => $productId,
            'product_sku' => $sku,
            'status_url' => $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=getProductStatus&ajax=1&product_id=' . $productId,
            'sync_url' => $this->context->link->getAdminLink('AdminIvoMarketplace') . '&action=syncProduct&ajax=1&product_id=' . $productId,
            'language_iso' => $langIso,
        ]);
        
        return $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
    }

    /**
     * Hook: actionProductUpdate
     * Sync product on save ProductSaveObserver
     */
    public function hookActionProductUpdate($params)
    {
        $this->syncProductOnSave($params);
    }

    /**
     * Hook: actionProductAdd
     * Sync product on create
     */
    public function hookActionProductAdd($params)
    {
        $this->syncProductOnSave($params);
    }

    /**
     * Hook: actionUpdateQuantity
     * Sync product when stock quantity is updated
     * In PrestaShop 9, stock is updated separately from the product save,
     * so actionProductUpdate fires before the new quantity is persisted.
     */
    public function hookActionUpdateQuantity($params)
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        if (!$apiKey) {
            return;
        }

        $productId = (int) ($params['id_product'] ?? 0);
        if (!$productId) {
            return;
        }
        $idProductAttribute = (int) ($params['id_product_attribute'] ?? 0);

        // PrestaShop calls this for each combination whose stock changed and
        // then for the product total it recomputes from them. IVO holds each
        // combination as its own offer, so the total has nothing to update.
        if (!$idProductAttribute && $this->hasCombinations($productId)) {
            return;
        }

        $merchantPointId = $this->getPushMerchantPointId('the stock of product ' . $productId, $productId);
        if (!$merchantPointId) {
            return;
        }

        $product = new Product($productId);
        if (!Validate::isLoadedObject($product)) {
            return;
        }

        // The stock is read back (0 when inactive), not taken from
        // $params['quantity']. PrestaShop has written the new quantities by
        // now but drops its per-request cache of them only after this hook.
        Cache::clean('StockAvailable::getQuantityAvailableByProduct_' . $productId . '*');

        if ($idProductAttribute) {
            $internalId = $this->getMerchantInternalId($product, $idProductAttribute);
            $this->syncProducts([$this->availabilityItem($internalId, $this->getAvailability($product, $idProductAttribute), $merchantPointId)], $apiKey);
            return;
        }

        $payloads = $this->prepareProductPayloads($product, $merchantPointId);
        if (!empty($payloads)) {
            $this->syncProducts($payloads, $apiKey);
        }
    }

    /**
     * Whether a product has combinations, each its own offer on IVO
     */
    public function hasCombinations($productId)
    {
        return (bool) Db::getInstance()->getValue(
            'SELECT 1 FROM `' . _DB_PREFIX_ . 'product_attribute` WHERE `id_product` = ' . (int) $productId,
            false
        );
    }

    /**
     * Sync product on save
     *
     */
    private function syncProductOnSave($params)
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        if (!$apiKey) {
            return;
        }
        
        $product = isset($params['product']) ? $params['product'] : null;
        if (!$product) {
            return;
        }

        $merchantPointId = $this->getPushMerchantPointId('product ' . (int) $product->id, $product->id);
        if (!$merchantPointId) {
            return;
        }
        
        // Every combination of the product; it can have more than IVO takes
        // in one call
        $payloads = $this->prepareProductPayloads($product, $merchantPointId);
        foreach (array_chunk($payloads ?: [], self::SYNC_BATCH_MAX) as $batch) {
            $this->syncProducts($batch, $apiKey);
        }
    }

    /**
     * The merchant point an automatic push goes to. A connected shop without
     * one cannot push, and the log says so instead of dropping it unseen.
     */
    private function getPushMerchantPointId($what, $productId = null)
    {
        $merchantPointId = $this->getMerchantPointId();
        if (!$merchantPointId) {
            $this->logIvo('IVO Marketplace: no merchant point is selected, so ' . $what . ' was not sent to IVO.', 3, $productId);
        }
        return $merchantPointId;
    }

    /**
     * Hook: actionProductDelete
     *
     * A deleted product disappears from every future sync, so nothing would
     * ever zero its IVO offer. Push the zero now, while the product's
     * reference can still be read. The push is availability-only — the
     * server updates rows and offers it already knows and never creates
     * anything from it.
     */
    public function hookActionProductDelete($params)
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        if (!$apiKey) {
            return;
        }

        $product = isset($params['product']) ? $params['product'] : null;
        $productId = isset($params['id_product']) ? (int) $params['id_product'] : 0;
        if (!$product && $productId > 0) {
            $product = new Product($productId);
        }

        if (!$product || !Validate::isLoadedObject($product)) {
            return;
        }

        $merchantPointId = $this->getPushMerchantPointId('the deletion of product ' . (int) $product->id, $product->id);
        if (!$merchantPointId) {
            return;
        }

        // PrestaShop deletes the combinations after this hook, so their ids
        // can still be read. The product's own id goes too: it is the offer
        // the product had before it got combinations.
        $internalIds = array_merge(
            [$this->getMerchantInternalId($product)],
            array_values($this->getCombinationInternalIds($product->id, $product->reference))
        );
        $items = [];
        foreach (array_unique($internalIds) as $internalId) {
            $items[] = $this->availabilityItem($internalId, 0, $merchantPointId);
        }
        foreach (array_chunk($items, self::SYNC_BATCH_MAX) as $batch) {
            $this->syncProducts($batch, $apiKey);
        }
    }

    /**
     * Hook: actionObjectCombinationDeleteAfter (every Combination::delete(),
     * from the product page or the API, PrestaShop 1.7 to 9)
     *
     * A deleted combination disappears from every future sync, so its offer
     * is zeroed now, under the id it was synced with.
     */
    public function hookActionObjectCombinationDeleteAfter($params)
    {
        $combination = isset($params['object']) ? $params['object'] : null;
        if (!$combination instanceof Combination || !(int) $combination->id || !(int) $combination->id_product) {
            return;
        }

        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        if (!$apiKey) {
            return;
        }

        $db = Db::getInstance();
        // Removed from some shops only: it still sells in the others
        if ($db->getValue('SELECT 1 FROM `' . _DB_PREFIX_ . 'product_attribute` WHERE `id_product_attribute` = ' . (int) $combination->id, false)) {
            return;
        }
        // Deleting a product deletes its combinations once the product row is
        // gone, and hookActionProductDelete has zeroed them all already
        $productId = (int) $combination->id_product;
        $productReference = $db->getValue('SELECT `reference` FROM `' . _DB_PREFIX_ . 'product` WHERE `id_product` = ' . $productId, false);
        if ($productReference === false) {
            return;
        }

        $merchantPointId = $this->getPushMerchantPointId('the deletion of combination ' . (int) $combination->id . ' of product ' . $productId, $productId);
        if (!$merchantPointId) {
            return;
        }

        // Its row is gone; it still counts when telling whether its reference was its own
        $ids = $this->getCombinationInternalIds($productId, $productReference, [[
            'id_product_attribute' => (int) $combination->id,
            'reference' => (string) $combination->reference,
        ]]);
        $internalId = $ids[(int) $combination->id];

        // Deleting all of a product's combinations (bulk delete, or making it
        // a standard product) runs this once per combination: one push when
        // the request ends instead of one call each
        if (empty(self::$deletedCombinationItems)) {
            register_shutdown_function([$this, 'pushDeletedCombinations'], $apiKey);
        }
        self::$deletedCombinationItems[$internalId] = $this->availabilityItem($internalId, 0, $merchantPointId);
    }

    /**
     * Shutdown: zero the offers of the combinations deleted in this request
     */
    public function pushDeletedCombinations($apiKey)
    {
        $items = array_values(self::$deletedCombinationItems);
        self::$deletedCombinationItems = [];
        foreach (array_chunk($items, self::SYNC_BATCH_MAX) as $batch) {
            $this->syncProducts($batch, $apiKey);
        }
    }

    /**
     * Hook: actionValidateOrder
     * Sync stock on order OrderPlaceObserver
     */
    public function hookActionValidateOrder($params)
    {
        $this->syncStockOnOrder($params['order']);
    }

    /**
     * Hook: actionOrderStatusPostUpdate
     * Sync stock on order status change
     */
    public function hookActionOrderStatusPostUpdate($params)
    {
        $order = new Order($params['id_order']);
        $this->syncStockOnOrder($order);
    }

    /**
     * Sync stock after order: the stock of what each order line sold, the
     * combination when it has one, else the product
     *
     */
    private function syncStockOnOrder($order)
    {
        $apiKey = Configuration::get(self::CONFIG_API_KEY);
        if (!$apiKey) {
            return;
        }

        $merchantPointId = $this->getPushMerchantPointId('the stock of order ' . (int) $order->id);
        if (!$merchantPointId) {
            return;
        }
        
        $productsPayload = [];
        
        $orderProducts = $order->getProducts();
        
        foreach ($orderProducts as $orderProduct) {
            $productId = (int) $orderProduct['product_id'];
            $idProductAttribute = (int) ($orderProduct['product_attribute_id'] ?? 0);
            $product = new Product($productId);
            if (!Validate::isLoadedObject($product)) {
                continue;
            }
            
            // Avoid processing same SKU twice
            $internalId = $this->getMerchantInternalId($product, $idProductAttribute);
            if (isset($productsPayload[$internalId])) {
                continue;
            }
            
            Cache::clean('StockAvailable::getQuantityAvailableByProduct_' . $productId . '*');
            $productsPayload[$internalId] = $this->availabilityItem(
                $internalId,
                $this->getAvailability($product, $idProductAttribute ?: null),
                $merchantPointId
            );
        }
        
        foreach (array_chunk(array_values($productsPayload), self::SYNC_BATCH_MAX) as $batch) {
            $this->syncProducts($batch, $apiKey);
        }
    }

    /**
     * Hook: displayDashboardTop
     * Show warning if not configured
     *
     */
    public function hookDisplayDashboardTop()
    {
        // Skip if on IVO config page
        if (Tools::getValue('configure') == $this->name) {
            return '';
        }
        
        // Check if configured
        if (!Configuration::get(self::CONFIG_CONFIGURED)) {
            $configureUrl = $this->context->link->getAdminLink('AdminModules') . '&configure=' . $this->name;
            
            $this->context->smarty->assign([
                'message' => $this->l('IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.'),
                'configure_url' => $configureUrl,
                'button_configure' => $this->l('Configure'),
            ]);
            
            return $this->display(__FILE__, 'views/templates/admin/notification.tpl');
        }
        
        return '';
    }
}
