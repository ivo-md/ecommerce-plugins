<?php
/**
 * IVO Marketplace - Romanian Translations
 * 
 */

global $_MODULE;
$_MODULE = [];

// Module name and description
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d41d8cd98f00b204e9800998ecf8427e'] = '';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8ff23cb7ea63e9b21eae7d02ad179dd1'] = 'Magazinul IVO';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_96f0708bdcabf9c17f9d97d73c84c96a'] = 'Integrare IVO Marketplace pentru PrestaShop.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8acf2a57da2e7db1927b49f92f8e3ed9'] = 'Sigur doriți să dezinstalați IVO Marketplace?';

// Configuration page
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c888438d14855d7d96a2724ee9c306bd'] = 'Setările au fost actualizate';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7dce122004969d56ae2e0245cb754d35'] = 'Editare';
$_MODULE['<{ivomarketplace}prestashop>configure_8ff23cb7ea63e9b21eae7d02ad179dd1'] = 'Magazinul IVO';
$_MODULE['<{ivomarketplace}prestashop>configure_96f0708bdcabf9c17f9d97d73c84c96a'] = 'Integrare IVO Marketplace pentru PrestaShop.';
$_MODULE['<{ivomarketplace}prestashop>configure_b7b1e314614cf326c6e2b6eba1540682'] = 'Editare IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>configure_1e4da6c30b41e9aaba6c78ca8f27b46a'] = 'IVO Marketplace este instalat dar nu este configurat. Vă rugăm să îl configurați pentru a începe să vindeți pe IVO.';
$_MODULE['<{ivomarketplace}prestashop>configure_b39939c6d5ed67e81ce03ab7cec3e92d'] = 'Cheie API';
$_MODULE['<{ivomarketplace}prestashop>configure_a97da2ba7ea1ecd79edaf49f5b04e1de'] = 'Punct de Vânzare';
$_MODULE['<{ivomarketplace}prestashop>configure_b85bd8f6c7835f9a21e68fd41b0e27fd'] = '--- Selectați ---';
$_MODULE['<{ivomarketplace}prestashop>configure_e2aeb51de42e3ab1a9fdb33f2b0a13b5'] = 'Vă rugăm să selectați un Punct de Vânzare. Pluginul nu va sincroniza produsele până când nu este selectat un punct de vânzare.';
$_MODULE['<{ivomarketplace}prestashop>configure_df2e3c0cd17b3435d1dea9b4c47aef54'] = 'Configurează';
$_MODULE['<{ivomarketplace}prestashop>configure_8dcd5e32c397d8d72a1eb7be32acae70'] = 'Reconfigurează';
$_MODULE['<{ivomarketplace}prestashop>configure_3c99e98e06e65c52dbb60e3c3cbdecfc'] = 'Sincronizează forțat cu IVO';
$_MODULE['<{ivomarketplace}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Salvează';
$_MODULE['<{ivomarketplace}prestashop>configure_88183b946cc5f0e8c96b2e66e1c74a7e'] = 'Se sincronizează...';
$_MODULE['<{ivomarketplace}prestashop>configure_f1d6be73b21bc3a8e70b9a2c2c8e87f7'] = 'Sincronizarea produselor a început cu succes.';

// Status messages
$_MODULE['<{ivomarketplace}prestashop>product_tab_4ec3f789fc22c5e2b5e8f22a3cb7d04a'] = 'Stare IVO';
$_MODULE['<{ivomarketplace}prestashop>product_tab_1243daf593fa297e07ab03bf06d925af'] = 'Se încarcă...';
$_MODULE['<{ivomarketplace}prestashop>product_tab_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activ';
$_MODULE['<{ivomarketplace}prestashop>product_tab_3cab03c00dbd11bc3569afa0748013f0'] = 'Inactiv';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2d13df6f8b5e4c5af9f87e0dc39df69d'] = 'În așteptare';
$_MODULE['<{ivomarketplace}prestashop>product_tab_72d6d7a1885885bb55a565fd1070581a'] = 'Nesincronizat';
$_MODULE['<{ivomarketplace}prestashop>product_tab_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Eroare';
$_MODULE['<{ivomarketplace}prestashop>product_tab_0557fa923dcee4d0f86b1409f5c2167f'] = 'Necunoscut';
$_MODULE['<{ivomarketplace}prestashop>product_tab_15ba57a3c1398a2de25f700c21e9a13d'] = 'Produsul este vizibil și poate fi cumpărat.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_6e72e76bdda6be2d2d18d94b5ff0ed3e'] = 'Vezi produsul';
$_MODULE['<{ivomarketplace}prestashop>product_tab_f047bf1d35c21c0be4bba90fe6badb41'] = 'Eroare de conexiune.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_48ddffb48f52a62c97e9e3f7c0eb7c88'] = 'Produs sincronizat cu succes!';

// Detailed status messages
$_MODULE['<{ivomarketplace}prestashop>product_tab_47e91f67d30d3a12bcdf19fd7b2c9f52'] = 'Produsul nu a fost încă sincronizat cu IVO.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_6ee8bd5c38def88f7c8ab8b94b6dbafc'] = 'Produsul este în coada de procesare.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Produsul este în curs de procesare.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2c09ec01f6c6ce0c32dcc7d2a7fca77b'] = 'Produs creat, dar încă în așteptarea aprobării.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_99baa85c7a04b0403a03ed9bace3b4e6'] = 'A apărut o eroare în timpul importului.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_fb7c6f4fa9bfa0f83bf1bd3acaa8e93e'] = 'Detaliile produsului sunt prea generice pentru a identifica cu exactitate articolul.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_18e36a69e2b6f4a5d70abc2a65c04c51'] = 'Comerciantul nu este autorizat pentru categoria produsului.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_c7fd4d2f1c1e3ddf6c4f68b70b09dc54'] = 'Oferta a fost ștearsă din marketplace.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_3c8e4f1c8b0e45ae5c03f2a7d9d73b1e'] = 'Produsul nu a fost găsit în marketplace.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_1c8e9ec0c2c93a7b6c8f4c3d5e7f9b0a'] = 'Stare necunoscută';

// Buttons
$_MODULE['<{ivomarketplace}prestashop>product_tab_3c99e98e06e65c52dbb60e3c3cbdecfc'] = 'Sincronizează forțat cu IVO';

// Error messages
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_2b3a6c6e5c7f8d9e0a1b2c3d4e5f6a7b'] = 'Cheie API neconfigurată';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Răspuns API invalid';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_5a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d'] = 'Nu s-a putut obține ID-ul Punctului de Vânzare. Verificați configurația cheii API.';

// Callback
$_MODULE['<{ivomarketplace}prestashop>callback_1e4da6c30b41e9aaba6c78ca8f27b46a'] = 'IVO Marketplace a fost configurat cu succes!';
$_MODULE['<{ivomarketplace}prestashop>callback_df2e3c0cd17b3435d1dea9b4c47aef54'] = 'Mergi la Configurație';
$_MODULE['<{ivomarketplace}prestashop>callback_7a4d3a25a5c22e3e0a1b2c3d4e5f6a7b'] = 'Callback invalid: niciun nonce stocat';
$_MODULE['<{ivomarketplace}prestashop>callback_8b5e4f6a7c8d9e0f1a2b3c4d5e6f7a8b'] = 'Callback invalid: nonce nepotrivit';
$_MODULE['<{ivomarketplace}prestashop>callback_9c6f5a7b8d9e0f1a2b3c4d5e6f7a8b9c'] = 'Callback invalid: nonce expirat';
$_MODULE['<{ivomarketplace}prestashop>callback_0d7a6b8c9e0f1a2b3c4d5e6f7a8b9c0d'] = 'Callback invalid: nicio cheie API furnizată';

// Notification
$_MODULE['<{ivomarketplace}prestashop>notification_1e4da6c30b41e9aaba6c78ca8f27b46a'] = 'IVO Marketplace este instalat dar nu este configurat. Vă rugăm să îl configurați pentru a începe să vindeți pe IVO.';
$_MODULE['<{ivomarketplace}prestashop>notification_df2e3c0cd17b3435d1dea9b4c47aef54'] = 'Configurează';

// Admin Controller
$_MODULE['<{ivomarketplace}prestashop>adminivomarketplace_5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d'] = 'Niciun ID produs furnizat';
$_MODULE['<{ivomarketplace}prestashop>adminivomarketplace_6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e'] = 'Produs negăsit';
$_MODULE['<{ivomarketplace}prestashop>adminivomarketplace_5a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d'] = 'Nu s-a putut obține ID-ul Punctului de Vânzare. Verificați configurația cheii API.';
$_MODULE['<{ivomarketplace}prestashop>adminivomarketplace_7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f'] = 'Nu s-a putut pregăti încărcarea produsului';
$_MODULE['<{ivomarketplace}prestashop>adminivomarketplace_48ddffb48f52a62c97e9e3f7c0eb7c88'] = 'Produs sincronizat cu succes!';

// Info section
$_MODULE['<{ivomarketplace}prestashop>configure_1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d'] = 'Despre Integrarea IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>configure_2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e'] = 'Acest plugin integrează magazinul dvs. PrestaShop cu IVO Marketplace. Produsele dvs. vor fi sincronizate automat cu IVO, permițând clienților să le descopere și să le cumpere prin platforma IVO.';
$_MODULE['<{ivomarketplace}prestashop>configure_3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f'] = 'Caracteristici:';
$_MODULE['<{ivomarketplace}prestashop>configure_4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a'] = 'Sincronizare automată a produselor la salvare';
$_MODULE['<{ivomarketplace}prestashop>configure_5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b'] = 'Actualizări în timp real ale prețurilor și disponibilității';
$_MODULE['<{ivomarketplace}prestashop>configure_6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c'] = 'Vizualizați starea produselor pe IVO direct din PrestaShop';
$_MODULE['<{ivomarketplace}prestashop>configure_7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d'] = 'Sincronizare forțată a tuturor produselor cu un singur clic';
