<?php
/**
 * IVO Marketplace - Romanian translations
 *
 * Keys are PrestaShop's: <{ivomarketplace}prestashop>{source}_{md5 of the English string},
 * source = 'ivomarketplace' for $this->l() / $this->module->l(), the .tpl file name for {l s=...}.
 * Generated from the strings in the code; a key that does not match its string is never used.
 */

global $_MODULE;
$_MODULE = [];

// Product page tab (views/templates/admin/product_tab.tpl)
$_MODULE['<{ivomarketplace}prestashop>product_tab_cde910880fe864a44f6c2b75b668738a'] = 'IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>product_tab_8524de963f07201e5c086830d370797f'] = 'Se încarcă...';
$_MODULE['<{ivomarketplace}prestashop>product_tab_727b632b862ad3c1a414540f699f0aa7'] = 'Vezi produsul';
$_MODULE['<{ivomarketplace}prestashop>product_tab_77e5b5f37adbfa981566ea1f11e36ccd'] = 'Sincronizează forțat cu IVO';
$_MODULE['<{ivomarketplace}prestashop>product_tab_9bbdfef6acb6f4e71c65a98def532a53'] = 'Produsul nu a fost încă sincronizat cu IVO.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_bb5d0f787fbce054117cf5aaf8ee1339'] = 'Produsul este în coada de procesare.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_d7b08e850f6012be6568b3975c3fe317'] = 'Produsul este în curs de procesare.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_a79222e03adc06731b8f2727b7230f78'] = 'Produs creat, dar încă în așteptarea aprobării.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_5fe19eeac74368fbb0d2737a82dd59f9'] = 'A apărut o eroare în timpul importului.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_540395b13d34d6e50b85efbf141a1f4a'] = 'Detaliile produsului sunt prea generice pentru a identifica cu exactitate articolul vândut.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_39f9bc777573c93180ae3e765cc43246'] = 'Detaliile produsului sunt prea generice pentru a genera o listare validă.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_efd382778d827d6de0a02a20fc2d63ac'] = 'Comerciantul nu este autorizat pentru categoria produsului.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_d3912b5aee4a0716e97107547f97e0f6'] = 'Oferta a fost ștearsă din marketplace.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_462b9a7180c68efc83b7065f641c17fa'] = 'Produsul nu a fost găsit în marketplace.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_53f2b9b2573884d7da55dd82062a35e3'] = 'Stare IVO';
$_MODULE['<{ivomarketplace}prestashop>product_tab_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activ';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2d13df6f8b5e4c5af9f87e0dc39df69d'] = 'În așteptare';
$_MODULE['<{ivomarketplace}prestashop>product_tab_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Eroare';
$_MODULE['<{ivomarketplace}prestashop>product_tab_4482b7b9909825f739ac5e4fb15f5f2c'] = 'Nesincronizat';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2914489688e275fce13a252499c09613'] = 'Produsul este vizibil și poate fi cumpărat.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_beba094108e5b0d290ed7a3cd7a08bbd'] = 'Eroare de conexiune.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_59468337d52a54fd6dbde8f39b451f21'] = 'Stare necunoscută';
$_MODULE['<{ivomarketplace}prestashop>product_tab_ece4ac8ca191a4b51ba732b2c179e96c'] = 'Produs sincronizat cu succes!';
$_MODULE['<{ivomarketplace}prestashop>product_tab_b21888f3f83c224b3451901da243d00a'] = 'Se sincronizează...';
$_MODULE['<{ivomarketplace}prestashop>product_tab_47ac923d219501859fb68fed8c8db77b'] = 'Combinație';
$_MODULE['<{ivomarketplace}prestashop>product_tab_f22b5361b0466ae72234d83ff849dde0'] = 'Se actualizează starea...';

// Module, settings page, sync, setup return page (ivomarketplace.php, controllers)
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_0cbc72d214635b6f50c970d30126fefd'] = 'Cerere invalidă: lipsește tokenul de securitate';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_2b64553a0f956b660a63db5fc8242d42'] = 'Cerere invalidă: tokenul de securitate nu corespunde';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c670d9f899353c5fbcaa025bb164202d'] = 'Cererea a expirat. Porniți din nou procesul de configurare.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_ff10eabd3432cc85a6189d65deb56222'] = 'Cheia API este obligatorie';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_9a8f3f1ef2d2ce3d8e1c4e0e9947949e'] = 'Alegeți punctul de vânzare în setările IVO Marketplace și salvați-le.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_53191418108a675da9c4735322ba7535'] = 'Configurare reușită';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d26dae67284bf3aee4365d7d1143f2ea'] = 'Configurare eșuată';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_187f5ab8225cbbd54ce1e1ea378943b3'] = 'Cheia API IVO Marketplace a fost configurată cu succes.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f93cc986f4f506384a9633b30c298640'] = 'Mergi la panoul de administrare';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e03e5e87f7c34a203964ea9eac395ffb'] = 'Datele produsului nu au putut fi pregătite sau lipsește ID-ul Punctului de Vânzare';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_15c059299196d7026733e682cd66fd34'] = 'Produsul nu poate fi sincronizat. Asigurați-vă că are un nume și un preț valid.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_ece4ac8ca191a4b51ba732b2c179e96c'] = 'Produs sincronizat cu succes!';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_1f4814e7925cd3f76c81df758e481759'] = 'Sincronizarea a eșuat. Cod API: %s';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f8265712eaac1d6e77a9bd4f27c32435'] = 'Neconfigurat.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_cde910880fe864a44f6c2b75b668738a'] = 'IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e48c39dcb51c25e94e312530aa56a285'] = 'Sincronizați produsele cu IVO Marketplace. Vindeți pe cel mai mare marketplace din Moldova direct din magazinul PrestaShop.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_04eae874e1696143c3423746445ad4b7'] = 'Sigur doriți să dezinstalați IVO Marketplace?';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c888438d14855d7d96a2724ee9c306bd'] = 'Setările au fost actualizate';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_5048c9e35c601b89e183482fee8cb243'] = 'Eroare API necunoscută';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_3e95c8932645ff1c8467d6f5b387fd27'] = 'Vă rugăm să selectați un Punct de Vânzare. Pluginul nu va sincroniza produsele până când nu este selectat un punct de vânzare.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d8417b97b88c60d4403613297001f1e4'] = 'Editare IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e89bcf76a55ad7449ce284b3567b0076'] = 'IVO Marketplace este instalat, dar nu este configurat. Vă rugăm să îl configurați pentru a începe să vindeți pe IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_2ec0d16e4ca169baedb9b2d50ec5c6d7'] = 'Conectat';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7b277018e43d41bc445731092b91547d'] = 'Neconectat';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8dadf942f38e01ad6040440ee3034477'] = 'Conector PrestaShop';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_68483e2da4e69bacf618a9cc34546fbd'] = 'Conectați-vă magazinul la IVO.md.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7b1a5d6cd161c259c418b787e1fa0f23'] = 'Autorizați contul de marketplace, alegeți ce se sincronizează, apoi lăsați PrestaShop și IVO să lucreze împreună.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_ab29890d2e8ef2c2a5382a61986dfba7'] = 'Configurează conexiunea';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d66433aad0ca295bda25cb14df12e406'] = 'Vezi ghidul de configurare';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f4f70727dc34561dfde1a3c529b6205c'] = 'Setări';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_592040d1265285e9803b5ba434d1b649'] = 'Acces cont';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_afb8496e97e5e1098a29312b56bb00ee'] = 'Adăugați cheia API IVO și identificatorul de comerciant.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_505a83f220c02df2f85c3810cd9ceb38'] = 'Succes';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Eroare';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_0fe1a4c72924c615cd64dc9782a46549'] = 'Eroare IVO:';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_b651efdb98a5d6bd2b3935d0c3f4a5e2'] = 'Necesar';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_31bf76e739a83c1da9b27efc8fdf5add'] = 'Sincronizare produse';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_0da21636f985cea29b6188bdf343168a'] = 'Asociați categoriile, prețurile, stocurile și imaginile.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activ';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_3cab03c00dbd11bc3569afa0748013f0'] = 'Inactiv';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Următorul';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7a0d24a4e1055a0dfc8c893c1c4434e9'] = 'Actualizare stoc';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f7d7ed6053dd96e5c36b855082f43af0'] = 'Sincronizați automat stocurile între magazin și IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e7d31fc0602fb2ede144d18cdffd816b'] = 'Pregătit';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d876ff8da67c3731ae25d8335a4168b4'] = 'Cheie API';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e5af3c1a8298ee31ba83864491e6f1fe'] = 'Punct de Vânzare';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f701570c8fbc03f48b190d0b46e036e4'] = 'Modificator de preț (%)';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_3a9eb90c2d225ccc67d1483982bc5834'] = 'Ajustează prețurile produselor trimise la IVO. Introduceți un procent de creștere sau de reducere (de ex. +10 sau -5). Folosiți 0 pentru a nu modifica prețurile.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_41708507781c27721e8828100fc4546a'] = 'Actualizează stocul la vânzare';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_4f976dfd7b53fe8c26987eb51cbdb80d'] = 'Scade automat stocul local când se plasează o comandă pe IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c98bfd8822cb543b5d61feb87d5999fe'] = '--- Selectați ---';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f1206f9fadc5ce41694f69129aecac26'] = 'Configurează';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_bb2d5ec8a4ac86b6601dd938cbadef8b'] = 'Reconfigurează';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_77e5b5f37adbfa981566ea1f11e36ccd'] = 'Sincronizează forțat cu IVO';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c9cc8cce247e49bae79f15173ce97354'] = 'Salvează';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_b21888f3f83c224b3451901da243d00a'] = 'Se sincronizează...';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_a626144d9ef5ea815db4a5ba1f195744'] = 'Sincronizarea produselor a început cu succes.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f01f24605129c6adb3386583c2063289'] = 'Sincronizate %s din %s produse...';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_eb2461b135e3a8c55d9177bc8d325f36'] = 'Serverul magazinului nu se poate conecta la IVO (%1$s): %2$s. Cereți furnizorului de hosting să permită conexiunile HTTPS de ieșire către %1$s.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_6ec861f4de5b5a65fa9488589ab500ff'] = 'IVO a respins cheia API: a fost revocată sau nu este validă. Apăsați „Configurează conexiunea” pentru a conecta din nou magazinul.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8e62d8c1c54d1701d4366a41bc7478fd'] = 'Integrarea IVO a acestui magazin este dezactivată. Activați-o în contul de comerciant IVO, la Setări → Integrări.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_95ba3fffd1a2bfc5580eafdb8b5e3c70'] = 'IVO nu a găsit contul de comerciant pentru această cheie API. Apăsați „Configurează conexiunea” pentru a conecta din nou magazinul.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7c5669df980c7d8f20a452adaf44377a'] = 'IVO a răspuns cu o eroare (HTTP %1$s%2$s). Încercați din nou peste câteva minute.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_44eaf05b7481699dc56b578c3429846a'] = 'Răspunsul de la IVO nu a putut fi citit (HTTP %1$s). Un proxy sau un firewall de pe server poate modifica conexiunea către %2$s.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_77d7f2a50870cccab52b4349c78e7548'] = 'Contul de comerciant IVO nu are niciun punct. Adăugați unul pe pagina „Puncte comerciant” din contul IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_b2981c3b3747872ff18c3a4bd824d67a'] = 'Nu este salvată nicio cheie API IVO. Conectați din nou magazinul la IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8a9898a0a810314ce5774ff226e52fe4'] = 'Nu s-a putut obține ID-ul Punctului de Vânzare. Verificați configurația cheii API.';
