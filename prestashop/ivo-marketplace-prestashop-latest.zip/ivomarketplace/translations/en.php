<?php
/**
 * IVO Marketplace - English Translations
 */

global $_MODULE;
$_MODULE = [];

// Module name and description
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d41d8cd98f00b204e9800998ecf8427e'] = '';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8ff23cb7ea63e9b21eae7d02ad179dd1'] = 'IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_96f0708bdcabf9c17f9d97d73c84c96a'] = 'Sync your products with IVO Marketplace. Sell on Moldova\'s largest marketplace directly from your PrestaShop store.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8acf2a57da2e7db1927b49f92f8e3ed9'] = 'Are you sure you want to uninstall IVO Marketplace?';

// Configuration page
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{ivomarketplace}prestashop>configure_8ff23cb7ea63e9b21eae7d02ad179dd1'] = 'IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>configure_96f0708bdcabf9c17f9d97d73c84c96a'] = 'Sync your products with IVO Marketplace. Sell on Moldova\'s largest marketplace directly from your PrestaShop store.';
$_MODULE['<{ivomarketplace}prestashop>configure_b7b1e314614cf326c6e2b6eba1540682'] = 'Edit IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>configure_1e4da6c30b41e9aaba6c78ca8f27b46a'] = 'IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.';
$_MODULE['<{ivomarketplace}prestashop>configure_b39939c6d5ed67e81ce03ab7cec3e92d'] = 'API Key';
$_MODULE['<{ivomarketplace}prestashop>configure_a97da2ba7ea1ecd79edaf49f5b04e1de'] = 'Merchant Point';
$_MODULE['<{ivomarketplace}prestashop>configure_b85bd8f6c7835f9a21e68fd41b0e27fd'] = '--- Select ---';
$_MODULE['<{ivomarketplace}prestashop>configure_e2aeb51de42e3ab1a9fdb33f2b0a13b5'] = 'Please select a Merchant Point. The plugin will not sync products until a merchant point is selected.';
$_MODULE['<{ivomarketplace}prestashop>configure_df2e3c0cd17b3435d1dea9b4c47aef54'] = 'Configure';
$_MODULE['<{ivomarketplace}prestashop>configure_8dcd5e32c397d8d72a1eb7be32acae70'] = 'Reconfigure';
$_MODULE['<{ivomarketplace}prestashop>configure_3c99e98e06e65c52dbb60e3c3cbdecfc'] = 'Force Sync with IVO';
$_MODULE['<{ivomarketplace}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{ivomarketplace}prestashop>configure_88183b946cc5f0e8c96b2e66e1c74a7e'] = 'Syncing...';
$_MODULE['<{ivomarketplace}prestashop>configure_f1d6be73b21bc3a8e70b9a2c2c8e87f7'] = 'Products synchronization started successfully.';

// Status messages
$_MODULE['<{ivomarketplace}prestashop>product_tab_4ec3f789fc22c5e2b5e8f22a3cb7d04a'] = 'IVO Status';
$_MODULE['<{ivomarketplace}prestashop>product_tab_1243daf593fa297e07ab03bf06d925af'] = 'Loading...';
$_MODULE['<{ivomarketplace}prestashop>product_tab_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Active';
$_MODULE['<{ivomarketplace}prestashop>product_tab_3cab03c00dbd11bc3569afa0748013f0'] = 'Inactive';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2d13df6f8b5e4c5af9f87e0dc39df69d'] = 'Pending';
$_MODULE['<{ivomarketplace}prestashop>product_tab_72d6d7a1885885bb55a565fd1070581a'] = 'Not Synced';
$_MODULE['<{ivomarketplace}prestashop>product_tab_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Error';
$_MODULE['<{ivomarketplace}prestashop>product_tab_0557fa923dcee4d0f86b1409f5c2167f'] = 'Unknown';
$_MODULE['<{ivomarketplace}prestashop>product_tab_15ba57a3c1398a2de25f700c21e9a13d'] = 'The product is visible and purchasable.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_6e72e76bdda6be2d2d18d94b5ff0ed3e'] = 'View Product';
$_MODULE['<{ivomarketplace}prestashop>product_tab_f047bf1d35c21c0be4bba90fe6badb41'] = 'Connection error.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_48ddffb48f52a62c97e9e3f7c0eb7c88'] = 'Product synced successfully!';

// Detailed status messages
$_MODULE['<{ivomarketplace}prestashop>product_tab_47e91f67d30d3a12bcdf19fd7b2c9f52'] = 'Product has not been synced to IVO yet.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_6ee8bd5c38def88f7c8ab8b94b6dbafc'] = 'Product is queued for processing.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_d9f068e46cd8ad9a2f781d77ce0dbd11'] = 'Product is being processed.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_3c5aea3b8dc0eb60ae1aab7a87ee2e23'] = 'Product is pending approval.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_bb4467c3c30ba4cd32d0e93e3e0e929d'] = 'An error occurred during import.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_f15ebf88a4dd15d1de753e5eb6ce7de0'] = 'Product was skipped - no matching catalog item found.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_6c1c97f2e1c1d4f7fcccb0a5c1f43d17'] = 'Merchant is not authorized for this product category.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_d1234c1d897e07b86b3e9a8e4f2b5d6a'] = 'The offer has been deleted from the marketplace.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_a8b69f4e5c3d2b1a0f9e8d7c6b5a4321'] = 'Offer not found on the marketplace.';

// Sync messages
$_MODULE['<{ivomarketplace}prestashop>product_tab_d7c8942b7c8c2e1d0a9b8c7d6e5f4a3b'] = 'Sync with IVO';
$_MODULE['<{ivomarketplace}prestashop>product_tab_88183b946cc5f0e8c96b2e66e1c74a7e'] = 'Syncing...';

// Error messages
$_MODULE['<{ivomarketplace}prestashop>configure_f047bf1d35c21c0be4bba90fe6badb41'] = 'Connection error.';
$_MODULE['<{ivomarketplace}prestashop>configure_1d2f5a8b9c3e4d7f6a0b1c2e3d4f5a6b'] = 'API Error';

// Info section
$_MODULE['<{ivomarketplace}prestashop>configure_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{ivomarketplace}prestashop>configure_689202409e48743b914713f96d93947c'] = 'Version';
$_MODULE['<{ivomarketplace}prestashop>configure_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_MODULE['<{ivomarketplace}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
