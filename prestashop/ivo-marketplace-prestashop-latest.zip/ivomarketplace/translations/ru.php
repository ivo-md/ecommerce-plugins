<?php
/**
 * IVO Marketplace - Russian translations
 *
 * Keys are PrestaShop's: <{ivomarketplace}prestashop>{source}_{md5 of the English string},
 * source = 'ivomarketplace' for $this->l() / $this->module->l(), the .tpl file name for {l s=...}.
 * Generated from the strings in the code; a key that does not match its string is never used.
 */

global $_MODULE;
$_MODULE = [];

// Product page tab (views/templates/admin/product_tab.tpl)
$_MODULE['<{ivomarketplace}prestashop>product_tab_cde910880fe864a44f6c2b75b668738a'] = 'IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>product_tab_8524de963f07201e5c086830d370797f'] = 'Загрузка...';
$_MODULE['<{ivomarketplace}prestashop>product_tab_727b632b862ad3c1a414540f699f0aa7'] = 'Посмотреть товар';
$_MODULE['<{ivomarketplace}prestashop>product_tab_77e5b5f37adbfa981566ea1f11e36ccd'] = 'Принудительная синхронизация с IVO';
$_MODULE['<{ivomarketplace}prestashop>product_tab_9bbdfef6acb6f4e71c65a98def532a53'] = 'Товар ещё не синхронизирован с IVO.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_bb5d0f787fbce054117cf5aaf8ee1339'] = 'Товар в очереди на обработку.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_d7b08e850f6012be6568b3975c3fe317'] = 'Товар в процессе обработки.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_a79222e03adc06731b8f2727b7230f78'] = 'Товар создан, но ожидает одобрения.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_5fe19eeac74368fbb0d2737a82dd59f9'] = 'Произошла ошибка при импорте.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_540395b13d34d6e50b85efbf141a1f4a'] = 'Описание товара слишком общее, чтобы точно определить продаваемый товар.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_39f9bc777573c93180ae3e765cc43246'] = 'Описание товара слишком общее, чтобы создать корректное объявление.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_efd382778d827d6de0a02a20fc2d63ac'] = 'Продавец не авторизован для этой категории товаров.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_d3912b5aee4a0716e97107547f97e0f6'] = 'Предложение было удалено с маркетплейса.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_462b9a7180c68efc83b7065f641c17fa'] = 'Товар не найден на маркетплейсе.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_53f2b9b2573884d7da55dd82062a35e3'] = 'Статус IVO';
$_MODULE['<{ivomarketplace}prestashop>product_tab_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Активен';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2d13df6f8b5e4c5af9f87e0dc39df69d'] = 'В ожидании';
$_MODULE['<{ivomarketplace}prestashop>product_tab_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Ошибка';
$_MODULE['<{ivomarketplace}prestashop>product_tab_4482b7b9909825f739ac5e4fb15f5f2c'] = 'Не синхронизирован';
$_MODULE['<{ivomarketplace}prestashop>product_tab_2914489688e275fce13a252499c09613'] = 'Товар виден и доступен для покупки.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_beba094108e5b0d290ed7a3cd7a08bbd'] = 'Ошибка соединения.';
$_MODULE['<{ivomarketplace}prestashop>product_tab_59468337d52a54fd6dbde8f39b451f21'] = 'Неизвестный статус';
$_MODULE['<{ivomarketplace}prestashop>product_tab_ece4ac8ca191a4b51ba732b2c179e96c'] = 'Товар успешно синхронизирован!';
$_MODULE['<{ivomarketplace}prestashop>product_tab_b21888f3f83c224b3451901da243d00a'] = 'Синхронизация...';
$_MODULE['<{ivomarketplace}prestashop>product_tab_47ac923d219501859fb68fed8c8db77b'] = 'Комбинация';
$_MODULE['<{ivomarketplace}prestashop>product_tab_f22b5361b0466ae72234d83ff849dde0'] = 'Обновление статуса...';

// Module, settings page, sync, setup return page (ivomarketplace.php, controllers)
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_0cbc72d214635b6f50c970d30126fefd'] = 'Некорректный запрос: отсутствует токен безопасности';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_2b64553a0f956b660a63db5fc8242d42'] = 'Некорректный запрос: токен безопасности не совпадает';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c670d9f899353c5fbcaa025bb164202d'] = 'Срок действия запроса истёк. Запустите настройку заново.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_ff10eabd3432cc85a6189d65deb56222'] = 'Требуется ключ API';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_9a8f3f1ef2d2ce3d8e1c4e0e9947949e'] = 'Выберите точку продаж в настройках IVO Marketplace и сохраните их.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_53191418108a675da9c4735322ba7535'] = 'Настройка завершена';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d26dae67284bf3aee4365d7d1143f2ea'] = 'Ошибка настройки';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_187f5ab8225cbbd54ce1e1ea378943b3'] = 'API-ключ IVO Marketplace успешно настроен.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f93cc986f4f506384a9633b30c298640'] = 'Перейти в панель администратора';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e03e5e87f7c34a203964ea9eac395ffb'] = 'Не удалось подготовить данные товара или не указан ID точки продаж';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_15c059299196d7026733e682cd66fd34'] = 'Товар не может быть синхронизирован. Убедитесь, что у него есть название и корректная цена.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_ece4ac8ca191a4b51ba732b2c179e96c'] = 'Товар успешно синхронизирован!';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_1f4814e7925cd3f76c81df758e481759'] = 'Синхронизация не удалась. Код API: %s';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f8265712eaac1d6e77a9bd4f27c32435'] = 'Не настроено.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_cde910880fe864a44f6c2b75b668738a'] = 'IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e48c39dcb51c25e94e312530aa56a285'] = 'Синхронизируйте товары с IVO Marketplace. Продавайте на крупнейшем маркетплейсе Молдовы прямо из магазина PrestaShop.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_04eae874e1696143c3423746445ad4b7'] = 'Вы уверены, что хотите удалить IVO Marketplace?';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_5048c9e35c601b89e183482fee8cb243'] = 'Неизвестная ошибка API';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_3e95c8932645ff1c8467d6f5b387fd27'] = 'Пожалуйста, выберите точку продаж. Плагин не будет синхронизировать товары, пока не выбрана точка продаж.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d8417b97b88c60d4403613297001f1e4'] = 'Редактирование IVO Marketplace';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e89bcf76a55ad7449ce284b3567b0076'] = 'IVO Marketplace установлен, но не настроен. Пожалуйста, настройте его, чтобы начать продавать на IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_2ec0d16e4ca169baedb9b2d50ec5c6d7'] = 'Подключено';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7b277018e43d41bc445731092b91547d'] = 'Не подключено';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8dadf942f38e01ad6040440ee3034477'] = 'Мост PrestaShop';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_68483e2da4e69bacf618a9cc34546fbd'] = 'Подключите свой магазин к IVO.md.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7b1a5d6cd161c259c418b787e1fa0f23'] = 'Авторизуйте свой аккаунт на маркетплейсе, выберите, что синхронизировать, и позвольте PrestaShop и IVO работать вместе.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_ab29890d2e8ef2c2a5382a61986dfba7'] = 'Настроить подключение';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d66433aad0ca295bda25cb14df12e406'] = 'Посмотреть руководство по настройке';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_592040d1265285e9803b5ba434d1b649'] = 'Доступ к аккаунту';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_afb8496e97e5e1098a29312b56bb00ee'] = 'Добавьте API-ключ IVO и идентификатор продавца.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_505a83f220c02df2f85c3810cd9ceb38'] = 'Успех';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Ошибка';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_0fe1a4c72924c615cd64dc9782a46549'] = 'Ошибка IVO:';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_b651efdb98a5d6bd2b3935d0c3f4a5e2'] = 'Обязательно';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_31bf76e739a83c1da9b27efc8fdf5add'] = 'Синхронизация товаров';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_0da21636f985cea29b6188bdf343168a'] = 'Сопоставьте категории, цены, остатки и изображения.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Активен';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_3cab03c00dbd11bc3569afa0748013f0'] = 'Неактивен';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Далее';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7a0d24a4e1055a0dfc8c893c1c4434e9'] = 'Обновление остатков';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f7d7ed6053dd96e5c36b855082f43af0'] = 'Автоматически синхронизируйте остатки между магазином и IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e7d31fc0602fb2ede144d18cdffd816b'] = 'Готово';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_d876ff8da67c3731ae25d8335a4168b4'] = 'Ключ API';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_e5af3c1a8298ee31ba83864491e6f1fe'] = 'Точка продаж';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f701570c8fbc03f48b190d0b46e036e4'] = 'Модификатор цены (%)';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_3a9eb90c2d225ccc67d1483982bc5834'] = 'Корректирует цены товаров, отправляемых в IVO. Укажите процент повышения или снижения (например, +10 или -5). Укажите 0, чтобы не менять цены.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_41708507781c27721e8828100fc4546a'] = 'Обновлять наличие при продаже';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_4f976dfd7b53fe8c26987eb51cbdb80d'] = 'Автоматически списывать остаток в магазине, когда на IVO оформлен заказ.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c98bfd8822cb543b5d61feb87d5999fe'] = '--- Выберите ---';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f1206f9fadc5ce41694f69129aecac26'] = 'Настроить';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_bb2d5ec8a4ac86b6601dd938cbadef8b'] = 'Перенастроить';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_77e5b5f37adbfa981566ea1f11e36ccd'] = 'Принудительная синхронизация с IVO';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_b21888f3f83c224b3451901da243d00a'] = 'Синхронизация...';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_a626144d9ef5ea815db4a5ba1f195744'] = 'Синхронизация товаров успешно запущена.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_f01f24605129c6adb3386583c2063289'] = 'Синхронизировано %s из %s товаров...';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_eb2461b135e3a8c55d9177bc8d325f36'] = 'Сервер магазина не может подключиться к IVO (%1$s): %2$s. Попросите хостинг-провайдера разрешить исходящие HTTPS-соединения к %1$s.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_6ec861f4de5b5a65fa9488589ab500ff'] = 'IVO отклонил API-ключ: он отозван или недействителен. Нажмите «Настроить подключение», чтобы подключить магазин заново.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8e62d8c1c54d1701d4366a41bc7478fd'] = 'Интеграция IVO для этого магазина отключена. Включите её в аккаунте продавца IVO: Настройки → Интеграции.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_95ba3fffd1a2bfc5580eafdb8b5e3c70'] = 'IVO не нашёл аккаунт продавца для этого API-ключа. Нажмите «Настроить подключение», чтобы подключить магазин заново.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_7c5669df980c7d8f20a452adaf44377a'] = 'IVO вернул ошибку (HTTP %1$s%2$s). Повторите попытку через несколько минут.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_44eaf05b7481699dc56b578c3429846a'] = 'Не удалось прочитать ответ IVO (HTTP %1$s). Прокси или файрвол на сервере может изменять соединение с %2$s.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_77d7f2a50870cccab52b4349c78e7548'] = 'В аккаунте продавца IVO нет ни одного пункта. Добавьте его на странице «Пункты продавца» в аккаунте IVO.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_b2981c3b3747872ff18c3a4bd824d67a'] = 'API-ключ IVO не сохранён. Подключите магазин к IVO заново.';
$_MODULE['<{ivomarketplace}prestashop>ivomarketplace_8a9898a0a810314ce5774ff226e52fe4'] = 'Не удалось получить ID точки продаж. Проверьте настройку ключа API.';
