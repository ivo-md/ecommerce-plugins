/**
 * IVO Marketplace Admin JavaScript
 * EXACT MATCH with Magento and OpenCart admin.js functionality
 */

(function() {
    'use strict';

    /**
     * IVO Marketplace Admin Module
     */
    var IvoMarketplace = {
        
        /**
         * Initialize module
         */
        init: function() {
            this.bindEvents();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Force Sync lives in configure.tpl's own script (sliced sync)

            // Product sync button
            var syncProductBtn = document.getElementById('ivo-sync-product-btn');
            if (syncProductBtn) {
                syncProductBtn.addEventListener('click', this.handleSyncProduct.bind(this));
            }

            // Auto-fetch product status
            var statusContainer = document.getElementById('ivo-status-container');
            if (statusContainer) {
                this.fetchProductStatus();
            }
        },

        /**
         * Handle Sync Single Product
         * EXACT MATCH with WooCommerce handleSyncProduct()
         */
        handleSyncProduct: function(e) {
            var btn = e.target;
            var container = document.getElementById('ivo-status-container');
            var statusEl = document.getElementById('ivo-sync-status');
            
            if (!container) {
                console.error('IVO: No status container found');
                return;
            }

            var productId = container.getAttribute('data-product-id');
            var syncUrl = btn.getAttribute('data-sync-url') || 
                         window.ivoSyncUrl || 
                         this.getSyncUrl(productId);

            // Disable button and show spinner
            btn.disabled = true;
            if (statusEl) {
                statusEl.style.display = 'inline';
            }

            var self = this;

            // Make AJAX request
            this.ajax(syncUrl, {}, function(response) {
                btn.disabled = false;
                if (statusEl) {
                    statusEl.style.display = 'none';
                }

                if (response.success) {
                    alert(response.message || 'Product synced successfully!');
                    // IVO processes sync asynchronously — wait before re-checking status
                    setTimeout(function() {
                        self.fetchProductStatus();
                    }, 5000);
                } else {
                    alert(response.message || 'Sync failed. Please try again.');
                }
            }, function(error) {
                btn.disabled = false;
                if (statusEl) {
                    statusEl.style.display = 'none';
                }
                alert('Error: ' + (error.message || 'Connection failed'));
            });
        },

        /**
         * Fetch Product Status from IVO
         * EXACT MATCH with OpenCart getProductStatus()
         */
        fetchProductStatus: function() {
            var container = document.getElementById('ivo-status-container');
            if (!container) return;

            var productId = container.getAttribute('data-product-id');
            var statusUrl = container.getAttribute('data-status-url') || 
                           window.ivoStatusUrl ||
                           this.getStatusUrl(productId);

            var badge = document.getElementById('ivo-status-badge');
            var message = document.getElementById('ivo-status-message');
            var viewLinkRow = document.getElementById('ivo-view-link-row');
            var viewLink = document.getElementById('ivo-view-link');

            // Show loading state
            if (badge) {
                badge.className = 'label label-default';
                badge.innerHTML = '<i class="icon-spinner icon-spin"></i> Loading...';
            }
            if (message) {
                message.textContent = '';
            }
            if (viewLinkRow) {
                viewLinkRow.style.display = 'none';
            }

            // Fetch status
            this.ajax(statusUrl, {}, function(response) {
                if (response.success) {
                    var status = response.status || 'unknown';
                    var statusText = response.status_text || status;
                    var statusMessage = response.message || '';
                    var productUrl = response.product_url || '';

                    // Update badge
                    if (badge) {
                        badge.className = 'label ' + IvoMarketplace.getStatusClass(status);
                        badge.innerHTML = statusText;
                    }

                    // Update message
                    if (message) {
                        message.textContent = statusMessage;
                    }

                    // Show/hide view link
                    if (status === 'active' && productUrl) {
                        if (viewLink) {
                            viewLink.href = productUrl;
                        }
                        if (viewLinkRow) {
                            viewLinkRow.style.display = 'block';
                        }
                    }
                } else {
                    if (badge) {
                        badge.className = 'label label-danger';
                        badge.innerHTML = (typeof textStatusError !== 'undefined' ? textStatusError : 'Error');
                    }
                    if (message) {
                        message.textContent = response.message || (typeof textConnectionError !== 'undefined' ? textConnectionError : 'Failed to fetch status');
                    }
                }
            }, function(error) {
                if (badge) {
                    badge.className = 'label label-danger';
                    badge.innerHTML = (typeof textStatusError !== 'undefined' ? textStatusError : 'Error');
                }
                if (message) {
                    message.textContent = (error && error.message) ? ((typeof textConnectionError !== 'undefined' ? textConnectionError : 'Connection error') + ' ' + error.message) : (typeof textConnectionError !== 'undefined' ? textConnectionError : 'Connection error');
                }
            });
        },

        /**
         * Get status badge class
         * EXACT MATCH with OpenCart statusClasses
         */
        getStatusClass: function(status) {
            var classes = {
                'active': 'label-success',
                'inactive': 'label-warning',
                'pending': 'label-info',
                'not_synced': 'label-default',
                'error': 'label-danger',
                'unknown': 'label-default'
            };
            return classes[status] || 'label-default';
        },

        /**
         * Make AJAX request
         */
        ajax: function(url, data, onSuccess, onError) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (onSuccess) onSuccess(response);
                        } catch (e) {
                            if (onError) onError({ message: 'Invalid JSON response' });
                        }
                    } else {
                        if (onError) onError({ message: 'HTTP ' + xhr.status });
                    }
                }
            };

            xhr.onerror = function() {
                if (onError) onError({ message: 'Network error' });
            };

            xhr.send();
        }
    };

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            IvoMarketplace.init();
        });
    } else {
        IvoMarketplace.init();
    }

    // Export for external access
    window.IvoMarketplace = IvoMarketplace;

})();
