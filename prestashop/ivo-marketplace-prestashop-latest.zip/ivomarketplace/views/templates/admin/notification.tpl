{**
 * IVO Marketplace Notification Template
 * EXACT MATCH with Magento CheckConfig Observer notification
 * 
 * Shows warning banner when module is not configured
 *}

<div class="alert alert-warning ivo-marketplace-notification">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <p>
        <i class="icon-warning"></i>
        <strong>{$message}</strong>
    </p>
    <p style="margin-top: 10px;">
        <a href="{$configure_url}" class="btn btn-sm btn-primary">
            <i class="icon-cog"></i> {$button_configure}
        </a>
    </p>
</div>
