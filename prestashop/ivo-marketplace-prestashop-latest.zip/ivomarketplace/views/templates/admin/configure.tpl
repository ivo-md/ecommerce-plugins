{**
 * IVO Marketplace Configuration Template
 *}

<style>
/* IVO Marketplace Admin CSS */
.ivo-card, .ivo-card * {
  box-sizing: border-box;
}

.ivo-card {
  --ivo-pink: #c711bd;
  --ivo-purple: #8a24d6;
  --ivo-blue: #273bd8;
  --ivo-ink: #101828;
  --ivo-muted: #667085;
  position: relative;
  overflow: hidden;
  width: 100%;
  max-width: 100%;
  min-height: 410px;
  border: 1px solid #dcdcde;
  border-radius: 6px;
  background:
    radial-gradient(circle at 82% 10%, rgba(199, 17, 189, .14), transparent 30%),
    radial-gradient(circle at 12% 90%, rgba(39, 59, 216, .12), transparent 34%),
    #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, .04);
  margin-top: 20px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}

.ivo-card__head {
  min-height: 56px;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 22px;
  border-bottom: 1px solid #e5e7eb;
  background: rgba(255, 255, 255, .76);
}

.ivo-card__icon {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  display: grid;
  place-items: center;
  color: #fff;
  background: linear-gradient(135deg, var(--ivo-pink), var(--ivo-blue));
  font-size: 15px;
}

.ivo-card__status {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 6px 10px;
  border-radius: 999px;
  background: #fff1fb;
  color: #9d1698;
  font-size: 12px;
  font-weight: 700;
  border: 1px solid #f4c7ef;
}

.ivo-card__status--connected {
  background: #ecfdf5;
  color: #047857;
  border-color: #a7f3d0;
}

.ivo-card__status-dot {
  width: 8px;
  height: 8px;
  border-radius: 99px;
  background: var(--ivo-pink);
  box-shadow: 0 0 0 4px rgba(199, 17, 189, .14);
}

.ivo-card__status-dot--connected {
  background: #10b981;
  box-shadow: 0 0 0 4px rgba(16, 185, 129, .14);
}

.ivo-card__body {
  display: flex;
  flex-wrap: wrap;
  gap: 36px;
  align-items: stretch;
  padding: 24px;
}
.ivo-card__body > div:first-child {
  flex: 1 1 300px;
  min-width: 0;
}

.ivo-card__logo {
  width: 76px;
  height: 76px;
  border-radius: 20px;
  display: grid;
  place-items: center;
  color: #fff;
  font-weight: 900;
  font-size: 26px;
  background: linear-gradient(135deg, var(--ivo-pink), var(--ivo-purple) 48%, var(--ivo-blue));
  box-shadow: 0 18px 40px rgba(39, 59, 216, .26);
  margin-bottom: 22px;
}

.ivo-card__eyebrow {
  margin: 0 0 10px;
  color: var(--ivo-purple);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .5px;
  text-transform: uppercase;
}

.ivo-card__body h2 {
  margin: 0 0 12px;
  font-size: 24px;
  font-weight: 600;
  color: var(--ivo-ink);
  line-height: 1.2;
}

.ivo-card__body p {
  margin: 0 0 24px;
  font-size: 14px;
  color: var(--ivo-muted);
  line-height: 1.5;
}

.ivo-card__actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 14px;
}

.ivo-card__button {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--ivo-purple);
  color: #fff !important;
  font-weight: 600;
  font-size: 14px;
  padding: 10px 18px;
  border-radius: 6px;
  text-decoration: none;
  transition: all .2s;
  border: none;
  cursor: pointer;
}
.ivo-card__button:hover {
  background: #7313b8;
  transform: translateY(-1px);
}

.ivo-card__button-secondary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: #fff;
  color: var(--ivo-ink) !important;
  font-weight: 600;
  font-size: 14px;
  padding: 10px 18px;
  border-radius: 6px;
  text-decoration: none;
  border: 1px solid #d0d5dd;
  transition: all .2s;
  cursor: pointer;
}
.ivo-card__button-secondary:hover {
  background: #f9fafb;
}

.ivo-card__link {
  color: var(--ivo-muted);
  font-weight: 500;
  font-size: 14px;
  text-decoration: none;
}
.ivo-card__link:hover {
  color: var(--ivo-ink);
}

.ivo-card__setup {
  flex: 0 1 340px;
  width: 100%;
}
.ivo-card__setup-box {
  background: rgba(255, 255, 255, .6);
  border: 1px solid rgba(255, 255, 255, .8);
  backdrop-filter: blur(8px);
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, .03);
}

.ivo-card__step {
  display: flex;
  gap: 14px;
  margin-bottom: 24px;
  position: relative;
}
.ivo-card__step:last-child {
  margin-bottom: 0;
}
.ivo-card__step::after {
  content: "";
  position: absolute;
  left: 11px;
  top: 28px;
  bottom: -20px;
  width: 2px;
  background: #f3f4f6;
}
.ivo-card__step:last-child::after {
  display: none;
}

.ivo-card__step-number {
  width: 24px;
  height: 24px;
  border-radius: 99px;
  background: var(--ivo-ink);
  color: #fff;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 700;
  flex-shrink: 0;
  z-index: 2;
}

.ivo-card__step strong {
  display: block;
  font-size: 13px;
  color: var(--ivo-ink);
  margin-bottom: 2px;
}
.ivo-card__step span {
  display: block;
  font-size: 12px;
  color: var(--ivo-muted);
  line-height: 1.4;
}

.ivo-card__tag {
  margin-left: auto;
  align-self: flex-start;
  font-size: 11px !important;
  font-weight: 600 !important;
  padding: 2px 8px !important;
  border-radius: 4px !important;
  background: #f3f4f6 !important;
  color: #4b5563 !important;
}
.ivo-card__tag--active {
  background: #eef2ff !important;
  color: #4f46e5 !important;
}
.ivo-card__tag--success {
  background: #ecfdf5 !important;
  color: #059669 !important;
}

.ivo-form-group {
  margin-bottom: 18px;
  max-width: 100%;
}
.ivo-form-group label {
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: var(--ivo-ink);
  margin-bottom: 6px;
  text-align: left;
}
.ivo-form-input, .ivo-form-select {
  width: 100%;
  max-width: 100%;
  padding: 8px 12px;
  border: 1px solid #d0d5dd;
  border-radius: 6px;
  font-size: 14px;
  background: #fff;
  box-shadow: 0 1px 2px rgba(16, 24, 40, .05);
}
.ivo-form-input:disabled {
  background: #f9fafb;
  color: var(--ivo-muted);
}
.ivo-form-group p.description {
  font-size: 12px;
  color: var(--ivo-muted);
  margin-top: 6px;
  margin-bottom: 0;
}

.ivo-sync-status {
  font-size: 13px;
  font-weight: 500;
  margin-left: 10px;
}
.ivo-sync-status .success { color: #059669; }
.ivo-sync-status .error { color: #dc2626; }

/* Responsive adjustments */
@media (max-width: 800px) {
  .ivo-card__setup {
    flex: 1 1 100%;
  }
}
</style>

<div class="panel" style="padding: 0; background: transparent; border: none; box-shadow: none; width: 60%; margin: 0 auto;">
<div class="ivo-card">
  <div class="ivo-card__head">
    <div class="ivo-card__icon"><i class="icon-cog"></i></div>
    {if $configured}
      <div class="ivo-card__status ivo-card__status--connected">
        <div class="ivo-card__status-dot ivo-card__status-dot--connected"></div>
        {$text_connected}
      </div>
    {else}
      <div class="ivo-card__status">
        <div class="ivo-card__status-dot"></div>
        {$text_status_inactive}
      </div>
    {/if}
  </div>

  <div class="ivo-card__body">
    <div>
      <div class="ivo-card__logo">
        <img src="https://static.ivo.md/favicon_white.png" alt="IVO" style="width: 42px; height: 42px; object-fit: contain; display: block;" />
      </div>
      <p class="ivo-card__eyebrow">{$text_bridge}</p>

      {if !$configured || !$api_valid}
        <h2>{$text_connect_prompt}</h2>
        <p>{$text_connect_desc}</p>
        
        {if !$api_valid && $configured}
        <div class="alert alert-danger" style="margin-bottom: 20px;">
            <i class="icon-exclamation-triangle"></i>
            <strong>IVO API Error:</strong> {$api_error}
        </div>
        {/if}

        <div class="ivo-card__actions">
          <button type="button" class="ivo-card__button btn-setup" data-url="{$setup_ajax_url}">
              <i class="icon-external-link"></i> {$text_configure_conn}
          </button>
          <a href="{$help_guide_url}" target="_blank" class="ivo-card__link">{$text_view_guide}</a>
        </div>
      {else}
        <h2>{$text_settings}</h2>
        
        {if $merchant_point_warning}
        <div class="alert alert-warning" style="margin-bottom: 20px;">
            <i class="icon-exclamation-triangle"></i>
            <strong>{$merchant_point_warning}</strong>
        </div>
        {/if}
        
        <form id="form-ivo-marketplace" action="{$current_url}" method="post" style="margin-top: 24px;">

          <div class="ivo-form-group">
            <label>{$text_api_key}</label>
            <input type="text" value="{$api_key_masked}" class="ivo-form-input" readonly disabled />
          </div>

          <div class="ivo-form-group">
            <label>{$text_merchant_point}</label>
            <select name="{$config_merchant_point_id}" class="ivo-form-select">
              <option value="">{$text_select}</option>
              {foreach from=$merchant_points item=point}
                <option value="{$point.id}" {if $merchant_point_id == $point.id}selected="selected"{/if}>
                  {$point.name}{if isset($point.address) && $point.address} - {$point.address}{/if}
                </option>
              {/foreach}
            </select>
          </div>

          <div class="ivo-form-group">
            <label>{$text_price_modifier}</label>
            <input type="number" step="0.01" name="{$config_price_modifier}" value="{$price_modifier}" class="ivo-form-input" />
            <p class="description">{$text_price_modifier_help}</p>
          </div>

          <div class="ivo-form-group" style="display: flex; align-items: flex-start; gap: 10px;">
            <input type="hidden" name="{$config_update_stock}" value="0" />
            <input type="checkbox" id="ivo_update_stock" name="{$config_update_stock}" value="1" {if $update_stock}checked="checked"{/if} style="margin-top: 4px; width: 16px; height: 16px; accent-color: var(--ivo-purple);" />
            <div>
              <label for="ivo_update_stock" style="margin-bottom: 2px; cursor: pointer;">{$text_update_stock}</label>
              <p class="description" style="margin-top: 0;">{$text_update_stock_help}</p>
            </div>
          </div>

          <div class="ivo-card__actions" style="margin-top: 26px;">
            <button type="submit" name="submit{$module_name}" class="ivo-card__button">
                <i class="icon-save"></i> {$button_save}
            </button>
            <button type="button" class="ivo-card__button-secondary btn-setup" data-url="{$setup_ajax_url}">
                {$button_reconfigure}
            </button>
            <button type="button" id="btn-force-sync" class="ivo-card__button-secondary" data-url="{$sync_url}">
              <i class="icon-refresh"></i> {$button_force_sync}
            </button>
            <span id="sync-status" class="ivo-sync-status"></span>
          </div>
        </form>
      {/if}
    </div>

    <div class="ivo-card__setup">
      <div class="ivo-card__setup-box">
        <div class="ivo-card__step">
          <div class="ivo-card__step-number">1</div>
          <div>
            <strong>{$text_step_account}</strong>
            <span>{$text_step_account_desc}</span>
          </div>
          {if $configured}
            <div class="ivo-card__tag ivo-card__tag--success">{$text_badge_success}</div>
          {else}
            <div class="ivo-card__tag ivo-card__tag--active">{$text_badge_required}</div>
          {/if}
        </div>

        <div class="ivo-card__step">
          <div class="ivo-card__step-number">2</div>
          <div>
            <strong>{$text_step_sync}</strong>
            <span>{$text_step_sync_desc}</span>
          </div>
          {if $configured}
            <div class="ivo-card__tag ivo-card__tag--success">{$text_badge_active}</div>
          {else}
            <div class="ivo-card__tag">{$text_badge_next}</div>
          {/if}
        </div>

        <div class="ivo-card__step">
          <div class="ivo-card__step-number">3</div>
          <div>
            <strong>{$text_step_order}</strong>
            <span>{$text_step_order_desc}</span>
          </div>
          {if $configured && $update_stock}
            <div class="ivo-card__tag ivo-card__tag--success">{$text_badge_active}</div>
          {else}
            <div class="ivo-card__tag">{if $configured}{$text_badge_inactive}{else}{$text_badge_ready}{/if}</div>
          {/if}
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Setup buttons - fetch URL via AJAX, then redirect
  var setupButtons = document.querySelectorAll('.btn-setup');
  setupButtons.forEach(function(btn) {
      btn.addEventListener('click', function() {
          var button = this;
          var originalHtml = button.innerHTML;
          button.disabled = true;
          button.innerHTML = '<i class="icon-spinner icon-spin"></i> Loading...';
          
          var ajaxUrl = button.getAttribute('data-url');
          
          $.ajax({
              url: ajaxUrl,
              type: 'GET',
              dataType: 'json',
              success: function(json) {
                  if (json.success && json.url) {
                      window.location.href = json.url;
                  } else {
                      button.disabled = false;
                      button.innerHTML = originalHtml;
                      alert('Error: ' + (json.error || 'Unknown error'));
                  }
              },
              error: function(xhr, status, error) {
                  button.disabled = false;
                  button.innerHTML = originalHtml;
                  alert('Request failed: ' + error);
              }
          });
      });
  });
  
  const btnSync = document.getElementById('btn-force-sync');
  const syncStatus = document.getElementById('sync-status');

  if (btnSync) {
    btnSync.addEventListener('click', function() {
      btnSync.disabled = true;
      btnSync.innerHTML = '<i class="icon-spinner icon-spin"></i> {$text_syncing}';
      syncStatus.innerHTML = '';

      var syncUrl = this.getAttribute('data-url');

      $.ajax({
        url: syncUrl,
        type: 'GET',
        dataType: 'json',
        success: function(json) {
          btnSync.disabled = false;
          btnSync.innerHTML = '<i class="icon-refresh"></i> {$button_force_sync}';

          if (json.success) {
            syncStatus.innerHTML = '<span class="success"><i class="icon-check"></i> ' + json.success + '</span>';
          } else if (json.error) {
            syncStatus.innerHTML = '<span class="error"><i class="icon-times"></i> ' + json.error + '</span>';
          }
        },
        error: function(xhr, status, error) {
          btnSync.disabled = false;
          btnSync.innerHTML = '<i class="icon-refresh"></i> {$button_force_sync}';
          syncStatus.innerHTML = '<span class="error"><i class="icon-times"></i> Request failed: ' + error + '</span>';
        }
      });
    });
  }
});
</script>
