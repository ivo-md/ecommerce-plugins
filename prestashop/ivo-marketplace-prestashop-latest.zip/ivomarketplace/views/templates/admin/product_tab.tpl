{**
 * IVO Marketplace Product Tab Template
 * EXACT MATCH with OpenCart eventProductTab() JavaScript and HTML
 * 
 * Shows IVO sync status in product edit page
 *}

<div class="panel" id="ivo-marketplace-product-tab">
    <div class="panel-heading">
        <i class="icon-shopping-cart"></i> {l s='IVO Marketplace' mod='ivomarketplace'}
    </div>
    <div class="panel-body">
        <div id="ivo-status-container" style="padding: 15px; background: #f8f8f8; border: 1px solid #d1d1d1; border-radius: 5px;">
            <div id="ivo-loading" class="text-center" style="padding: 20px 0;">
                <i class="icon-spinner icon-spin" style="font-size: 24px;"></i>
                <p style="margin-top: 10px;">{l s='Loading...' mod='ivomarketplace'}</p>
            </div>
            <div id="ivo-status-content" style="display:none;">
                <h3 id="ivo-status-header" style="margin-top:0"></h3>
                <p id="ivo-status-description"></p>
                <div id="ivo-extra-info" style="display:none;">
                    <ul id="ivo-info-list" style="padding-left: 20px; margin-bottom: 0;"></ul>
                </div>
                <div id="ivo-view-btn-container" style="display:none; margin-top:15px;">
                    <a id="ivo-product-url" href="#" target="_blank" style="
                        background-color: #eb5202;
                        color: white;
                        padding: 10px 20px;
                        text-decoration: none;
                        border-radius: 3px;
                        font-weight: bold;
                        display: inline-block;
                    ">{l s='View Product' mod='ivomarketplace'}</a>
                </div>
            </div>
            <div id="ivo-error" class="alert alert-danger" style="display:none;"></div>
            <div style="margin-top: 15px; padding-top: 10px; border-top: 1px dashed #ccc;">
                <button type="button" id="btn-ivo-sync" class="btn btn-default">
                    <i class="icon-refresh"></i> {l s='Force Sync with IVO' mod='ivomarketplace'}
                </button>
                <span id="ivo-sync-status" style="margin-left: 10px; font-weight: bold;"></span>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var statusUrl = '{$status_url|escape:'javascript' nofilter}';
    var syncUrl = '{$sync_url|escape:'javascript' nofilter}';
    
    // Message descriptions for error statuses - EXACT MATCH with OpenCart
    var messageDescriptions = {
        'not_imported': '{l s='Product has not been synced to IVO yet.' mod='ivomarketplace' js=1}',
        'queued': '{l s='Product is queued for processing.' mod='ivomarketplace' js=1}',
        'processing': '{l s='Product is currently being processed.' mod='ivomarketplace' js=1}',
        'pending_approval': '{l s='Product created but still pending approval.' mod='ivomarketplace' js=1}',
        'import_error': '{l s='An error occurred during import.' mod='ivomarketplace' js=1}',
        'skipped_no_match': '{l s='The product details are too generic to accurately identify the specific item being sold.' mod='ivomarketplace' js=1}',
        'too_generic': '{l s='The product details are too generic to generate a valid listing.' mod='ivomarketplace' js=1}',
        'unauthorized_category': '{l s='Merchant not authorized for product category.' mod='ivomarketplace' js=1}',
        'offer_deleted': '{l s='The offer was deleted from the marketplace.' mod='ivomarketplace' js=1}',
        'offer_not_found': '{l s='Product not found on marketplace.' mod='ivomarketplace' js=1}'
    };
    
    // Language strings - EXACT MATCH with OpenCart
    var textStatus = '{l s='IVO Status' mod='ivomarketplace' js=1}';
    var textStatusActive = '{l s='Active' mod='ivomarketplace' js=1}';
    var textStatusPending = '{l s='Pending' mod='ivomarketplace' js=1}';
    var textStatusError = '{l s='Error' mod='ivomarketplace' js=1}';
    var textStatusNotSynced = '{l s='Not Synced' mod='ivomarketplace' js=1}';
    var textProductVisible = '{l s='The product is visible and purchasable.' mod='ivomarketplace' js=1}';
    var textViewOnIvo = '{l s='View Product' mod='ivomarketplace' js=1}';
    var textConnectionError = '{l s='Connection error.' mod='ivomarketplace' js=1}';
    var textUnknownStatus = '{l s='Unknown status' mod='ivomarketplace' js=1}';
    var textProductSynced = '{l s='Product synced successfully!' mod='ivomarketplace' js=1}';
    var buttonForceSync = '{l s='Force Sync with IVO' mod='ivomarketplace' js=1}';
    var textSyncing = '{l s='Syncing...' mod='ivomarketplace' js=1}';
    
    // Load status immediately
    loadIvoStatus();
    
    function loadIvoStatus() {
        // Use jQuery if available (PrestaShop includes it) - EXACT MATCH with OpenCart
        if (typeof jQuery !== 'undefined') {
            jQuery.ajax({
                url: statusUrl,
                type: 'GET',
                dataType: 'json',
                success: function(json) {
                    document.getElementById('ivo-loading').style.display = 'none';
                    
                    if (json.error) {
                        document.getElementById('ivo-error').innerHTML = json.error;
                        document.getElementById('ivo-error').style.display = 'block';
                        document.getElementById('ivo-status-content').style.display = 'block';
                        return;
                    }
                    
                    document.getElementById('ivo-status-content').style.display = 'block';
                    
                    var header = document.getElementById('ivo-status-header');
                    var desc = document.getElementById('ivo-status-description');
                    var viewBtnContainer = document.getElementById('ivo-view-btn-container');
                    var productUrl = document.getElementById('ivo-product-url');
                    
                    if (json.status === 'success') {
                        // Success - offer found, show Active status
                        var color = '#28a745';
                        header.innerHTML = textStatus + ': <span style="font-weight:bold; color: ' + color + ';">' + textStatusActive + '</span>';
                        desc.innerHTML = textProductVisible;
                        
                        // Show View Product button with language preference
                        var targetUrl = null;
                        var btnText = textViewOnIvo;
                        var lang = '{$language_iso|default:'en'}';
                        
                        if (json.urls && json.urls[lang]) {
                            targetUrl = json.urls[lang];
                            btnText += ' (' + lang.toUpperCase() + ')';
                        } else if (json.urls && json.urls['en']) {
                            targetUrl = json.urls['en'];
                            btnText += ' (EN)';
                        } else if (json.url) {
                            targetUrl = json.url;
                        }
                        
                        if (targetUrl) {
                            productUrl.href = targetUrl;
                            productUrl.innerHTML = btnText;
                            viewBtnContainer.style.display = 'block';
                        }
                    } else {
                        // Error status - show appropriate message
                        var message = json.message || 'unknown';
                        var color = '#dc3545'; // Red for errors
                        var statusLabel = textStatusError;
                        
                        // Determine color and label based on message type - EXACT MATCH with OpenCart
                        if (message === 'queued' || message === 'processing' || message === 'pending_approval') {
                            color = '#ffc107'; // Yellow for pending
                            statusLabel = textStatusPending;
                        } else if (message === 'not_imported') {
                            color = '#6c757d'; // Gray for not synced
                            statusLabel = textStatusNotSynced;
                        }
                        
                        header.innerHTML = textStatus + ': <span style="font-weight:bold; color: ' + color + ';">' + statusLabel + '</span>';
                        
                        if (messageDescriptions[message]) {
                            desc.innerHTML = messageDescriptions[message];
                        } else {
                            desc.innerHTML = textUnknownStatus + ': ' + message;
                        }
                    }
                },
                error: function(xhr, status, error) {
                    document.getElementById('ivo-loading').style.display = 'none';
                    document.getElementById('debug-response').innerHTML = 'AJAX ERROR\\nStatus: ' + status + '\\nError: ' + error + '\\nResponse: ' + xhr.responseText;
                    document.getElementById('ivo-error').innerHTML = textConnectionError;
                    document.getElementById('ivo-error').style.display = 'block';
                }
            });
        }
    }
    
    // Force sync button - EXACT MATCH with OpenCart
    var btnSync = document.getElementById('btn-ivo-sync');
    if (btnSync) {
        btnSync.addEventListener('click', function() {
            btnSync.disabled = true;
            btnSync.innerHTML = '<i class="icon-spinner icon-spin"></i> ' + textSyncing;
            document.getElementById('ivo-sync-status').innerHTML = '';
            
            jQuery.ajax({
                url: syncUrl,
                type: 'GET',
                dataType: 'json',
                success: function(json) {
                    btnSync.disabled = false;
                    btnSync.innerHTML = '<i class="icon-refresh"></i> ' + buttonForceSync;
                    
                    if (json.success) {
                        document.getElementById('ivo-sync-status').innerHTML = '<span class="text-success"><i class="icon-check"></i> ' + json.success + '</span>';
                        // IVO processes sync asynchronously — wait before re-checking status
                        document.getElementById('ivo-sync-status').innerHTML += ' <span style="color:#666;">{l s='Refreshing status...' mod='ivomarketplace' js=1}</span>';
                        setTimeout(function() {
                            document.getElementById('ivo-loading').style.display = 'block';
                            document.getElementById('ivo-status-content').style.display = 'none';
                            document.getElementById('ivo-error').style.display = 'none';
                            loadIvoStatus();
                            document.getElementById('ivo-sync-status').innerHTML = '';
                        }, 5000);
                    } else if (json.error) {
                        document.getElementById('ivo-sync-status').innerHTML = '<span class="text-danger"><i class="icon-times"></i> ' + json.error + '</span>';
                    }
                },
                error: function() {
                    btnSync.disabled = false;
                    btnSync.innerHTML = '<i class="icon-refresh"></i> ' + buttonForceSync;
                    document.getElementById('ivo-sync-status').innerHTML = '<span class="text-danger"><i class="icon-times"></i> ' + textConnectionError + '</span>';
                }
            });
        });
    }
});
</script>
