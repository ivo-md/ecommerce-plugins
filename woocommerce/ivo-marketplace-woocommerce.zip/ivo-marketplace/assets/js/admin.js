/**
 * IVO Marketplace Admin JavaScript
 * EXACT MATCH with OpenCart eventProductTab JavaScript
 */

(function($) {
    'use strict';

    // Force Sync button on settings page
    $(document).ready(function() {
        var btnSync = $('#btn-force-sync');
        var syncStatus = $('#sync-status');

        if (btnSync.length) {
            btnSync.on('click', function() {
                btnSync.prop('disabled', true);
                btnSync.html('<span class="dashicons dashicons-update-alt spinning"></span> ' + ivo_ajax.strings.syncing);
                syncStatus.html('').removeClass('success error');

                $.ajax({
                    url: ivo_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'ivo_force_sync',
                        nonce: ivo_ajax.nonce
                    },
                    success: function(response) {
                        btnSync.prop('disabled', false);
                        btnSync.html('<span class="dashicons dashicons-update"></span> ' + ivo_ajax.strings.force_sync);

                        if (response.success) {
                            syncStatus.html('<span class="dashicons dashicons-yes-alt"></span> ' + response.data.message).addClass('success');
                        } else {
                            syncStatus.html('<span class="dashicons dashicons-dismiss"></span> ' + response.data.message).addClass('error');
                        }
                    },
                    error: function() {
                        btnSync.prop('disabled', false);
                        btnSync.html('<span class="dashicons dashicons-update"></span> ' + ivo_ajax.strings.force_sync);
                        syncStatus.html('<span class="dashicons dashicons-dismiss"></span> ' + ivo_ajax.strings.connection_error).addClass('error');
                    }
                });
            });
        }
    });

    /**
     * Load IVO Status for a product
     * EXACT MATCH with OpenCart loadIvoStatus()
     */
    window.loadIvoStatus = function(productId) {
        var loading = $('#ivo-loading');
        var content = $('#ivo-status-content');
        var error = $('#ivo-error');
        var header = $('#ivo-status-header');
        var desc = $('#ivo-status-description');
        var viewBtnContainer = $('#ivo-view-btn-container');
        var productUrl = $('#ivo-product-url');

        // Message descriptions for error statuses - EXACT MATCH with OpenCart
        var messageDescriptions = {
            'not_imported': ivo_ajax.strings.not_imported,
            'queued': ivo_ajax.strings.queued,
            'processing': ivo_ajax.strings.processing,
            'pending_approval': ivo_ajax.strings.pending_approval,
            'import_error': ivo_ajax.strings.import_error,
            'skipped_no_match': ivo_ajax.strings.skipped_no_match,
            'too_generic': ivo_ajax.strings.too_generic,
            'unauthorized_category': ivo_ajax.strings.unauthorized_category,
            'offer_deleted': ivo_ajax.strings.offer_deleted,
            'offer_not_found': ivo_ajax.strings.offer_not_found
        };

        $.ajax({
            url: ivo_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'ivo_get_product_status',
                nonce: ivo_ajax.nonce,
                product_id: productId
            },
            success: function(response) {
                loading.hide();

                if (!response.success && response.data && response.data.message) {
                    error.html(response.data.message).show();
                    content.show();
                    return;
                }

                content.show();
                var data = response.data;

                if (data.status === 'success') {
                    // Success - offer found, show Active status
                    var color = '#28a745';
                    header.html(ivo_ajax.strings.status + ': <span style="font-weight:bold; color: ' + color + ';">' + ivo_ajax.strings.active + '</span>');
                    desc.html(ivo_ajax.strings.product_visible);

                    // Show View Product button with language preference
                    var targetUrl = null;
                    var btnText = ivo_ajax.strings.view_product;

                    // Get browser language
                    var lang = (navigator.language || navigator.userLanguage || 'en').substring(0, 2);

                    if (data.urls && data.urls[lang]) {
                        targetUrl = data.urls[lang];
                        btnText += ' (' + lang.toUpperCase() + ')';
                    } else if (data.urls && data.urls['en']) {
                        targetUrl = data.urls['en'];
                        btnText += ' (EN)';
                    } else if (data.url) {
                        targetUrl = data.url;
                    }

                    if (targetUrl) {
                        productUrl.attr('href', targetUrl).text(btnText);
                        viewBtnContainer.show();
                    }
                } else {
                    // Error status - show appropriate message
                    var message = data.message || 'unknown';
                    var statusColor = '#dc3545'; // Red for errors
                    var statusLabel = ivo_ajax.strings.error;

                    // Determine color and label based on message type - EXACT MATCH with OpenCart
                    if (message === 'queued' || message === 'processing' || message === 'pending_approval') {
                        statusColor = '#ffc107'; // Yellow for pending
                        statusLabel = ivo_ajax.strings.pending;
                    } else if (message === 'not_imported') {
                        statusColor = '#6c757d'; // Gray for not synced
                        statusLabel = ivo_ajax.strings.not_synced;
                    }

                    header.html(ivo_ajax.strings.status + ': <span style="font-weight:bold; color: ' + statusColor + ';">' + statusLabel + '</span>');

                    if (messageDescriptions[message]) {
                        desc.html(messageDescriptions[message]);
                    } else {
                        desc.html(ivo_ajax.strings.unknown_status + ': ' + message);
                    }
                }
            },
            error: function() {
                loading.hide();
                error.html(ivo_ajax.strings.connection_error).show();
            }
        });

        // Sync Product button
        var btnSync = $('#btn-ivo-sync');
        var syncStatus = $('#ivo-sync-status');

        if (btnSync.length && !btnSync.data('bound')) {
            btnSync.data('bound', true);
            btnSync.on('click', function() {
                var pid = $(this).data('product-id');
                btnSync.prop('disabled', true);
                btnSync.html('<span class="dashicons dashicons-update-alt spinning"></span> ' + ivo_ajax.strings.syncing);
                syncStatus.html('');

                $.ajax({
                    url: ivo_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'ivo_sync_product',
                        nonce: ivo_ajax.nonce,
                        product_id: pid
                    },
                    success: function(response) {
                        btnSync.prop('disabled', false);
                        btnSync.html('<span class="dashicons dashicons-update"></span> ' + ivo_ajax.strings.force_sync);

                        if (response.success) {
                            syncStatus.html('<span style="color:#28a745;"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</span>');
                            // IVO processes sync asynchronously — wait before re-checking status
                            loading.show();
                            content.hide();
                            error.hide();
                            syncStatus.html('<span style="color:#28a745;"><span class="dashicons dashicons-yes-alt"></span> ' + response.data.message + '</span> <span style="color:#666;">' + ivo_ajax.strings.refreshing_status + '</span>');
                            setTimeout(function() {
                                loadIvoStatus(pid);
                                syncStatus.html('');
                            }, 5000);
                        } else {
                            syncStatus.html('<span style="color:#dc3545;"><span class="dashicons dashicons-dismiss"></span> ' + response.data.message + '</span>');
                        }
                    },
                    error: function() {
                        btnSync.prop('disabled', false);
                        btnSync.html('<span class="dashicons dashicons-update"></span> ' + ivo_ajax.strings.force_sync);
                        syncStatus.html('<span style="color:#dc3545;"><span class="dashicons dashicons-dismiss"></span> ' + ivo_ajax.strings.connection_error + '</span>');
                    }
                });
            });
        }
    };

    // Add spinning animation for dashicons
    $('<style>')
        .prop('type', 'text/css')
        .html('.dashicons.spinning { animation: spin 1s linear infinite; } @keyframes spin { 100% { transform: rotate(360deg); } }')
        .appendTo('head');

})(jQuery);
