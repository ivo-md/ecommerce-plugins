=== IVO Marketplace ===
Contributors: ivoteam
Tags: woocommerce, marketplace, ivo, product sync, e-commerce
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.16
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

IVO Marketplace integration for WooCommerce. Sync your products to IVO and reach more customers.

== Description ==

IVO Marketplace integration for WooCommerce. This plugin provides EXACT functionality match with the Magento and OpenCart extensions.

**Features:**

* Automatic product synchronization on save
* Real-time price and availability updates
* View product status on IVO directly from WooCommerce
* Force sync all products with one click
* Order completion triggers stock sync to IVO
* Secure OAuth-based API key configuration

**How it works:**

1. Install and activate the plugin
2. Click "Configure" to connect to IVO Marketplace
3. Select your Merchant Point
4. Your products will automatically sync to IVO

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/ivo-marketplace/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to IVO Marketplace in the admin menu
4. Click "Configure" to connect your store to IVO

== Frequently Asked Questions ==

= Do I need a WooCommerce store? =

Yes, this plugin requires WooCommerce to be installed and active.

= How do I get an IVO API key? =

Click the "Configure" button on the IVO Marketplace settings page. You will be redirected to IVO to complete the setup process.

= Are my products synced automatically? =

Yes, products are automatically synced when you save them. You can also use the "Force Sync with IVO" button to sync all products at once.

== Changelog ==

= 1.0.16 =
* Force Sync runs as a series of small requests with progress, so a shop's request timeout no longer cuts it off; a new price modifier re-sends the catalogue the same way
* Every variation is sent, each under its own SKU or its own ID (variations without a SKU used to share the parent's and collapse into one IVO offer); disabled, out-of-stock and backorder stock goes out as 0
* Stock changes and orders update the variations on IVO right away; unpublishing a product is no longer undone by the save that follows
* Pushes depend only on the API key and merchant point; saving the settings can no longer blank the merchant point
* Items without a name or price are skipped instead of failing their batch, calls carry at most 100 items, and rejected pushes are logged (WooCommerce > Status > Logs, source ivo-marketplace)
* IVO's stock webhook leaves products whose stock is not managed alone instead of switching stock management on

= 1.0.15 =
* Sends the regular price as the recommended retail price (PRP) while a discount is active

= 1.0.0 =
* Initial release
* Automatic product synchronization on save
* Force sync all products
* Product status display on edit page
* Order completion stock sync
* Secure OAuth configuration flow

== Upgrade Notice ==

= 1.0.0 =
Initial release of IVO Marketplace integration for WooCommerce.
