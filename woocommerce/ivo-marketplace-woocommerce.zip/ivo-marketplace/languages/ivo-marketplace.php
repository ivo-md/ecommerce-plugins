<?php
/**
 * IVO Marketplace Language Strings
 * 
 */

// Heading
$_['heading_title'] = 'IVO Marketplace';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified IVO Marketplace settings!';
$_['text_edit'] = 'Edit IVO Marketplace';
$_['text_home'] = 'Home';
$_['text_select'] = '--- Select ---';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_configured'] = 'Configured';
$_['text_not_configured'] = 'Not configured.';
$_['text_syncing'] = 'Syncing...';
$_['text_sync_success'] = 'Products synchronization started successfully.';
$_['text_success_configured'] = 'IVO Marketplace configured successfully!';
$_['text_please_configure'] = 'IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.';
$_['text_loading'] = 'Loading...';

// IVO Status messages
$_['text_status'] = 'IVO Status';
$_['text_status_active'] = 'Active';
$_['text_status_inactive'] = 'Inactive';
$_['text_status_draft'] = 'Draft';
$_['text_status_unknown'] = 'Unknown';
$_['text_status_error'] = 'Error';
$_['text_status_pending'] = 'Pending';
$_['text_status_not_synced'] = 'Not Synced';
$_['text_not_synced'] = 'Product not found on marketplace.';
$_['text_view_on_ivo'] = 'View Product';
$_['text_product_hidden'] = 'The product is hidden or disabled.';
$_['text_product_pending'] = 'The product is still being created or reviewed.';
$_['text_product_available'] = 'Product is available on IVO.';
$_['text_product_visible'] = 'The product is visible and purchasable.';
$_['text_connection_error'] = 'Connection error.';
$_['text_error_fetching'] = 'Error fetching status.';
$_['text_product_synced'] = 'Product synced successfully!';
$_['text_unknown_status'] = 'Unknown status';

// New simplified message codes
$_['text_not_imported'] = 'Product has not been synced to IVO yet.';
$_['text_queued'] = 'Product is queued for processing.';
$_['text_processing'] = 'Product is currently being processed.';
$_['text_pending_approval'] = 'Product created but still pending approval.';
$_['text_import_error'] = 'An error occurred during import.';
$_['text_offer_deleted'] = 'The offer was deleted from the marketplace.';

// Offer Status messages
$_['text_offer_status'] = 'Offer Status';
$_['text_note'] = 'Note';
$_['text_detail'] = 'Detail';
$_['text_reason'] = 'Reason';
$_['text_no_variants'] = 'No variants were found for this product.';
$_['text_too_generic'] = 'The product details are too generic to accurately identify the specific item being sold.';
$_['text_not_authorized'] = 'Merchant not authorized for product category.';
$_['text_offer_created'] = 'Offer was successfully created for the product/variant.';
$_['text_offer_error'] = 'An error occurred during offer creation.';
$_['text_offer_pending'] = 'Found existing product, offer creation is pending.';

// Entry
$_['entry_status'] = 'Status';
$_['entry_api_key'] = 'API Key';
$_['entry_merchant_point'] = 'Merchant Point';

// Tab
$_['tab_ivo_marketplace'] = 'IVO Marketplace';

// Button
$_['button_configure'] = 'Configure';
$_['button_reconfigure'] = 'Reconfigure';
$_['button_force_sync'] = 'Force Sync with IVO';
$_['button_save'] = 'Save';
$_['button_cancel'] = 'Cancel';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify IVO Marketplace!';
$_['error_not_configured'] = 'Unable to fetch Merchant Point ID. Please check API Key configuration.';
$_['error_no_api_key'] = 'No API key received from IVO.';
$_['error_api_key_decrypt'] = 'Failed to process API key from IVO.';
$_['error_payload'] = 'Could not prepare payload or Merchant Point ID missing';
$_['error_sync_failed'] = 'Sync failed. API Code: %s';

// Info
$_['text_info_title'] = 'About IVO Marketplace Integration';
$_['text_info_description'] = 'This plugin integrates your WooCommerce store with IVO Marketplace. Your products will be automatically synced to IVO, allowing customers to discover and purchase them through the IVO platform.';
$_['text_info_features'] = 'Features:';
$_['text_feature_1'] = 'Automatic product synchronization on save';
$_['text_feature_2'] = 'Real-time price and availability updates';
$_['text_feature_3'] = 'View product status on IVO directly from WooCommerce';
$_['text_feature_4'] = 'Force sync all products with one click';
