<?php
/**
 * Plugin Name: IVO Marketplace
 * Plugin URI:  https://ivo.md
 * Description: Sync your products with IVO Marketplace. Sell on Moldova's largest marketplace directly from your WooCommerce store.
 * Version:     1.0.16
 * Author:      IVO Team
 * Author URI:  https://ivo.md
 * License:     GPL-2.0+
 * Text Domain: ivo-marketplace
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define plugin constants
define( 'IVO_MARKETPLACE_VERSION', '1.0.16' );
define( 'IVO_MARKETPLACE_DIR', plugin_dir_path( __FILE__ ) );
define( 'IVO_MARKETPLACE_URL', plugin_dir_url( __FILE__ ) );
define( 'IVO_MARKETPLACE_BASENAME', plugin_basename( __FILE__ ) );

// IVO Endpoints
define( 'IVO_SETUP_URL', getenv('IVO_SETUP_URL') ?: 'https://www.ivo.md/merchant/plugin/setup' );
define( 'IVO_API_BASE_URL', getenv('IVO_API_URL') ?: 'https://a.ivo.md' );

/**
 * Main IVO Marketplace Class
 * 
 * EXACT functionality match with Magento/OpenCart
 */
class IVO_Marketplace {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Option keys - similar to Magento's CONFIG_PATH_*
     */
    const OPTION_API_KEY = 'ivo_marketplace_api_key';
    const OPTION_CONFIGURED = 'ivo_marketplace_configured';
    const OPTION_MERCHANT_POINT_ID = 'ivo_marketplace_merchant_point_id';
    const OPTION_SETUP_NONCE = 'ivo_marketplace_setup_nonce';
    const OPTION_PRICE_MODIFIER = 'ivo_marketplace_price_modifier';
    const OPTION_UPDATE_STOCK = 'ivo_marketplace_update_stock';
    // Set when the catalogue must be re-sent (a new price modifier); the
    // settings page starts the sliced Force Sync and a completed run clears it
    const OPTION_RESYNC_PENDING = 'ivo_marketplace_resync_pending';

    // Force Sync slices: products read, and payloads gathered, per request
    const SYNC_SLICE_PRODUCTS = 50;
    const SYNC_SLICE_PAYLOADS = 50;

    /**
     * Why the last batched sync failed, for the admin who started it
     */
    private $last_sync_error = '';

    /**
     * Availability IVO accepted in this request, by merchant internal id
     */
    private $pushed_availability = array();

    /**
     * Get single instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Initialize translations early so plugin metadata is localized on the Plugins page.
        add_action( 'plugins_loaded', array( $this, 'init' ), 0 );

        // Check WooCommerce dependency
        add_action( 'plugins_loaded', array( $this, 'check_dependencies' ) );
        
        // Admin hooks
        if ( is_admin() ) {
            add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
            add_action( 'admin_init', array( $this, 'register_settings' ) );
            add_action( 'admin_notices', array( $this, 'admin_notices' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
            
            // Product edit page metabox
            add_action( 'add_meta_boxes', array( $this, 'add_product_metabox' ) );
            
            // AJAX handlers
            add_action( 'wp_ajax_ivo_force_sync', array( $this, 'ajax_force_sync' ) );
            add_action( 'wp_ajax_ivo_get_product_status', array( $this, 'ajax_get_product_status' ) );
            add_action( 'wp_ajax_ivo_sync_product', array( $this, 'ajax_sync_product' ) );
            
            // Settings link on plugins page
            add_filter( 'plugin_action_links_' . IVO_MARKETPLACE_BASENAME, array( $this, 'add_settings_link' ) );
        }
        
        // Product save hook
        add_action( 'woocommerce_update_product', array( $this, 'on_product_save' ), 10, 2 );
        add_action( 'woocommerce_new_product', array( $this, 'on_product_save' ), 10, 2 );

        // A product removed from the store must go out of stock on IVO, or it
        // stays purchasable there forever with its last-pushed availability.
        add_action( 'wp_trash_post', array( $this, 'on_product_remove' ) );
        add_action( 'before_delete_post', array( $this, 'on_product_remove' ) );
        add_action( 'transition_post_status', array( $this, 'on_product_status_change' ), 10, 3 );

        // Stock changed by an order, an edit or an import
        add_action( 'woocommerce_product_set_stock', array( $this, 'on_stock_change' ) );
        add_action( 'woocommerce_variation_set_stock', array( $this, 'on_stock_change' ) );

        // A new price modifier means every price must be re-sent. The first
        // save adds the option, which fires add_option_ and not update_option_
        add_action( 'update_option_' . self::OPTION_PRICE_MODIFIER, array( $this, 'on_price_modifier_update' ), 10, 3 );
        add_action( 'add_option_' . self::OPTION_PRICE_MODIFIER, array( $this, 'on_price_modifier_add' ), 10, 2 );

        // Order complete hook
        add_action( 'woocommerce_order_status_completed', array( $this, 'on_order_complete' ) );
        add_action( 'woocommerce_payment_complete', array( $this, 'on_order_complete' ) );
        
        // Callback endpoint
        add_action( 'init', array( $this, 'register_callback_endpoint' ) );
        add_action( 'template_redirect', array( $this, 'handle_callback' ) );

        // Inbound stock-update webhook (called by IVO when a sale happens on IVO)
        add_action( 'rest_api_init', array( $this, 'register_webhook_routes' ) );
    }
    
    /**
     * Check if WooCommerce is active
     */
    public function check_dependencies() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', function() {
                echo '<div class="error"><p><strong>IVO Marketplace</strong> requires WooCommerce to be installed and active.</p></div>';
            } );
            return false;
        }
        return true;
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        load_plugin_textdomain( 'ivo-marketplace', false, dirname( IVO_MARKETPLACE_BASENAME ) . '/languages' );
    }
    
    /**
     * Register callback endpoint
     */
    public function register_callback_endpoint() {
        add_rewrite_rule( '^ivo-callback/?$', 'index.php?ivo_callback=1', 'top' );
        add_filter( 'query_vars', function( $vars ) {
            $vars[] = 'ivo_callback';
            $vars[] = 'key';
            $vars[] = 'nonce';
            return $vars;
        } );
    }
    
    /**
     * Handle callback from IVO setup
     * 
     */
    public function handle_callback() {
        if ( ! get_query_var( 'ivo_callback' ) ) {
            return;
        }
        
        $api_key = isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';
        $nonce = isset( $_GET['nonce'] ) ? sanitize_text_field( $_GET['nonce'] ) : '';
        
        $success = false;
        $error = '';
        $selected_point_id = '';
        
        // Security: Verify the nonce
        $stored_data = get_option( self::OPTION_SETUP_NONCE, '' );
        $stored_nonce = '';
        $stored_time = 0;
        $stored_locale = '';
        
        if ( $stored_data ) {
            $parts = explode( '|', $stored_data );
            $stored_nonce = $parts[0] ?? '';
            $stored_time = (int) ( $parts[1] ?? 0 );
            $stored_locale = $parts[2] ?? '';
        }
        $text = $this->get_callback_text( $stored_locale );
        
        // Delete the nonce immediately (one-time use)
        delete_option( self::OPTION_SETUP_NONCE );
        
        // Validate security
        if ( empty( $nonce ) || empty( $stored_nonce ) ) {
            $error = $text['error_missing_token'];
        } elseif ( ! hash_equals( $stored_nonce, $nonce ) ) {
            $error = $text['error_token_mismatch'];
        } elseif ( time() - $stored_time > 600 ) { // 10 minutes expiry
            $error = $text['error_expired'];
        } elseif ( empty( $api_key ) ) {
            $error = $text['error_api_key'];
        } else {
            // Decode the API key decryptIvoKey()
            $decoded_key = $this->decrypt_ivo_key( $api_key );
            
            if ( $decoded_key ) {
                // Save API key
                update_option( self::OPTION_API_KEY, $decoded_key );
                update_option( self::OPTION_CONFIGURED, 1 );
                
                // Keep the point already chosen: deleting it whenever the fetch
                // failed or found several points silently stopped every push.
                // Choose one only when none is stored and the choice is unambiguous.
                $selected_point_id = (string) get_option( self::OPTION_MERCHANT_POINT_ID, '' );
                if ( $selected_point_id === '' ) {
                    $points = $this->fetch_merchant_points( $decoded_key );
                    if ( count( $points ) === 1 ) {
                        $selected_point_id = $points[0]['id'] ?? $points[0]['_id'] ?? '';
                        if ( $selected_point_id ) {
                            update_option( self::OPTION_MERCHANT_POINT_ID, $selected_point_id );
                        }
                    }
                }
                
                $success = true;
            } else {
                $error = $text['error_api_key_decrypt'];
            }
        }
        
        // Build admin URL
        $admin_link = admin_url( 'admin.php?page=ivo-marketplace' );
        $sync_data = array(
            'url' => ( $success && ! empty( $selected_point_id ) ) ? admin_url( 'admin-ajax.php' ) : '',
            'nonce' => ( $success && ! empty( $selected_point_id ) ) ? wp_create_nonce( 'ivo_marketplace_nonce' ) : '',
        );
        if ( $success && empty( $selected_point_id ) ) {
            $sync_data['status'] = $text['select_point'];
        }
        
        // Output standalone HTML page
        $this->output_callback_page( $success, $error, $admin_link, $sync_data, $text );
        exit;
    }
    
    /**
     * Decrypt IVO API key
     * 
     */
    private function decrypt_ivo_key( $encrypted_key ) {
        $encrypted_key = trim( $encrypted_key );
        
        // User Requirement: "The callback key is simply Base64 encoded"
        $decoded = base64_decode( $encrypted_key, true );
        
        // Validation: If valid UTF-8/ASCII string, use it.
        if ( $decoded !== false && ctype_print( $decoded ) ) {
            return $decoded;
        }
        
        // Fallback: return raw input
        return $encrypted_key;
    }
    
    /**
     * Output callback page
     * 
     */
    private function output_callback_page( $success, $error, $admin_link, $sync_data, $text ) {
        $title = $success ? $text['success_title'] : $text['failed_title'];
        $message = $success 
            ? $text['success_message']
            : $error;
        $icon_color = $success ? '#28a745' : '#dc3545';
        $icon = $success 
            ? '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $icon_color . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>'
            : '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $icon_color . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';
        $sync_url = ! empty( $sync_data['url'] ) ? $sync_data['url'] : '';
        $sync_nonce = ! empty( $sync_data['nonce'] ) ? $sync_data['nonce'] : '';
        $sync_status = ! empty( $sync_data['status'] ) ? $sync_data['status'] : ( $success ? $text['syncing'] : '' );
        
        ?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( $text['lang'] ); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVO Marketplace - <?php echo esc_html( $title ); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #123cd1 0%, #ff3385 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px;
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .icon { margin-bottom: 24px; }
        .sync-status {
            color: #6c757d;
            font-size: 14px;
            line-height: 1.5;
            min-height: 22px;
            margin: -16px 0 28px;
        }
        .sync-status.success { color: #16813a; }
        .sync-status.error { color: #b42318; }
        h1 {
            color: #1a1a2e;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 32px;
        }
        .btn {
            display: inline-block;
            background: #123cd1;
            color: white;
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(18, 60, 209, 0.4);
        }
        .logo {
            margin-bottom: 32px;
            font-size: 28px;
            font-weight: 700;
            color: #123cd1;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">IVO Marketplace</div>
        <div class="icon"><?php echo $icon; ?></div>
        <h1><?php echo esc_html( $title ); ?></h1>
        <p><?php echo esc_html( $message ); ?></p>
        <div id="sync-status" class="sync-status"><?php echo esc_html( $sync_status ); ?></div>
        <a href="<?php echo esc_url( $admin_link ); ?>" class="btn"><?php echo esc_html( $text['admin_button'] ); ?></a>
    </div>
    <script>
        (function () {
            var syncUrl = <?php echo wp_json_encode( $sync_url ); ?>;
            var nonce = <?php echo wp_json_encode( $sync_nonce ); ?>;
            var status = document.getElementById('sync-status');
            if (!syncUrl || !nonce || !status) {
                if (status) status.textContent = '';
                return;
            }

            var syncProgress = <?php echo wp_json_encode( $text['sync_progress'] ); ?>;
            var syncFailed = <?php echo wp_json_encode( $text['sync_failed'] ); ?>;
            var after = 0;
            var runId = '';
            var retries = 0;

            status.textContent = <?php echo wp_json_encode( $text['syncing'] ); ?>;

            function finish(ok, message) {
                status.className = 'sync-status ' + (ok ? 'success' : 'error');
                status.textContent = message;
            }

            // The same walk as Force Sync on the settings page: one slice per
            // request, so no request nears the shop's timeout
            function next() {
                var body = new URLSearchParams();
                body.append('action', 'ivo_force_sync');
                body.append('nonce', nonce);
                body.append('after', after);
                body.append('run_id', runId);

                fetch(syncUrl, {
                    method: 'POST',
                    credentials: 'include',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                })
                    .then(function (response) {
                        if (!response.ok) {
                            throw new Error('HTTP ' + response.status);
                        }
                        return response.json();
                    })
                    .then(function (data) {
                        retries = 0;
                        if (!data || !data.success || !data.data) {
                            finish(false, data && data.data && data.data.message ? data.data.message : syncFailed);
                        } else if (data.data.done) {
                            finish(true, <?php echo wp_json_encode( $text['sync_success'] ); ?>);
                        } else {
                            after = data.data.after;
                            runId = data.data.run_id;
                            status.textContent = syncProgress.replace('%s', data.data.position).replace('%s', data.data.total);
                            next();
                        }
                    })
                    .catch(function (error) {
                        // Sending a slice again is safe: the same products, the same run
                        if (retries < 2) {
                            retries++;
                            setTimeout(next, 2000 * retries);
                            return;
                        }
                        finish(false, error && error.message ? syncFailed + ' ' + error.message : syncFailed);
                    });
            }

            next();
        })();
    </script>
</body>
</html>
        <?php
    }

    /**
     * Callback page translations. This page is rendered outside wp-admin, so keep
     * the setup return screen tied to the locale captured when setup started.
     */
    private function get_callback_text( $locale = '' ) {
        $locale = strtolower( $locale ?: get_locale() );
        if ( strpos( $locale, 'ro' ) === 0 ) {
            return array(
                'lang' => 'ro',
                'success_title' => 'Configurare reusita',
                'failed_title' => 'Configurare esuata',
                'success_message' => 'Cheia API IVO Marketplace a fost configurata cu succes.',
                'admin_button' => 'Mergi la setari',
                'syncing' => 'Sincronizarea produselor a pornit...',
                'sync_success' => 'Sincronizarea produselor a fost pornita cu succes.',
                'sync_failed' => 'Sincronizarea nu a putut fi pornita automat.',
                'sync_progress' => 'Sincronizate %s din %s produse...',
                'select_point' => 'Conexiunea este configurata. Selectati punctul de vanzare in setari pentru a porni sincronizarea.',
                'error_missing_token' => 'Cerere invalida: lipseste tokenul de securitate.',
                'error_token_mismatch' => 'Cerere invalida: tokenul de securitate nu corespunde.',
                'error_expired' => 'Cererea a expirat. Porniti din nou procesul de configurare.',
                'error_api_key' => 'Nu a fost primita cheia API de la IVO.',
                'error_api_key_decrypt' => 'Cheia API primita de la IVO nu a putut fi procesata.',
            );
        }
        if ( strpos( $locale, 'ru' ) === 0 ) {
            return array(
                'lang' => 'ru',
                'success_title' => 'Настройка завершена',
                'failed_title' => 'Ошибка настройки',
                'success_message' => 'API-ключ IVO Marketplace успешно настроен.',
                'admin_button' => 'Перейти к настройкам',
                'syncing' => 'Синхронизация товаров запущена...',
                'sync_success' => 'Синхронизация товаров успешно запущена.',
                'sync_failed' => 'Не удалось запустить синхронизацию автоматически.',
                'sync_progress' => 'Синхронизировано %s из %s товаров...',
                'select_point' => 'Подключение настроено. Выберите торговую точку в настройках, чтобы запустить синхронизацию.',
                'error_missing_token' => 'Некорректный запрос: отсутствует токен безопасности.',
                'error_token_mismatch' => 'Некорректный запрос: токен безопасности не совпадает.',
                'error_expired' => 'Срок действия запроса истек. Запустите настройку заново.',
                'error_api_key' => 'API-ключ от IVO не получен.',
                'error_api_key_decrypt' => 'Не удалось обработать API-ключ от IVO.',
            );
        }
        return array(
            'lang' => 'en',
            'success_title' => 'Configuration Successful',
            'failed_title' => 'Configuration Failed',
            'success_message' => 'Your IVO Marketplace API key has been successfully configured.',
            'admin_button' => 'Go to Settings',
            'syncing' => 'Product synchronization is starting...',
            'sync_success' => 'Product synchronization started successfully.',
            'sync_failed' => 'Synchronization could not be started automatically.',
            'sync_progress' => 'Synced %s of %s products...',
            'select_point' => 'Connection is configured. Select the merchant point in settings to start synchronization.',
            'error_missing_token' => 'Invalid request: missing security token.',
            'error_token_mismatch' => 'Invalid request: security token mismatch.',
            'error_expired' => 'Request expired. Please start the setup process again.',
            'error_api_key' => 'No API key received from IVO.',
            'error_api_key_decrypt' => 'Failed to process API key from IVO.',
        );
    }
    
    /**
     * Add admin menu under Marketing
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce-marketing',
            __( 'IVO Marketplace', 'ivo-marketplace' ),
            __( 'IVO Marketplace', 'ivo-marketplace' ),
            'manage_woocommerce',
            'ivo-marketplace',
            array( $this, 'render_settings_page' ),
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting( 'ivo_marketplace_settings', self::OPTION_MERCHANT_POINT_ID, array(
            'type' => 'string',
            'sanitize_callback' => array( $this, 'sanitize_merchant_point_id' ),
        ) );
        register_setting( 'ivo_marketplace_settings', self::OPTION_PRICE_MODIFIER, array(
            'type' => 'number',
            'sanitize_callback' => array( $this, 'sanitize_price_modifier' ),
            'default' => 0,
        ) );
        register_setting( 'ivo_marketplace_settings', self::OPTION_UPDATE_STOCK, array(
            'type' => 'string',
            'default' => '1',
        ) );
    }

    /**
     * Sanitize price modifier option
     */
    public function sanitize_price_modifier( $value ) {
        if ( $value === '' || $value === null ) {
            return 0;
        }
        return (float) $value;
    }

    /**
     * Keep the stored merchant point when the form posts none. The select is
     * built from a live API call; when that fails it holds only the empty
     * option, and saving blanked the point, which stopped every push.
     */
    public function sanitize_merchant_point_id( $value ) {
        $value = is_string( $value ) ? trim( sanitize_text_field( $value ) ) : '';
        if ( $value === '' ) {
            return (string) get_option( self::OPTION_MERCHANT_POINT_ID, '' );
        }
        return $value;
    }

    /**
     * Admin notices CheckConfig Observer
     */
    public function admin_notices() {
        // Only show on non-IVO pages
        $screen = get_current_screen();
        if ( $screen && $screen->id === 'toplevel_page_ivo-marketplace' ) {
            return;
        }
        
        // Check if configured
        if ( ! $this->is_configured() ) {
            $configure_url = admin_url( 'admin.php?page=ivo-marketplace' );
            ?>
            <div class="notice notice-warning">
                <p>
                    <strong><?php esc_html_e( 'IVO Marketplace', 'ivo-marketplace' ); ?></strong>: 
                    <?php esc_html_e( 'IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.', 'ivo-marketplace' ); ?>
                    <a href="<?php echo esc_url( $configure_url ); ?>"><?php esc_html_e( 'Configure', 'ivo-marketplace' ); ?></a>
                </p>
            </div>
            <?php
        }
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_scripts( $hook ) {
        if ( $hook === 'marketing_page_ivo-marketplace' || $hook === 'toplevel_page_ivo-marketplace' || $hook === 'post.php' || $hook === 'post-new.php' ) {
            wp_enqueue_style( 'ivo-marketplace-admin', IVO_MARKETPLACE_URL . 'assets/css/admin.css', array(), IVO_MARKETPLACE_VERSION );
            wp_enqueue_script( 'ivo-marketplace-admin', IVO_MARKETPLACE_URL . 'assets/js/admin.js', array( 'jquery' ), IVO_MARKETPLACE_VERSION, true );
            $is_settings_page = $hook === 'marketing_page_ivo-marketplace' || $hook === 'toplevel_page_ivo-marketplace';
            wp_localize_script( 'ivo-marketplace-admin', 'ivo_ajax', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'ivo_marketplace_nonce' ),
                // A re-send is pending (new price modifier): the page starts Force Sync itself
                'auto_sync' => ( $is_settings_page && get_option( self::OPTION_RESYNC_PENDING ) ) ? '1' : '',
                'strings' => array(
                    'syncing' => __( 'Syncing...', 'ivo-marketplace' ),
                    'sync_progress' => $this->translate( 'Synced %s of %s products...' ),
                    'force_sync' => __( 'Force Sync with IVO', 'ivo-marketplace' ),
                    'loading' => __( 'Loading...', 'ivo-marketplace' ),
                    'connection_error' => __( 'Connection error.', 'ivo-marketplace' ),
                    'status' => __( 'IVO Status', 'ivo-marketplace' ),
                    'active' => __( 'Active', 'ivo-marketplace' ),
                    'inactive' => __( 'Inactive', 'ivo-marketplace' ),
                    'pending' => __( 'Pending', 'ivo-marketplace' ),
                    'not_synced' => __( 'Not Synced', 'ivo-marketplace' ),
                    'error' => __( 'Error', 'ivo-marketplace' ),
                    'product_visible' => __( 'The product is visible and purchasable.', 'ivo-marketplace' ),
                    'view_product' => __( 'View Product', 'ivo-marketplace' ),
                    // Message descriptions/Magento
                    'not_imported' => __( 'Product has not been synced to IVO yet.', 'ivo-marketplace' ),
                    'queued' => __( 'Product is queued for processing.', 'ivo-marketplace' ),
                    'processing' => __( 'Product is currently being processed.', 'ivo-marketplace' ),
                    'pending_approval' => __( 'Product created but still pending approval.', 'ivo-marketplace' ),
                    'import_error' => __( 'An error occurred during import.', 'ivo-marketplace' ),
                    'skipped_no_match' => __( 'The product details are too generic to accurately identify the specific item being sold.', 'ivo-marketplace' ),
                    'unauthorized_category' => __( 'Merchant not authorized for product category.', 'ivo-marketplace' ),
                    'offer_deleted' => __( 'The offer was deleted from the marketplace.', 'ivo-marketplace' ),
                    'offer_not_found' => __( 'Product not found on marketplace.', 'ivo-marketplace' ),
                    'unknown_status' => __( 'Unknown status', 'ivo-marketplace' ),
                    'refreshing_status' => __( 'Refreshing status...', 'ivo-marketplace' ),
                    'too_generic' => __( 'The product details are too generic to accurately identify the specific item being sold.', 'ivo-marketplace' ),
                ),
            ) );
        }
    }
    
    /**
     * Add settings link to plugins page
     */
    public function add_settings_link( $links ) {
        $settings_link = '<a href="' . admin_url( 'admin.php?page=ivo-marketplace' ) . '">' . __( 'Settings', 'ivo-marketplace' ) . '</a>';
        array_unshift( $links, $settings_link );
        return $links;
    }
    
    /**
     * Render settings page
     * 
     */
    public function render_settings_page() {
        $configured = $this->is_configured();
        $api_key = $this->get_api_key();
        $api_key_masked = $api_key ? substr( $api_key, 0, 8 ) . '••••••••••••••••' : '';
        $merchant_point_id = get_option( self::OPTION_MERCHANT_POINT_ID, '' );
        $update_stock = get_option( self::OPTION_UPDATE_STOCK, '1' );
        $merchant_points = $configured ? $this->fetch_merchant_points() : array();
        $configure_url = $this->get_setup_url();
        
        // Handle success/error messages
        $success = '';
        $error = '';
        
        if ( isset( $_GET['settings-updated'] ) ) {
            $success = __( 'Success: You have modified IVO Marketplace settings!', 'ivo-marketplace' );
        }
        
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'IVO Marketplace', 'ivo-marketplace' ); ?></h1>
            
            <?php if ( $success ) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html( $success ); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ( $error ) : ?>
            <div class="notice notice-error is-dismissible">
                <p><?php echo esc_html( $error ); ?></p>
            </div>
            <?php endif; ?>
            
            <section class="ivo-card">
                <div class="ivo-card__head">
                    <div class="ivo-card__icon">⚙</div>
                    <strong><?php echo esc_html( $this->translate( 'Edit IVO Marketplace' ) ); ?></strong>
                    
                    <?php if ( ! $configured ) : ?>
                        <div class="ivo-card__status">
                            <span class="ivo-card__status-dot"></span>
                            <?php echo esc_html( $this->translate( 'Not connected' ) ); ?>
                        </div>
                    <?php else : ?>
                        <div class="ivo-card__status ivo-card__status--connected">
                            <span class="ivo-card__status-dot ivo-card__status-dot--connected"></span>
                            <?php echo esc_html( $this->translate( 'Connected' ) ); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="ivo-card__body">
                    <div>
                        <div class="ivo-card__logo"><img src="https://static.ivo.md/favicon_white.png" alt="IVO" style="width: 42px; height: 42px; object-fit: contain; display: block;" /></div>
                        <p class="ivo-card__eyebrow"><?php echo esc_html( $this->translate( 'WordPress bridge' ) ); ?></p>
                        
                        <?php if ( ! $configured ) : ?>
                            <h2><?php echo esc_html( $this->translate( 'Connect your store to IVO.md.' ) ); ?></h2>
                            <p><?php echo esc_html( $this->translate( 'Authorize your marketplace account, choose what gets synced, then let WooCommerce and IVO work together.' ) ); ?></p>
                            
                            <div class="ivo-card__actions">
                                <a href="<?php echo esc_url( $configure_url ); ?>" class="ivo-card__button">🔌 <?php echo esc_html( $this->translate( 'Configure connection' ) ); ?></a>
                                <a href="<?php echo esc_url( $this->get_help_guide_url() ); ?>" target="_blank" class="ivo-card__link"><?php echo esc_html( $this->translate( 'View setup guide' ) ); ?></a>
                            </div>
                        <?php else : ?>
                            <h2><?php echo esc_html( $this->translate( 'Settings' ) ); ?></h2>
                            <form method="post" action="options.php" style="margin-top: 24px;">
                                <?php settings_fields( 'ivo_marketplace_settings' ); ?>
                                
                                <div class="ivo-form-group">
                                    <label><?php echo esc_html( $this->translate( 'API Key' ) ); ?></label>
                                    <input type="text" value="<?php echo esc_attr( $api_key_masked ); ?>" class="ivo-form-input" readonly disabled />
                                </div>
                                
                                <div class="ivo-form-group">
                                    <label><?php echo esc_html( $this->translate( 'Merchant Point' ) ); ?></label>
                                    <select name="<?php echo esc_attr( self::OPTION_MERCHANT_POINT_ID ); ?>" class="ivo-form-select">
                                        <option value=""><?php echo esc_html( $this->translate( '--- Select ---' ) ); ?></option>
                                        <?php
                                        $listed_point_ids = array();
                                        foreach ( $merchant_points as $point ) :
                                            $point_id = $point['id'] ?? $point['_id'] ?? '';
                                            $listed_point_ids[] = (string) $point_id;
                                            ?>
                                            <option value="<?php echo esc_attr( $point_id ); ?>" <?php selected( $merchant_point_id, $point_id ); ?>>
                                                <?php echo esc_html( $point['name'] ); ?>
                                                <?php if ( ! empty( $point['address'] ) ) : ?>
                                                    - <?php echo esc_html( $point['address'] ); ?>
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>
                                        <?php // The stored point stays selectable when the live list failed or lacks it ?>
                                        <?php if ( $merchant_point_id && ! in_array( (string) $merchant_point_id, $listed_point_ids, true ) ) : ?>
                                            <option value="<?php echo esc_attr( $merchant_point_id ); ?>" selected="selected">
                                                <?php echo esc_html( $this->translate( 'Saved merchant point' ) . ' (' . $merchant_point_id . ')' ); ?>
                                            </option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                
                                <div class="ivo-form-group">
                                    <label><?php echo esc_html( $this->translate( 'Price Modifier (%)' ) ); ?></label>
                                    <?php 
                                        $mod_val = get_option( self::OPTION_PRICE_MODIFIER, '0' ); 
                                        if ( $mod_val === '' ) $mod_val = '0';
                                    ?>
                                    <input type="number" step="0.01" name="<?php echo esc_attr( self::OPTION_PRICE_MODIFIER ); ?>" value="<?php echo esc_attr( $mod_val ); ?>" class="ivo-form-input" />
                                    <p class="description"><?php esc_html_e( 'Automatically adjust product prices sent to IVO (e.g., enter 10 to increase by 10%, or -5 to decrease by 5%). Enter 0 for no change.', 'ivo-marketplace' ); ?></p>
                                </div>
                                
                                <div class="ivo-form-group" style="display: flex; align-items: flex-start; gap: 10px;">
                                    <input type="hidden" name="<?php echo esc_attr( self::OPTION_UPDATE_STOCK ); ?>" value="0" />
                                    <?php 
                                        $update_stock_val = get_option( self::OPTION_UPDATE_STOCK, '1' ); 
                                    ?>
                                    <input type="checkbox" id="ivo_update_stock" name="<?php echo esc_attr( self::OPTION_UPDATE_STOCK ); ?>" value="1" <?php checked( $update_stock_val, '1' ); ?> style="margin-top: 4px; width: 16px; height: 16px; accent-color: #8a24d6;" />
                                    <div>
                                        <label for="ivo_update_stock" style="margin-bottom: 2px; cursor: pointer;"><?php echo esc_html( $this->translate( 'Update stock on sale' ) ); ?></label>
                                        <p class="description" style="margin-top: 0;"><?php echo esc_html( $this->translate( 'Automatically update your WooCommerce stock when a sale occurs on IVO.' ) ); ?></p>
                                    </div>
                                </div>
                                
                                <div class="ivo-card__actions" style="margin-top: 26px;">
                                    <button type="submit" class="ivo-card__button"><?php echo esc_html( $this->translate( 'Save settings' ) ); ?></button>
                                    <a href="<?php echo esc_url( $configure_url ); ?>" class="ivo-card__button-secondary"><?php echo esc_html( $this->translate( 'Reconfigure' ) ); ?></a>
                                    <button type="button" id="btn-force-sync" class="ivo-card__button-secondary">
                                        🔄 <?php echo esc_html( $this->translate( 'Force Sync' ) ); ?>
                                    </button>
                                    <span id="sync-status" class="ivo-sync-status"></span>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ivo-card__setup">
                        <div class="ivo-card__setup-box">
                            <div class="ivo-card__step">
                                <div class="ivo-card__step-number">1</div>
                                <div>
                                    <strong><?php echo esc_html( $this->translate( 'Account access' ) ); ?></strong>
                                    <span><?php echo esc_html( $this->translate( 'Add your IVO API key and merchant identifier.' ) ); ?></span>
                                </div>
                                <?php if ( $configured ) : ?>
                                    <div class="ivo-card__tag ivo-card__tag--success"><?php echo esc_html( $this->translate( 'Success' ) ); ?></div>
                                <?php else : ?>
                                    <div class="ivo-card__tag ivo-card__tag--active"><?php echo esc_html( $this->translate( 'Required' ) ); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="ivo-card__step">
                                <div class="ivo-card__step-number">2</div>
                                <div>
                                    <strong><?php echo esc_html( $this->translate( 'Product sync' ) ); ?></strong>
                                    <span><?php echo esc_html( $this->translate( 'Map categories, prices, stock, and images.' ) ); ?></span>
                                </div>
                                <?php if ( $configured ) : ?>
                                    <div class="ivo-card__tag ivo-card__tag--success"><?php echo esc_html( $this->translate( 'Active' ) ); ?></div>
                                <?php else : ?>
                                    <div class="ivo-card__tag"><?php echo esc_html( $this->translate( 'Next' ) ); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="ivo-card__step">
                                <div class="ivo-card__step-number">3</div>
                                <div>
                                    <strong><?php echo esc_html( $this->translate( 'Update stock' ) ); ?></strong>
                                    <span><?php echo esc_html( $this->translate( 'Automatically sync stock between your store and IVO.' ) ); ?></span>
                                </div>
                                <?php if ( $configured && $update_stock === '1' ) : ?>
                                    <div class="ivo-card__tag ivo-card__tag--success"><?php echo esc_html( $this->translate( 'Active' ) ); ?></div>
                                <?php else : ?>
                                    <div class="ivo-card__tag"><?php echo esc_html( $this->translate( $configured ? 'Inactive' : 'Ready' ) ); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php
    }

    /**
     * Get help guide URL based on current WordPress locale
     */
    public function get_help_guide_url() {
        $locale = get_locale();
        if ( strpos( $locale, 'ru' ) === 0 ) {
            return 'https://www.ivo.md/ru/help/merchant-integration/woocommerce';
        } elseif ( strpos( $locale, 'en' ) === 0 ) {
            return 'https://www.ivo.md/en/help/merchant-integration/woocommerce';
        } else {
            return 'https://www.ivo.md/help/merchant-integration/woocommerce';
        }
    }

    /**
     * Helper to translate custom admin strings
     */
    private function translate( $text ) {
        $locale = get_locale();
        $is_ro = strpos( $locale, 'ro' ) === 0;
        $is_ru = strpos( $locale, 'ru' ) === 0;

        $dictionary = array(
            'Edit IVO Marketplace' => array(
                'ro' => 'Editare IVO Marketplace',
                'ru' => 'Редактировать IVO Marketplace',
            ),
            'Not connected' => array(
                'ro' => 'Neconectat',
                'ru' => 'Не подключено',
            ),
            'Connected' => array(
                'ro' => 'Conectat',
                'ru' => 'Подключено',
            ),
            'Connect your store to IVO.md.' => array(
                'ro' => 'Conectează-ți magazinul la IVO.md.',
                'ru' => 'Подключите свой магазин к IVO.md.',
            ),
            'Authorize your marketplace account, choose what gets synced, then let WooCommerce and IVO work together.' => array(
                'ro' => 'Autorizează contul de marketplace, alege ce dorești să sincronizezi, apoi lasă WooCommerce și IVO să lucreze împreună.',
                'ru' => 'Авторизуйте свой аккаунт на маркетплейсе, выберите, что синхронизировать, и позвольте WooCommerce и IVO работать вместе.',
            ),
            'Configure connection' => array(
                'ro' => 'Configurează conexiunea',
                'ru' => 'Настроить подключение',
            ),
            'View setup guide' => array(
                'ro' => 'Vezi ghidul de configurare',
                'ru' => 'Посмотреть руководство по настройке',
            ),
            'Account access' => array(
                'ro' => 'Acces cont',
                'ru' => 'Доступ к аккаунту',
            ),
            'Add your IVO API key and merchant identifier.' => array(
                'ro' => 'Adaugă cheia API IVO și identificatorul de comerciant.',
                'ru' => 'Добавьте API-ключ IVO и идентификатор продавца.',
            ),
            'Product sync' => array(
                'ro' => 'Sincronizare produse',
                'ru' => 'Синхронизация товаров',
            ),
            'Map categories, prices, stock, and images.' => array(
                'ro' => 'Asociază categoriile, prețurile, stocurile și imaginile.',
                'ru' => 'Сопоставьте категории, цены, запасы и изображения.',
            ),
            'Update stock' => array(
                'ro' => 'Actualizare stoc',
                'ru' => 'Обновление остатков',
            ),
            'Automatically sync stock between your store and IVO.' => array(
                'ro' => 'Sincronizează automat stocurile între magazin și IVO.',
                'ru' => 'Автоматически синхронизируйте остатки между магазином и IVO.',
            ),
            'Success' => array(
                'ro' => 'Succes',
                'ru' => 'Успех',
            ),
            'Required' => array(
                'ro' => 'Necesar',
                'ru' => 'Обязательно',
            ),
            'Next' => array(
                'ro' => 'Următorul',
                'ru' => 'Далее',
            ),
            'Ready' => array(
                'ro' => 'Pregătit',
                'ru' => 'Готово',
            ),
            'Active' => array(
                'ro' => 'Activ',
                'ru' => 'Активен',
            ),
            'Inactive' => array(
                'ro' => 'Inactiv',
                'ru' => 'Неактивен',
            ),
            'Settings' => array(
                'ro' => 'Setări',
                'ru' => 'Настройки',
            ),
            'Save settings' => array(
                'ro' => 'Salvează setările',
                'ru' => 'Сохранить настройки',
            ),
            'Reconfigure' => array(
                'ro' => 'Reconfigurează',
                'ru' => 'Перенастроить',
            ),
            'Force Sync' => array(
                'ro' => 'Sincronizare forțată',
                'ru' => 'Принудительная синхронизация',
            ),
            'WordPress bridge' => array(
                'ro' => 'Conexiune WordPress',
                'ru' => 'Мост WordPress',
            ),
            'Update stock on sale' => array(
                'ro' => 'Actualizează stocul la vânzare',
                'ru' => 'Обновлять наличие при продаже',
            ),
            'Automatically update your WooCommerce stock when a sale occurs on IVO.' => array(
                'ro' => 'Actualizează automat stocul WooCommerce atunci când are loc o vânzare pe IVO.',
                'ru' => 'Автоматически обновлять наличие в WooCommerce при продаже на IVO.',
            ),
            'Saved merchant point' => array(
                'ro' => 'Punctul de vânzare salvat',
                'ru' => 'Сохранённая торговая точка',
            ),
            'Synced %s of %s products...' => array(
                'ro' => 'Sincronizate %s din %s produse...',
                'ru' => 'Синхронизировано %s из %s товаров...',
            ),
        );

        if ( isset( $dictionary[$text] ) ) {
            if ( $is_ro && isset( $dictionary[$text]['ro'] ) ) {
                return $dictionary[$text]['ro'];
            }
            if ( $is_ru && isset( $dictionary[$text]['ru'] ) ) {
                return $dictionary[$text]['ru'];
            }
        }

        return $text;
    }
    
    /**
     * Add product metabox
     * 
     */
    public function add_product_metabox() {
        if ( ! $this->is_configured() ) {
            return;
        }
        
        add_meta_box(
            'ivo-marketplace-status',
            __( 'IVO Marketplace', 'ivo-marketplace' ),
            array( $this, 'render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }
    
    /**
     * Render product metabox
     * 
     */
    public function render_product_metabox( $post ) {
        $product_id = $post->ID;
        $product = wc_get_product( $product_id );
        $is_variable = $product && $product->is_type( 'variable' );
        $variations = array();
        
        if ( $is_variable ) {
            foreach ( $product->get_available_variations() as $v ) {
                $variation = wc_get_product( $v['variation_id'] );
                if ( $variation ) {
                    $attrs = array();
                    foreach ( $variation->get_variation_attributes() as $val ) {
                        if ( $val ) $attrs[] = $val;
                    }
                    $variations[] = array(
                        'id' => $v['variation_id'],
                        'name' => implode( ', ', $attrs ),
                        'sku' => $this->internal_id( $variation ),
                    );
                }
            }
        }
        ?>
        <div id="ivo-status-container">
            <?php if ( $is_variable && ! empty( $variations ) ) : ?>
                <!-- Variable Product: Show each variation -->
                <p style="margin-bottom: 15px; color: #666;">
                    <span class="dashicons dashicons-info"></span>
                    <?php printf( esc_html__( 'This variable product has %d variations. Each variation is synced separately to IVO.', 'ivo-marketplace' ), count( $variations ) ); ?>
                </p>
                <div id="ivo-variations-list" style="max-height: 400px; overflow-y: auto;">
                    <?php foreach ( $variations as $var ) : ?>
                        <div class="ivo-variation-item" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; background: #f9f9f9;">
                            <strong><?php echo esc_html( $var['name'] ); ?></strong>
                            <span style="color: #666; font-size: 12px;">(SKU: <?php echo esc_html( $var['sku'] ); ?>)</span>
                            <div id="ivo-variation-status-<?php echo esc_attr( $var['id'] ); ?>" style="margin-top: 8px;">
                                <span class="spinner is-active" style="float: none; margin: 0;"></span>
                                <span style="color: #666;"><?php esc_html_e( 'Loading...', 'ivo-marketplace' ); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <!-- Simple Product: Show single status -->
                <div id="ivo-loading" class="ivo-loading">
                    <span class="spinner is-active"></span>
                    <p><?php esc_html_e( 'Loading...', 'ivo-marketplace' ); ?></p>
                </div>
                <div id="ivo-status-content" style="display:none;">
                    <h4 id="ivo-status-header"></h4>
                    <p id="ivo-status-description"></p>
                    <div id="ivo-view-btn-container" style="display:none; margin-top:10px;">
                        <a id="ivo-product-url" href="#" target="_blank" class="button button-primary" style="background-color: #eb5202; border-color: #eb5202;">
                            <?php esc_html_e( 'View Product', 'ivo-marketplace' ); ?>
                        </a>
                    </div>
                </div>
                <div id="ivo-error" class="notice notice-error" style="display:none; margin:0;"></div>
            <?php endif; ?>
            
            <hr style="margin: 15px 0;">
            <button type="button" id="btn-ivo-sync" class="button" data-product-id="<?php echo esc_attr( $product_id ); ?>">
                <span class="dashicons dashicons-update"></span>
                <?php esc_html_e( 'Force Sync with IVO', 'ivo-marketplace' ); ?>
            </button>
            <span id="ivo-sync-status" style="display:block; margin-top:5px;"></span>
        </div>
        <script>
        jQuery(document).ready(function($) {
            <?php if ( $is_variable && ! empty( $variations ) ) : ?>
                // Load status for each variation
                var variations = <?php echo json_encode( $variations ); ?>;
                variations.forEach(function(v) {
                    loadVariationStatus(v.id, v.name);
                });
            <?php else : ?>
                loadIvoStatus(<?php echo esc_js( $product_id ); ?>);
            <?php endif; ?>
        });
        
        function loadVariationStatus(variationId, variationName) {
            var container = jQuery('#ivo-variation-status-' + variationId);
            jQuery.ajax({
                url: ivo_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'ivo_get_product_status',
                    nonce: ivo_ajax.nonce,
                    product_id: variationId
                },
                success: function(response) {
                    if (response.success && response.data.status) {
                        var status = response.data.status;
                        var statusClass = status === 'active' ? 'color: green;' : (status === 'pending' ? 'color: orange;' : 'color: #666;');
                        var html = '<span style="' + statusClass + ' font-weight: bold;">' + status.toUpperCase() + '</span>';
                        if (response.data.url) {
                            html += ' <a href="' + response.data.url + '" target="_blank" style="margin-left: 10px;">View on IVO</a>';
                        }
                        container.html(html);
                    } else {
                        container.html('<span style="color: #999;">' + ivo_ajax.strings.not_synced + '</span>');
                    }
                },
                error: function() {
                    container.html('<span style="color: red;">Error</span>');
                }
            });
        }
        </script>
        <?php
    }
    
    /**
     * AJAX: Force sync, one slice per request (see sync_slice). The page calls
     * again with the returned `after` and `run_id` until `done`.
     */
    public function ajax_force_sync() {
        check_ajax_referer( 'ivo_marketplace_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Warning: You do not have permission to modify IVO Marketplace!', 'ivo-marketplace' ) ) );
        }

        $after = isset( $_POST['after'] ) ? absint( $_POST['after'] ) : 0;
        $run_id = isset( $_POST['run_id'] ) ? preg_replace( '/[^A-Za-z0-9_]/', '', (string) wp_unslash( $_POST['run_id'] ) ) : '';

        try {
            $slice = $this->sync_slice( $after, $run_id );
        } catch ( \Throwable $e ) {
            $this->log( 'error', 'Force Sync error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            wp_send_json_error( array( 'message' => sprintf( __( 'Force sync failed: %s', 'ivo-marketplace' ), $e->getMessage() ) ) );
        }

        if ( ! $slice ) {
            wp_send_json_error( array( 'message' => $this->last_sync_error ) );
        }

        if ( $slice['done'] ) {
            // Every price went out with the current modifier
            delete_option( self::OPTION_RESYNC_PENDING );
            // EXACT message from Magento: "Products synchronization started successfully."
            $slice['message'] = __( 'Products synchronization started successfully.', 'ivo-marketplace' );
        }

        wp_send_json_success( $slice );
    }

    /**
     * One slice of a full sync: the next published products by ID after
     * $after, expanded into the payloads IVO receives and sent in batches.
     *
     * The page walks the catalogue slice by slice, so no request runs anywhere
     * near a shop's PHP or proxy timeout (often 30 s). Every slice carries the
     * same run id and the last one closes the run, so IVO zeroes what the run
     * never mentioned. A failed slice stops the walk before that, so a partial
     * run never zeroes products that merely did not arrive. Paging by ID, not
     * offset, keeps a product added or deleted mid-run from shifting the pages
     * and skipping a neighbour.
     */
    private function sync_slice( $after, $run_id ) {
        global $wpdb;

        $this->last_sync_error = '';
        $api_key = $this->get_api_key();
        $merchant_point_id = $api_key ? $this->get_merchant_point_id() : null;
        if ( ! $api_key || ! $merchant_point_id ) {
            // EXACT message from Magento: "Unable to fetch Merchant Point ID. Please check API Key configuration."
            $this->last_sync_error = __( 'Unable to fetch Merchant Point ID. Please check API Key configuration.', 'ivo-marketplace' );
            return false;
        }

        if ( $run_id === '' ) {
            $run_id = 'wc_' . time() . '_' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 12 );
        }

        $published = "post_type = 'product' AND post_status = 'publish'";
        $product_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE {$published} AND ID > %d ORDER BY ID ASC LIMIT %d",
            $after,
            self::SYNC_SLICE_PRODUCTS
        ) );

        $currency = get_woocommerce_currency();
        $payloads = array();
        $consumed = 0;

        foreach ( $product_ids as $product_id ) {
            $after = (int) $product_id;
            $consumed++;

            $product = wc_get_product( $product_id );
            if ( $product ) {
                $payloads = array_merge( $payloads, $this->prepare_product_payloads( $product, $merchant_point_id, $currency ) );
            }

            if ( count( $payloads ) >= self::SYNC_SLICE_PAYLOADS ) {
                break;
            }
        }

        // One product can have more variations than IVO takes in one call
        if ( ! $this->sync_in_batches( $payloads, $api_key, $run_id ) ) {
            return false;
        }

        $done = $consumed === count( $product_ids ) && count( $product_ids ) < self::SYNC_SLICE_PRODUCTS;
        if ( $done ) {
            $this->complete_sync_run( $run_id, $api_key );
        }

        return array(
            'done' => $done,
            'after' => $after,
            'run_id' => $run_id,
            'position' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE {$published} AND ID <= %d", $after ) ),
            'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE {$published}" ),
        );
    }

    /**
     * Close a full-sync run: products IVO knows from this store that were NOT
     * part of the run no longer exist here, so their offers go out of stock.
     */
    public function complete_sync_run( $run_id, $api_key = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }

        if ( ! $api_key || ! $run_id ) {
            return array( 'code' => 0, 'response' => null );
        }

        $payload = array(
            'import_name' => 'api_sync_import_woocommerce',
            'integration_run_id' => $run_id,
        );

        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, IVO_API_BASE_URL . '/v1/merchant-api/product/complete-run' );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
            'Content-Type: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $payload ) );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 60 );

        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $curl_error = curl_error( $ch );
        curl_close( $ch );

        if ( $curl_error || $http_code < 200 || $http_code >= 300 ) {
            $this->log( 'error', sprintf(
                'Complete run %s failed: HTTP %d%s, response: %s',
                $run_id,
                $http_code,
                $curl_error ? ' (' . $curl_error . ')' : '',
                mb_substr( (string) $response, 0, 1000 )
            ) );
        }

        return array( 'code' => $http_code, 'response' => is_string( $response ) ? json_decode( $response, true ) : null, 'error' => $curl_error );
    }

    /**
     * A new price modifier: every price on IVO is stale. The catalogue is not
     * re-sent inside the options.php request (one request cannot carry it);
     * the settings page it redirects to starts the sliced Force Sync.
     */
    public function on_price_modifier_update( $old_value, $value, $option ) {
        if ( (float) $old_value !== (float) $value ) {
            update_option( self::OPTION_RESYNC_PENDING, 1 );
        }
    }

    /**
     * The first save of the price modifier adds the option instead
     */
    public function on_price_modifier_add( $option, $value ) {
        if ( (float) $value !== 0.0 ) {
            update_option( self::OPTION_RESYNC_PENDING, 1 );
        }
    }
    
    /**
     * AJAX: Get product status
     * 
     */
    public function ajax_get_product_status() {
        check_ajax_referer( 'ivo_marketplace_nonce', 'nonce' );
        
        $product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
        
        if ( ! $product_id ) {
            wp_send_json_error( array( 'message' => 'Product ID required' ) );
        }
        
        $api_key = $this->get_api_key();
        
        if ( ! $api_key ) {
            wp_send_json_error( array( 'message' => __( 'Not configured.', 'ivo-marketplace' ) ) );
        }
        
        $product = wc_get_product( $product_id );
        
        if ( ! $product ) {
            wp_send_json_error( array( 'message' => 'Product not found' ) );
        }
        
        $sku = $this->internal_id( $product );
        $ivo_data = $this->get_product_ivo_info( $sku, $api_key );
        
        // API response format:
        // Success: { status: "success", product: {...}, offer: {...} }
        // Error: { status: "error", message: "code" }
        if ( $ivo_data && isset( $ivo_data['status'] ) && $ivo_data['status'] === 'success' && isset( $ivo_data['product'] ) ) {
            wp_send_json_success( array(
                'status' => 'success',
                'name' => $ivo_data['product']['name'] ?? array(),
                'urls' => $ivo_data['product']['urls'] ?? array(),
                'url' => $ivo_data['product']['url'] ?? '',
            ) );
        } elseif ( $ivo_data && isset( $ivo_data['status'] ) && $ivo_data['status'] === 'error' && isset( $ivo_data['message'] ) ) {
            wp_send_json_success( array(
                'status' => 'error',
                'message' => $ivo_data['message'],
            ) );
        } else {
            wp_send_json_success( array(
                'status' => 'error',
                'message' => 'not_imported',
            ) );
        }
    }
    
    /**
     * AJAX: Sync single product
     * 
     */
    public function ajax_sync_product() {
        check_ajax_referer( 'ivo_marketplace_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Warning: You do not have permission to modify IVO Marketplace!', 'ivo-marketplace' ) ) );
        }
        
        $product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
        
        if ( ! $product_id ) {
            wp_send_json_error( array( 'message' => 'Product ID required' ) );
        }
        
        $api_key = $this->get_api_key();
        $merchant_point_id = $this->get_merchant_point_id();
        
        if ( ! $api_key || ! $merchant_point_id ) {
            wp_send_json_error( array( 'message' => __( 'Unable to fetch Merchant Point ID. Please check API Key configuration.', 'ivo-marketplace' ) ) );
        }
        
        $product = wc_get_product( $product_id );
        
        if ( ! $product ) {
            wp_send_json_error( array( 'message' => 'Product not found' ) );
        }
        
        $currency = get_woocommerce_currency();
        
        // Use helper to handle both simple and variable products
        $products_data = $this->prepare_product_payloads( $product, $merchant_point_id, $currency );
        
        if ( empty( $products_data ) ) {
            wp_send_json_error( array( 'message' => __( 'Product cannot be synced. Please ensure it has a valid price.', 'ivo-marketplace' ) ) );
        }
        
        if ( $this->sync_in_batches( $products_data, $api_key ) ) {
            wp_send_json_success( array( 'message' => __( 'Product synced successfully!', 'ivo-marketplace' ) ) );
        } else {
            wp_send_json_error( array( 'message' => $this->last_sync_error ) );
        }
    }
    
    /**
     * On product save
     */
    public function on_product_save( $product_id, $product = null ) {
        if ( ! $product ) {
            $product = wc_get_product( $product_id );
        }

        if ( ! $product ) {
            return;
        }

        // An unpublished product sells nothing. transition_post_status has
        // just zeroed it; pushing its real stock here would undo that.
        $status = $product->is_type( 'variation' ) ? get_post_status( $product->get_parent_id() ) : $product->get_status();
        if ( 'publish' !== $status ) {
            $this->push_out_of_stock( $product->get_id() );
            return;
        }

        // A store with an API key and a merchant point pushes; nothing else gates it
        $api_key = $this->get_api_key();
        if ( ! $api_key ) {
            return;
        }
        $merchant_point_id = $this->get_push_merchant_point_id( 'Product ' . $product->get_id() );
        if ( ! $merchant_point_id ) {
            return;
        }

        $currency = get_woocommerce_currency();

        // Use helper to handle both simple and variable products
        $products_data = $this->prepare_product_payloads( $product, $merchant_point_id, $currency );

        $this->sync_in_batches( $products_data, $api_key );
    }
    
    /**
     * A product being trashed or permanently deleted disappears from every
     * future sync, so nothing would ever zero its IVO offer. Push the zero
     * now, while the product (and its SKUs) can still be read.
     */
    public function on_product_remove( $post_id ) {
        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'product', 'product_variation' ), true ) ) {
            return;
        }

        $this->push_out_of_stock( $post_id );
    }

    /**
     * Unpublishing (draft/pending/private) has the same effect as deleting:
     * a full sync only reads published products, so nothing else would zero
     * the offer. Trash is handled by on_product_remove.
     */
    public function on_product_status_change( $new_status, $old_status, $post ) {
        if ( ! $post || 'product' !== $post->post_type ) {
            return;
        }

        if ( 'publish' !== $old_status || 'publish' === $new_status || 'trash' === $new_status ) {
            return;
        }

        $this->push_out_of_stock( $post->ID );
    }

    /**
     * Send availability 0 for a product (every variation of a variable one)
     * as an availability-only sync: the server only updates rows/offers it
     * already knows, so this can never create products.
     */
    public function push_out_of_stock( $product_id ) {
        $api_key = $this->get_api_key();
        if ( ! $api_key ) {
            return;
        }
        $merchant_point_id = $this->get_push_merchant_point_id( 'Out-of-stock update for product ' . $product_id );
        if ( ! $merchant_point_id ) {
            return;
        }

        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            return;
        }

        $internal_ids = array();
        if ( $product->is_type( 'variable' ) ) {
            foreach ( $product->get_children() as $child_id ) {
                $child = wc_get_product( $child_id );
                if ( $child ) {
                    $internal_ids[] = $this->internal_id( $child );
                }
            }
        } else {
            $internal_ids[] = $this->internal_id( $product );
        }

        $products_payload = array();
        foreach ( array_unique( array_filter( $internal_ids ) ) as $internal_id ) {
            $products_payload[] = $this->availability_item( $internal_id, 0, $merchant_point_id );
        }

        $this->push_availability( $products_payload, $api_key );
    }

    /**
     * On order complete: the stock of every product the order holds.
     *
     * Availability only, as an order changes nothing else. A full payload
     * built from a line's variation went out as a stand-alone product and
     * overwrote the variation offer's name and dropped its group.
     */
    public function on_order_complete( $order_id ) {
        $api_key = $this->get_api_key();
        if ( ! $api_key ) {
            return;
        }
        $merchant_point_id = $this->get_push_merchant_point_id( 'Stock update for order ' . $order_id );
        if ( ! $merchant_point_id ) {
            return;
        }
        
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }
        
        // Keyed by merchant internal id, so a product on two lines goes once
        $products_payload = array();
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product();
            if ( ! $product ) {
                continue;
            }
            
            foreach ( $this->prepare_availability_items( $product, $merchant_point_id ) as $availability_item ) {
                $products_payload[ $availability_item['merchant_internal_id'] ] = $availability_item;
            }
        }
        
        $this->push_availability( array_values( $products_payload ), $api_key );
    }

    /**
     * Stock changed in the store (an order, an edit, an import): push the
     * new availability now, not at the next full sync.
     */
    public function on_stock_change( $product ) {
        if ( ! $product instanceof WC_Product ) {
            return;
        }

        $api_key = $this->get_api_key();
        if ( ! $api_key ) {
            return;
        }
        $merchant_point_id = $this->get_push_merchant_point_id( 'Stock update for product ' . $product->get_id() );
        if ( ! $merchant_point_id ) {
            return;
        }

        $this->push_availability( $this->prepare_availability_items( $product, $merchant_point_id ), $api_key );
    }

    /**
     * Availability-only items for a product whose stock changed. Stock held by
     * a variable parent is shared by every variation that defers to it, so
     * then all of them go, each still answering with its own stock first.
     */
    private function prepare_availability_items( $product, $merchant_point_id ) {
        $parent = null;
        $variation_ids = array();

        if ( $product->is_type( 'variation' ) ) {
            $parent = wc_get_product( $product->get_parent_id() );
            if ( ! $parent ) {
                return array();
            }
            $variation_ids = (int) $product->get_stock_managed_by_id() === (int) $parent->get_id()
                ? $parent->get_children()
                : array( $product->get_id() );
        } elseif ( $product->is_type( 'variable' ) ) {
            $parent = $product;
            $variation_ids = $product->get_children();
        }

        if ( ! $parent ) {
            $availability = $this->is_sellable( $product ) ? $this->get_product_availability( $product ) : 0;
            return array( $this->availability_item( $this->internal_id( $product ), $availability, $merchant_point_id ) );
        }

        $items = array();
        foreach ( $variation_ids as $variation_id ) {
            $variation = wc_get_product( $variation_id );
            if ( ! $variation || ! $variation->is_type( 'variation' ) ) {
                continue;
            }
            $availability = $this->is_sellable( $variation, $parent ) ? $this->get_product_availability( $variation ) : 0;
            $items[] = $this->availability_item( $this->internal_id( $variation ), $availability, $merchant_point_id );
        }

        return $items;
    }

    /**
     * One availability-only item: IVO updates the existing offer's stock on
     * the spot and never creates a product from it
     */
    private function availability_item( $merchant_internal_id, $availability, $merchant_point_id ) {
        return array(
            'availability_only' => true,
            'availability' => (int) $availability,
            'merchant_internal_id' => (string) $merchant_internal_id,
            'merchant_point_id' => $merchant_point_id,
        );
    }

    /**
     * Push availability-only items. One store change fires several hooks
     * (the product save, the stock change, the order), so a value IVO already
     * accepted in this request is not sent again.
     */
    private function push_availability( $items, $api_key ) {
        $fresh = array();
        foreach ( $items as $item ) {
            $internal_id = $item['merchant_internal_id'];
            if ( ! isset( $this->pushed_availability[ $internal_id ] ) || $this->pushed_availability[ $internal_id ] !== $item['availability'] ) {
                $fresh[] = $item;
            }
        }

        $this->sync_in_batches( $fresh, $api_key );
    }

    /**
     * The ID a product or variation is known by on IVO: its own SKU, else its
     * WooCommerce ID. Read in 'edit' context: in 'view' context a variation
     * without a SKU of its own returns its parent's, which put every such
     * variation of a product onto one IVO offer.
     */
    private function internal_id( $product ) {
        return $product->get_sku( 'edit' ) ?: (string) $product->get_id();
    }

    /**
     * Whether the store sells this product now. A disabled variation is
     * 'private'; a variation also needs a published parent, and must be
     * purchasable (a price, among others) and in stock.
     */
    private function is_sellable( $product, $parent = null ) {
        if ( 'publish' !== $product->get_status() ) {
            return false;
        }
        if ( ! $parent ) {
            return true;
        }
        return 'publish' === $parent->get_status() && $product->is_purchasable() && $product->is_in_stock();
    }
    
    /**
     * Check if configured
     */
    /**
     * Get product availability: real stock only. Out of stock is 0, a negative
     * quantity is 0, and a backorder is not stock. Unmanaged stock that is in
     * stock has no number, so it goes as 9999.
     */
    public function get_product_availability( $product ) {
        if ( ! $product->is_in_stock() ) {
            return 0;
        }

        // If stock management is enabled for this product, use the stock quantity
        if ( $product->managing_stock() ) {
            return max( 0, (int) $product->get_stock_quantity() );
        }
        
        // Stock management disabled - only 'instock' is stock; 'onbackorder' is not
        if ( $product->get_stock_status() === 'instock' ) {
            // Product is available but quantity not tracked - send high number
            return 9999;
        }
        
        return 0;
    }
    

    public function is_configured() {
        return (bool) get_option( self::OPTION_CONFIGURED, false );
    }
    
    /**
     * Get product images (featured + gallery)
     * Returns array of image URLs
     */
    public function get_product_images( $product, $parent_product = null ) {
        $images = array();
        
        // Get featured/main image
        $image_id = $product->get_image_id();
        if ( $image_id ) {
            $image_url = wp_get_attachment_url( $image_id );
            if ( $image_url ) {
                $images[] = $image_url;
            }
        }
        
        // Get gallery images
        $gallery_ids = $product->get_gallery_image_ids();
        if ( ! empty( $gallery_ids ) ) {
            foreach ( $gallery_ids as $gallery_id ) {
                $gallery_url = wp_get_attachment_url( $gallery_id );
                if ( $gallery_url && ! in_array( $gallery_url, $images ) ) {
                    $images[] = $gallery_url;
                }
            }
        }
        
        // For variations without images, fall back to parent product images
        if ( empty( $images ) && $parent_product ) {
            $parent_image_id = $parent_product->get_image_id();
            if ( $parent_image_id ) {
                $parent_image_url = wp_get_attachment_url( $parent_image_id );
                if ( $parent_image_url ) {
                    $images[] = $parent_image_url;
                }
            }
            
            $parent_gallery_ids = $parent_product->get_gallery_image_ids();
            if ( ! empty( $parent_gallery_ids ) ) {
                foreach ( $parent_gallery_ids as $gallery_id ) {
                    $gallery_url = wp_get_attachment_url( $gallery_id );
                    if ( $gallery_url && ! in_array( $gallery_url, $images ) ) {
                        $images[] = $gallery_url;
                    }
                }
            }
        }
        
        return $images;
    }
    
    /**
     * Get product category path (deepest category, full path e.g. "Electronics > Phones")
     * Matches Magento's category path logic
     */
    public function get_product_category( $product_id ) {
        $terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'all' ) );
        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            return '';
        }
        
        // Build full path for each term by traversing parents
        $term_map = array();
        foreach ( $terms as $term ) {
            $term_map[ $term->term_id ] = $term;
        }
        
        $paths = array();
        foreach ( $terms as $term ) {
            $path_names = array( $term->name );
            $parent_id  = $term->parent;
            
            while ( $parent_id ) {
                // Try from already-fetched terms first, then fetch from DB
                if ( isset( $term_map[ $parent_id ] ) ) {
                    $parent = $term_map[ $parent_id ];
                } else {
                    $parent = get_term( $parent_id, 'product_cat' );
                    if ( is_wp_error( $parent ) || ! $parent ) {
                        break;
                    }
                    $term_map[ $parent_id ] = $parent;
                }
                array_unshift( $path_names, $parent->name );
                $parent_id = $parent->parent;
            }
            
            $paths[] = implode( ' > ', $path_names );
        }
        
        if ( empty( $paths ) ) {
            return '';
        }
        
        // Use the deepest path (most specific category), matching Magento behaviour
        usort( $paths, function( $a, $b ) {
            return substr_count( $b, '>' ) - substr_count( $a, '>' );
        } );
        
        return $paths[0];
    }
    
    /**
     * Get product description (short description + full description)
     */
    public function get_product_description( $product ) {
        $parts = array();
        
        $short = $product->get_short_description();
        if ( $short ) {
            $parts[] = wp_strip_all_tags( $short );
        }
        
        $full = $product->get_description();
        if ( $full ) {
            $parts[] = wp_strip_all_tags( $full );
        }
        
        return implode( "\n\n", $parts );
    }
    
    /**
     * Get product brand (checks pa_brand attribute and product_brand taxonomy)
     */
    public function get_product_brand( $product ) {
        // Check product_brand taxonomy (used by many brand plugins)
        $brand_terms = wp_get_post_terms( $product->get_id(), 'product_brand', array( 'fields' => 'names' ) );
        if ( ! is_wp_error( $brand_terms ) && ! empty( $brand_terms ) ) {
            return $brand_terms[0];
        }
        
        // Check pa_brand attribute (WooCommerce global attribute)
        $brand = $product->get_attribute( 'pa_brand' );
        if ( $brand ) {
            return $brand;
        }
        
        // Check plain "brand" attribute
        $brand = $product->get_attribute( 'brand' );
        if ( $brand ) {
            return $brand;
        }
        
        return '';
    }
    
    /**
     * Get product weight and package dimensions, each with its unit spelled out
     * (IVO converts units itself). A variation inherits empty values from its
     * parent through the 'view' context. Empty or zero values are left out, and
     * the three dimensions are sent together or not at all.
     */
    public function get_product_measures( $product ) {
        $measures = array();

        $weight_unit = strtolower( (string) get_option( 'woocommerce_weight_unit', 'kg' ) );
        $weight      = $this->format_measure( $product->get_weight() );
        if ( $weight !== null && in_array( $weight_unit, array( 'kg', 'g', 'lbs', 'oz' ), true ) ) {
            $measures['weight'] = $weight . ' ' . $weight_unit;
        }

        // WooCommerce offers m, cm, mm, in and yd; IVO has no yards, so send inches
        $dimension_unit = strtolower( (string) get_option( 'woocommerce_dimension_unit', 'cm' ) );
        $factor = 1;
        if ( $dimension_unit === 'yd' ) {
            $dimension_unit = 'in';
            $factor = 36;
        }
        if ( in_array( $dimension_unit, array( 'mm', 'cm', 'm', 'in' ), true ) ) {
            $length = $this->format_measure( $product->get_length(), $factor );
            $width  = $this->format_measure( $product->get_width(), $factor );
            $height = $this->format_measure( $product->get_height(), $factor );
            if ( $length !== null && $width !== null && $height !== null ) {
                $measures['length'] = $length . ' ' . $dimension_unit;
                $measures['width']  = $width . ' ' . $dimension_unit;
                $measures['height'] = $height . ' ' . $dimension_unit;
            }
        }

        return $measures;
    }

    /**
     * Format a positive measure as a plain decimal string; null when empty, zero or not numeric
     */
    private function format_measure( $value, $factor = 1 ) {
        if ( ! is_numeric( $value ) ) {
            return null;
        }
        $value = round( (float) $value * $factor, 4 );
        if ( $value <= 0 ) {
            return null;
        }
        return rtrim( rtrim( number_format( $value, 4, '.', '' ), '0' ), '.' );
    }

    /**
     * Get the regular price as IVO's recommended retail price while a sale is
     * active; get_price() is then the sale price sent as 'price'. The regular
     * price skips the price modifier. Empty when not on sale or not higher.
     */
    public function get_retail_price_field( $product ) {
        if ( ! $product->is_on_sale() ) {
            return array();
        }
        $regular = (float) $product->get_regular_price();
        if ( $regular <= (float) $product->get_price() ) {
            return array();
        }
        return array( 'retail_price' => round( $regular, 2 ) );
    }
    
    /**
     * Get API key
     */
    /**
     * Prepare product payloads - handles both simple and variable products
     * Variable products are expanded into individual variation payloads
     */
    public function prepare_product_payloads( $product, $merchant_point_id, $currency ) {
        $payloads = array();
        
        // Gather shared fields from the parent/simple product
        $description = $this->get_product_description( $product );
        $brand       = $this->get_product_brand( $product );
        $category    = $this->get_product_category( $product->get_id() );
        
        // Check if it is a variable product
        if ( $product->is_type( 'variable' ) ) {
            // Every variation, not get_available_variations(): that leaves out
            // disabled and priceless ones (and out-of-stock ones when the shop
            // hides them), so IVO kept selling them at their last pushed stock
            foreach ( $product->get_children() as $variation_id ) {
                $variation = wc_get_product( $variation_id );
                if ( ! $variation || ! $variation->is_type( 'variation' ) ) {
                    continue;
                }

                // A variation the store does not sell goes out at 0
                $sellable = $this->is_sellable( $variation, $product );
                
                // Build variation name with attributes (e.g., "Product Name - Red, Large")
                $variation_name = $category ? $product->get_name() . ' - ' . $category : $product->get_name();
                $attributes = $variation->get_variation_attributes();
                $attr_values = array();
                if ( ! empty( $attributes ) ) {
                    foreach ( $attributes as $attr_key => $attr_value ) {
                        if ( $attr_value ) {
                            $attr_values[] = $attr_value;
                        }
                    }
                    if ( ! empty( $attr_values ) ) {
                        $variation_name .= ' - ' . implode( ', ', $attr_values );
                    }
                }
                
                $payload = array(
                    'name' => $variation_name,
                    'price' => $this->apply_price_modifier( (float) $variation->get_price() ),
                    'currency' => $currency,
                    'availability' => $sellable ? $this->get_product_availability( $variation ) : 0,
                    'merchant_point_id' => $merchant_point_id,
                    'merchant_internal_id' => $this->internal_id( $variation ),
                    'item_group_id' => 'woocommerce-product-' . $product->get_id(),
                    'item_group_title' => $product->get_name(),
                );

                // One item without a name or a price makes IVO reject the whole
                // call. A variation that does not sell must still reach 0.
                if ( ! $this->is_valid_sync_payload( $payload ) ) {
                    if ( $sellable ) {
                        $this->log_skipped_payload( $payload );
                    } else {
                        $payloads[] = $this->availability_item( $payload['merchant_internal_id'], 0, $merchant_point_id );
                    }
                    continue;
                }

                if ( ! empty( $attr_values ) ) {
                    $payload['variant_options'] = array_values( array_unique( $attr_values ) );
                }
                
                // Get images for variation (with parent fallback)
                $images = $this->get_product_images( $variation, $product );
                
                if ( $description ) {
                    $payload['description'] = $description;
                }
                if ( $brand ) {
                    $payload['brand'] = $brand;
                }
                if ( $category ) {
                    $payload['category'] = $category;
                }
                if ( ! empty( $images ) ) {
                    $payload['images'] = $images;
                }
                $payload = array_merge( $payload, $this->get_product_measures( $variation ) );
                $payload = array_merge( $payload, $this->get_retail_price_field( $variation ) );
                
                $payloads[] = $payload;
            }
        } else {
            $product_name = $category ? $product->get_name() . ' - ' . $category : $product->get_name();
            
            $payload = array(
                'name' => $product_name,
                'price' => $this->apply_price_modifier( (float) $product->get_price() ),
                'currency' => $currency,
                'availability' => $this->is_sellable( $product ) ? $this->get_product_availability( $product ) : 0,
                'merchant_point_id' => $merchant_point_id,
                'merchant_internal_id' => $this->internal_id( $product ),
            );

            // One item without a name or a price makes IVO reject the whole call
            if ( $this->is_valid_sync_payload( $payload ) ) {
                // Get images for simple product
                $images = $this->get_product_images( $product );
                
                if ( $description ) {
                    $payload['description'] = $description;
                }
                if ( $brand ) {
                    $payload['brand'] = $brand;
                }
                if ( $category ) {
                    $payload['category'] = $category;
                }
                if ( ! empty( $images ) ) {
                    $payload['images'] = $images;
                }
                $payload = array_merge( $payload, $this->get_product_measures( $product ) );
                $payload = array_merge( $payload, $this->get_retail_price_field( $product ) );
                
                $payloads[] = $payload;
            } else {
                $this->log_skipped_payload( $payload );
            }
        }
        
        return $payloads;
    }

    /**
     * What IVO requires of a full item: a non-empty name and a price of at
     * least 0.01. Availability-only items are exempt.
     */
    public function is_valid_sync_payload( $payload ) {
        return is_array( $payload )
            && isset( $payload['name'] )
            && is_string( $payload['name'] )
            && trim( $payload['name'] ) !== ''
            && isset( $payload['price'] )
            && is_numeric( $payload['price'] )
            && (float) $payload['price'] >= 0.01;
    }

    /**
     * A product left out of a sync is logged, so the merchant can see why it
     * never reached IVO
     */
    private function log_skipped_payload( $payload ) {
        $this->log( 'warning', sprintf(
            'Product %s not sent: a non-empty name and a price of at least 0.01 are required.',
            $payload['merchant_internal_id']
        ) );
    }

    /**
     * Apply the percentage price modifier to a given price
     */
    public function apply_price_modifier( $price ) {
        $modifier = (float) get_option( self::OPTION_PRICE_MODIFIER, '0' );
        if ( $modifier === 0.0 ) {
            return $price;
        }
        $adjusted_price = $price * ( 1 + ( $modifier / 100 ) );
        return round( max( 0.0, $adjusted_price ), 2 );
    }
    

    public function get_api_key() {
        return get_option( self::OPTION_API_KEY, '' );
    }
    
    /**
     * Get setup URL
     * 
     */
    public function get_setup_url() {
        $shop_url = home_url();
        
        // Generate a security nonce and store it temporarily
        $nonce = bin2hex( random_bytes( 16 ) );
        $locale = get_locale();
        update_option( self::OPTION_SETUP_NONCE, $nonce . '|' . time() . '|' . $locale );
        
        // Flush rewrite rules to ensure callback endpoint works
        flush_rewrite_rules();
        
        $return_url = home_url( '/ivo-callback/' ) . '?nonce=' . $nonce;
        
        $params = array(
            'url_shop' => $shop_url,
            'url_return' => $return_url,
            'platform' => 'woocommerce',
            'version' => defined('WC_VERSION') ? WC_VERSION : get_bloginfo('version'),
            'ip_server' => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
            'os_server' => php_uname( 's' ),
            'locale' => $locale,
        );
        
        return IVO_SETUP_URL . '?' . http_build_query( $params );
    }
    
    /**
     * Fetch merchant points from IVO API
     * 
     */
    public function fetch_merchant_points( $api_key = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }
        
        if ( ! $api_key ) {
            return array();
        }
        
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, IVO_API_BASE_URL . '/v1/merchant-api/merchant-points' );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 30 );
        
        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );
        
        if ( $http_code === 200 ) {
            $data = json_decode( $response, true );
            return $this->normalize_merchant_points( $data );
        }
        
        return array();
    }

    /**
     * Normalize API merchant-points responses to a flat list with id aliases.
     */
    private function normalize_merchant_points( $data ) {
        if ( ! is_array( $data ) ) {
            return array();
        }

        $points = $data['points'] ?? $data['data'] ?? $data;
        if ( ! is_array( $points ) ) {
            return array();
        }

        $normalized = array();
        foreach ( $points as $point ) {
            if ( ! is_array( $point ) ) {
                continue;
            }
            if ( isset( $point['_id'] ) && ! isset( $point['id'] ) ) {
                $point['id'] = $point['_id'];
            }
            $normalized[] = $point;
        }

        return $normalized;
    }
    
    /**
     * Get Merchant Point ID
     * 
     */
    public function get_merchant_point_id() {
        // First check option
        $config_id = get_option( self::OPTION_MERCHANT_POINT_ID, '' );
        if ( $config_id ) {
            return $config_id;
        }
        
        // Fetch from API only when the merchant has exactly one possible point.
        $points = $this->fetch_merchant_points();
        if ( count( $points ) === 1 ) {
            return $points[0]['id'] ?? $points[0]['_id'] ?? null;
        }
        
        return null;
    }
    
    /**
     * Sync products to IVO API
     * 
     */
    public function sync_products( $products_data, $api_key = null, $mode = 'async', $integration_run_id = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }

        if ( ! $api_key ) {
            return array( 'code' => 0, 'response' => null );
        }

        // EXACT payload from Magento Config.php syncProducts()
        $payload = array(
            'mode' => $mode,
            'import_name' => 'api_sync_import_woocommerce', // Similar to Magento's "api_sync_import_magento"
            'products' => $products_data,
        );
        if ( $integration_run_id ) {
            $payload['integration_run_id'] = $integration_run_id;
        }
        
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, IVO_API_BASE_URL . '/v1/merchant-api/product/sync-multiple' );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
            'Content-Type: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $payload ) );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 60 );
        
        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $curl_error = curl_error( $ch );
        curl_close( $ch );

        // A rejected push is logged, never dropped silently
        if ( $curl_error || $http_code < 200 || $http_code >= 300 ) {
            $this->log( 'error', sprintf(
                'Sync of %d item(s)%s failed: HTTP %d%s, response: %s',
                count( $products_data ),
                $integration_run_id ? ' in run ' . $integration_run_id : '',
                $http_code,
                $curl_error ? ' (' . $curl_error . ')' : '',
                mb_substr( (string) $response, 0, 1000 )
            ) );
        }

        // EXACT return format from Magento, plus the transport error
        return array( 'code' => $http_code, 'response' => is_string( $response ) ? json_decode( $response, true ) : null, 'error' => $curl_error );
    }

    /**
     * Send items in calls of at most 100: IVO rejects a larger call whole.
     * Every call is made even after one fails, so one rejection drops nothing
     * else. False when any failed, with the first failure in last_sync_error.
     */
    private function sync_in_batches( $products_data, $api_key, $integration_run_id = null ) {
        $this->last_sync_error = '';
        $all_ok = true;

        foreach ( array_chunk( $products_data, 100 ) as $batch ) {
            $result = $this->sync_products( $batch, $api_key, 'async', $integration_run_id );
            if ( $result['code'] >= 200 && $result['code'] < 300 ) {
                foreach ( $batch as $item ) {
                    $this->pushed_availability[ (string) $item['merchant_internal_id'] ] = (int) $item['availability'];
                }
                continue;
            }

            if ( $all_ok ) {
                $this->last_sync_error = $this->format_sync_error( $result, $batch );
            }
            $all_ok = false;
        }

        return $all_ok;
    }

    /**
     * The admin-facing reason a call failed: the HTTP code, IVO's message and,
     * for a validation error, the product and fields it names
     */
    private function format_sync_error( $result, $batch ) {
        $message = sprintf( __( 'Sync failed. API Code: %s', 'ivo-marketplace' ), $result['code'] );
        $response = $result['response'];

        if ( ! is_array( $response ) ) {
            return ! empty( $result['error'] ) ? $message . ' ' . $result['error'] : $message;
        }

        $detail = $response['message'] ?? $response['error'] ?? '';
        if ( is_string( $detail ) && $detail !== '' ) {
            $message .= ' ' . $detail;
        }

        $parts = array();
        if ( isset( $response['index'] ) && isset( $batch[ (int) $response['index'] ]['merchant_internal_id'] ) ) {
            $parts[] = 'product ' . $batch[ (int) $response['index'] ]['merchant_internal_id'];
        }
        if ( isset( $response['errors'] ) && is_array( $response['errors'] ) ) {
            foreach ( $response['errors'] as $field => $messages ) {
                $messages = array_filter( (array) $messages, 'is_scalar' );
                if ( ! empty( $messages ) ) {
                    $parts[] = $field . ': ' . implode( ', ', $messages );
                }
            }
        }
        if ( ! empty( $parts ) ) {
            $message .= ' — ' . implode( '; ', $parts );
        }

        return $message;
    }

    /**
     * The merchant point for an automatic push. Pushes are gated only on the
     * API key and this point, and a missing point is logged, not skipped quietly.
     */
    private function get_push_merchant_point_id( $what ) {
        $merchant_point_id = $this->get_merchant_point_id();
        if ( ! $merchant_point_id ) {
            $this->log( 'warning', $what . ' not sent: no merchant point is selected in the IVO Marketplace settings.' );
        }
        return $merchant_point_id;
    }

    /**
     * Write to the WooCommerce log (WooCommerce > Status > Logs, source ivo-marketplace)
     */
    private function log( $level, $message ) {
        if ( function_exists( 'wc_get_logger' ) ) {
            wc_get_logger()->log( $level, $message, array( 'source' => 'ivo-marketplace' ) );
        } else {
            error_log( 'IVO Marketplace: ' . $message );
        }
    }
    
    /**
     * Get product IVO info by SKU
     * 
     */
    public function get_product_ivo_info( $sku, $api_key = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }
        
        if ( ! $api_key ) {
            return null;
        }
        
        // EXACT payload from Magento Config.php getProductIvoInfo()
        $payload = array(
            'import_name' => 'api_sync_import_woocommerce',
            'merchant_internal_id' => $sku,
        );
        
        $url = IVO_API_BASE_URL . '/v1/merchant-api/product/info-by-sku';
        
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
            'Content-Type: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $payload ) );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 30 );
        
        $response = curl_exec( $ch );
        curl_close( $ch );
        
        if ( $response ) {
            return json_decode( $response, true );
        }
        
        return null;
    }

    /**
     * Register inbound REST endpoints (called from rest_api_init).
     *
     * Endpoint:  POST /wp-json/ivo-marketplace/v1/stock
     * Auth:      Authorization: Bearer <api_key>     (matches stored API key)
     * Body:      { "products": [ { "merchant_internal_id": "SKU-or-ID", "availability": 5 }, ... ] }
     *
     * Triggered when a sale on IVO occurs, so the merchant's local WooCommerce stock stays in sync.
     */
    public function register_webhook_routes() {
        register_rest_route( 'ivo-marketplace/v1', '/stock', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'rest_update_stock' ),
            'permission_callback' => array( $this, 'rest_check_auth' ),
        ) );
    }

    /**
     * Verify Authorization: Bearer <api_key> against the stored API key.
     */
    public function rest_check_auth( $request ) {
        $expected = (string) $this->get_api_key();
        if ( $expected === '' ) {
            return new WP_Error( 'ivo_not_configured', 'IVO Marketplace is not configured', array( 'status' => 503 ) );
        }

        $header = (string) $request->get_header( 'authorization' );
        if ( $header === '' ) {
            return new WP_Error( 'ivo_unauthorized', 'Missing Authorization header', array( 'status' => 401 ) );
        }
        if ( stripos( $header, 'Bearer ' ) === 0 ) {
            $bearer = trim( substr( $header, 7 ) );
        } else {
            $bearer = trim( $header );
        }

        if ( $bearer === '' || ! hash_equals( $expected, $bearer ) ) {
            return new WP_Error( 'ivo_unauthorized', 'Invalid API key', array( 'status' => 401 ) );
        }
        return true;
    }

    /**
     * Handle POST /wp-json/ivo-marketplace/v1/stock
     */
    public function rest_update_stock( $request ) {
        $data = $request->get_json_params();
        if ( ! is_array( $data ) || empty( $data['products'] ) || ! is_array( $data['products'] ) ) {
            return new WP_REST_Response( array(
                'success' => false,
                'error'   => 'Invalid payload: expected { products: [...] }',
            ), 400 );
        }

        $updated = array();
        $errors  = array();
        
        $should_update = get_option( self::OPTION_UPDATE_STOCK, '1' );

        foreach ( $data['products'] as $item ) {
            $ref = isset( $item['merchant_internal_id'] ) ? (string) $item['merchant_internal_id'] : '';
            if ( $ref === '' || ! array_key_exists( 'availability', $item ) ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => 'Missing merchant_internal_id or availability' );
                continue;
            }
            $delta = (int) $item['availability'];

            $product_id = $this->resolve_product_id( $ref );
            if ( ! $product_id ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => 'Product not found' );
                continue;
            }

            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => 'Product not loadable' );
                continue;
            }

            // Unmanaged stock has no count to move. Turning stock management on
            // here (at 9999 + delta) changed the merchant's own product setup.
            if ( ! $product->managing_stock() ) {
                $updated[] = array( 'merchant_internal_id' => $ref, 'note' => 'Skipped (stock not managed)' );
                continue;
            }

            // availability is a movement: negative for a sale on IVO, positive
            // for a cancelled IVO order giving the units back
            $new_stock = max( 0, (int) $product->get_stock_quantity() + $delta );

            if ( $should_update !== '1' ) {
                $updated[] = array( 'merchant_internal_id' => $ref, 'availability' => $new_stock, 'note' => 'Skipped (stock sync disabled)' );
                continue;
            }

            try {
                wc_update_product_stock( $product, $new_stock, 'set' );
                $product->set_stock_status( $new_stock > 0 ? 'instock' : 'outofstock' );
                $product->save();

                $updated[] = array( 'merchant_internal_id' => $ref, 'availability' => $new_stock );
            } catch ( \Throwable $e ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => $e->getMessage() );
            }
        }

        return new WP_REST_Response( array(
            'success' => empty( $errors ),
            'updated' => $updated,
            'errors'  => $errors,
        ), 200 );
    }

    /**
     * Resolve a product (or variation) by SKU first, then by numeric ID.
     */
    private function resolve_product_id( $ref ) {
        $product_id = wc_get_product_id_by_sku( $ref );
        if ( $product_id ) {
            return (int) $product_id;
        }
        if ( ctype_digit( (string) $ref ) ) {
            $product = wc_get_product( (int) $ref );
            if ( $product ) {
                return (int) $ref;
            }
        }
        return 0;
    }
}

// Initialize the plugin
IVO_Marketplace::get_instance();

// Activation hook - flush rewrite rules
register_activation_hook( __FILE__, function() {
    IVO_Marketplace::get_instance()->register_callback_endpoint();
    flush_rewrite_rules();
} );

// Deactivation hook
register_deactivation_hook( __FILE__, function() {
    flush_rewrite_rules();
} );
