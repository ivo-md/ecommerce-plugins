<?php
/**
 * Plugin Name: IVO Marketplace
 * Plugin URI:  https://ivo.md
 * Description: Sync your products with IVO Marketplace. Sell on Moldova's largest marketplace directly from your WooCommerce store.
 * Version:     1.0.12
 * Author:      IVO Team
 * Author URI:  https://ivo.md
 * License:     GPL-2.0+
 * Text Domain: ivo-marketplace
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define plugin constants
define( 'IVO_MARKETPLACE_VERSION', '1.0.12' );
define( 'IVO_MARKETPLACE_DIR', plugin_dir_path( __FILE__ ) );
define( 'IVO_MARKETPLACE_URL', plugin_dir_url( __FILE__ ) );
define( 'IVO_MARKETPLACE_BASENAME', plugin_basename( __FILE__ ) );

// IVO Endpoints
define( 'IVO_SETUP_URL', getenv('IVO_SETUP_URL') ?: 'https://www.preview.ivo.md/merchant/plugin/setup' );
define( 'IVO_API_BASE_URL', getenv('IVO_API_URL') ?: 'https://a.ivo.md' );

/**
 * Main IVO Marketplace Class
 * 
 * EXACT functionality match with Magento/OpenCart
 */
class IVO_Marketplace {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Option keys - similar to Magento's CONFIG_PATH_*
     */
    const OPTION_API_KEY = 'ivo_marketplace_api_key';
    const OPTION_CONFIGURED = 'ivo_marketplace_configured';
    const OPTION_MERCHANT_POINT_ID = 'ivo_marketplace_merchant_point_id';
    const OPTION_SETUP_NONCE = 'ivo_marketplace_setup_nonce';
    const OPTION_PRICE_MODIFIER = 'ivo_marketplace_price_modifier';
    const OPTION_UPDATE_STOCK = 'ivo_marketplace_update_stock';
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Initialize translations early so plugin metadata is localized on the Plugins page.
        add_action( 'plugins_loaded', array( $this, 'init' ), 0 );

        // Check WooCommerce dependency
        add_action( 'plugins_loaded', array( $this, 'check_dependencies' ) );
        
        // Admin hooks
        if ( is_admin() ) {
            add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
            add_action( 'admin_init', array( $this, 'register_settings' ) );
            add_action( 'admin_notices', array( $this, 'admin_notices' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
            
            // Product edit page metabox
            add_action( 'add_meta_boxes', array( $this, 'add_product_metabox' ) );
            
            // AJAX handlers
            add_action( 'wp_ajax_ivo_force_sync', array( $this, 'ajax_force_sync' ) );
            add_action( 'wp_ajax_ivo_get_product_status', array( $this, 'ajax_get_product_status' ) );
            add_action( 'wp_ajax_ivo_sync_product', array( $this, 'ajax_sync_product' ) );
            
            // Settings link on plugins page
            add_filter( 'plugin_action_links_' . IVO_MARKETPLACE_BASENAME, array( $this, 'add_settings_link' ) );
        }
        
        // Product save hook
        add_action( 'woocommerce_update_product', array( $this, 'on_product_save' ), 10, 2 );
        add_action( 'woocommerce_new_product', array( $this, 'on_product_save' ), 10, 2 );

        // A product removed from the store must go out of stock on IVO, or it
        // stays purchasable there forever with its last-pushed availability.
        add_action( 'wp_trash_post', array( $this, 'on_product_remove' ) );
        add_action( 'before_delete_post', array( $this, 'on_product_remove' ) );
        add_action( 'transition_post_status', array( $this, 'on_product_status_change' ), 10, 3 );
        
        // Trigger product updates when price modifier changes
        add_action( 'update_option_' . self::OPTION_PRICE_MODIFIER, array( $this, 'on_price_modifier_update' ), 10, 3 );
        
        // Order complete hook
        add_action( 'woocommerce_order_status_completed', array( $this, 'on_order_complete' ) );
        add_action( 'woocommerce_payment_complete', array( $this, 'on_order_complete' ) );
        
        // Callback endpoint
        add_action( 'init', array( $this, 'register_callback_endpoint' ) );
        add_action( 'template_redirect', array( $this, 'handle_callback' ) );

        // Inbound stock-update webhook (called by IVO when a sale happens on IVO)
        add_action( 'rest_api_init', array( $this, 'register_webhook_routes' ) );
    }
    
    /**
     * Check if WooCommerce is active
     */
    public function check_dependencies() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', function() {
                echo '<div class="error"><p><strong>IVO Marketplace</strong> requires WooCommerce to be installed and active.</p></div>';
            } );
            return false;
        }
        return true;
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        load_plugin_textdomain( 'ivo-marketplace', false, dirname( IVO_MARKETPLACE_BASENAME ) . '/languages' );
    }
    
    /**
     * Register callback endpoint
     */
    public function register_callback_endpoint() {
        add_rewrite_rule( '^ivo-callback/?$', 'index.php?ivo_callback=1', 'top' );
        add_filter( 'query_vars', function( $vars ) {
            $vars[] = 'ivo_callback';
            $vars[] = 'key';
            $vars[] = 'nonce';
            return $vars;
        } );
    }
    
    /**
     * Handle callback from IVO setup
     * 
     */
    public function handle_callback() {
        if ( ! get_query_var( 'ivo_callback' ) ) {
            return;
        }
        
        $api_key = isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';
        $nonce = isset( $_GET['nonce'] ) ? sanitize_text_field( $_GET['nonce'] ) : '';
        
        $success = false;
        $error = '';
        $selected_point_id = '';
        
        // Security: Verify the nonce
        $stored_data = get_option( self::OPTION_SETUP_NONCE, '' );
        $stored_nonce = '';
        $stored_time = 0;
        $stored_locale = '';
        
        if ( $stored_data ) {
            $parts = explode( '|', $stored_data );
            $stored_nonce = $parts[0] ?? '';
            $stored_time = (int) ( $parts[1] ?? 0 );
            $stored_locale = $parts[2] ?? '';
        }
        $text = $this->get_callback_text( $stored_locale );
        
        // Delete the nonce immediately (one-time use)
        delete_option( self::OPTION_SETUP_NONCE );
        
        // Validate security
        if ( empty( $nonce ) || empty( $stored_nonce ) ) {
            $error = $text['error_missing_token'];
        } elseif ( ! hash_equals( $stored_nonce, $nonce ) ) {
            $error = $text['error_token_mismatch'];
        } elseif ( time() - $stored_time > 600 ) { // 10 minutes expiry
            $error = $text['error_expired'];
        } elseif ( empty( $api_key ) ) {
            $error = $text['error_api_key'];
        } else {
            // Decode the API key decryptIvoKey()
            $decoded_key = $this->decrypt_ivo_key( $api_key );
            
            if ( $decoded_key ) {
                // Save API key
                update_option( self::OPTION_API_KEY, $decoded_key );
                update_option( self::OPTION_CONFIGURED, 1 );
                
                // Automatically select a merchant point only when the choice is unambiguous.
                $points = $this->fetch_merchant_points( $decoded_key );
                $points = $this->normalize_merchant_points( $points );
                $selected_point_id = '';
                if ( count( $points ) === 1 ) {
                    $selected_point_id = $points[0]['id'] ?? $points[0]['_id'] ?? '';
                    if ( $selected_point_id ) {
                        update_option( self::OPTION_MERCHANT_POINT_ID, $selected_point_id );
                    }
                } else {
                    delete_option( self::OPTION_MERCHANT_POINT_ID );
                }
                
                $success = true;
            } else {
                $error = $text['error_api_key_decrypt'];
            }
        }
        
        // Build admin URL
        $admin_link = admin_url( 'admin.php?page=ivo-marketplace' );
        $sync_data = array(
            'url' => ( $success && ! empty( $selected_point_id ) ) ? admin_url( 'admin-ajax.php' ) : '',
            'nonce' => ( $success && ! empty( $selected_point_id ) ) ? wp_create_nonce( 'ivo_marketplace_nonce' ) : '',
        );
        if ( $success && empty( $selected_point_id ) ) {
            $sync_data['status'] = $text['select_point'];
        }
        
        // Output standalone HTML page
        $this->output_callback_page( $success, $error, $admin_link, $sync_data, $text );
        exit;
    }
    
    /**
     * Decrypt IVO API key
     * 
     */
    private function decrypt_ivo_key( $encrypted_key ) {
        $encrypted_key = trim( $encrypted_key );
        
        // User Requirement: "The callback key is simply Base64 encoded"
        $decoded = base64_decode( $encrypted_key, true );
        
        // Validation: If valid UTF-8/ASCII string, use it.
        if ( $decoded !== false && ctype_print( $decoded ) ) {
            return $decoded;
        }
        
        // Fallback: return raw input
        return $encrypted_key;
    }
    
    /**
     * Output callback page
     * 
     */
    private function output_callback_page( $success, $error, $admin_link, $sync_data, $text ) {
        $title = $success ? $text['success_title'] : $text['failed_title'];
        $message = $success 
            ? $text['success_message']
            : $error;
        $icon_color = $success ? '#28a745' : '#dc3545';
        $icon = $success 
            ? '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $icon_color . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>'
            : '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="' . $icon_color . '" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';
        $sync_url = ! empty( $sync_data['url'] ) ? $sync_data['url'] : '';
        $sync_nonce = ! empty( $sync_data['nonce'] ) ? $sync_data['nonce'] : '';
        $sync_status = ! empty( $sync_data['status'] ) ? $sync_data['status'] : ( $success ? $text['syncing'] : '' );
        
        ?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( $text['lang'] ); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVO Marketplace - <?php echo esc_html( $title ); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #123cd1 0%, #ff3385 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px;
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .icon { margin-bottom: 24px; }
        .sync-status {
            color: #6c757d;
            font-size: 14px;
            line-height: 1.5;
            min-height: 22px;
            margin: -16px 0 28px;
        }
        .sync-status.success { color: #16813a; }
        .sync-status.error { color: #b42318; }
        h1 {
            color: #1a1a2e;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 32px;
        }
        .btn {
            display: inline-block;
            background: #123cd1;
            color: white;
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(18, 60, 209, 0.4);
        }
        .logo {
            margin-bottom: 32px;
            font-size: 28px;
            font-weight: 700;
            color: #123cd1;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">IVO Marketplace</div>
        <div class="icon"><?php echo $icon; ?></div>
        <h1><?php echo esc_html( $title ); ?></h1>
        <p><?php echo esc_html( $message ); ?></p>
        <div id="sync-status" class="sync-status"><?php echo esc_html( $sync_status ); ?></div>
        <a href="<?php echo esc_url( $admin_link ); ?>" class="btn"><?php echo esc_html( $text['admin_button'] ); ?></a>
    </div>
    <script>
        (function () {
            var syncUrl = <?php echo wp_json_encode( $sync_url ); ?>;
            var nonce = <?php echo wp_json_encode( $sync_nonce ); ?>;
            var status = document.getElementById('sync-status');
            if (!syncUrl || !nonce || !status) {
                if (status) status.textContent = '';
                return;
            }

            status.textContent = <?php echo wp_json_encode( $text['syncing'] ); ?>;
            var body = new URLSearchParams();
            body.append('action', 'ivo_force_sync');
            body.append('nonce', nonce);

            fetch(syncUrl, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            })
                .then(function (response) { return response.json(); })
                .then(function (data) {
                    if (data && data.success) {
                        status.className = 'sync-status success';
                        status.textContent = <?php echo wp_json_encode( $text['sync_success'] ); ?>;
                    } else {
                        status.className = 'sync-status error';
                        status.textContent = data && data.data && data.data.message ? data.data.message : <?php echo wp_json_encode( $text['sync_failed'] ); ?>;
                    }
                })
                .catch(function () {
                    status.className = 'sync-status error';
                    status.textContent = <?php echo wp_json_encode( $text['sync_failed'] ); ?>;
                });
        })();
    </script>
</body>
</html>
        <?php
    }

    /**
     * Callback page translations. This page is rendered outside wp-admin, so keep
     * the setup return screen tied to the locale captured when setup started.
     */
    private function get_callback_text( $locale = '' ) {
        $locale = strtolower( $locale ?: get_locale() );
        if ( strpos( $locale, 'ro' ) === 0 ) {
            return array(
                'lang' => 'ro',
                'success_title' => 'Configurare reusita',
                'failed_title' => 'Configurare esuata',
                'success_message' => 'Cheia API IVO Marketplace a fost configurata cu succes.',
                'admin_button' => 'Mergi la setari',
                'syncing' => 'Sincronizarea produselor a pornit...',
                'sync_success' => 'Sincronizarea produselor a fost pornita cu succes.',
                'sync_failed' => 'Sincronizarea nu a putut fi pornita automat.',
                'select_point' => 'Conexiunea este configurata. Selectati punctul de vanzare in setari pentru a porni sincronizarea.',
                'error_missing_token' => 'Cerere invalida: lipseste tokenul de securitate.',
                'error_token_mismatch' => 'Cerere invalida: tokenul de securitate nu corespunde.',
                'error_expired' => 'Cererea a expirat. Porniti din nou procesul de configurare.',
                'error_api_key' => 'Nu a fost primita cheia API de la IVO.',
                'error_api_key_decrypt' => 'Cheia API primita de la IVO nu a putut fi procesata.',
            );
        }
        if ( strpos( $locale, 'ru' ) === 0 ) {
            return array(
                'lang' => 'ru',
                'success_title' => 'Настройка завершена',
                'failed_title' => 'Ошибка настройки',
                'success_message' => 'API-ключ IVO Marketplace успешно настроен.',
                'admin_button' => 'Перейти к настройкам',
                'syncing' => 'Синхронизация товаров запущена...',
                'sync_success' => 'Синхронизация товаров успешно запущена.',
                'sync_failed' => 'Не удалось запустить синхронизацию автоматически.',
                'select_point' => 'Подключение настроено. Выберите торговую точку в настройках, чтобы запустить синхронизацию.',
                'error_missing_token' => 'Некорректный запрос: отсутствует токен безопасности.',
                'error_token_mismatch' => 'Некорректный запрос: токен безопасности не совпадает.',
                'error_expired' => 'Срок действия запроса истек. Запустите настройку заново.',
                'error_api_key' => 'API-ключ от IVO не получен.',
                'error_api_key_decrypt' => 'Не удалось обработать API-ключ от IVO.',
            );
        }
        return array(
            'lang' => 'en',
            'success_title' => 'Configuration Successful',
            'failed_title' => 'Configuration Failed',
            'success_message' => 'Your IVO Marketplace API key has been successfully configured.',
            'admin_button' => 'Go to Settings',
            'syncing' => 'Product synchronization is starting...',
            'sync_success' => 'Product synchronization started successfully.',
            'sync_failed' => 'Synchronization could not be started automatically.',
            'select_point' => 'Connection is configured. Select the merchant point in settings to start synchronization.',
            'error_missing_token' => 'Invalid request: missing security token.',
            'error_token_mismatch' => 'Invalid request: security token mismatch.',
            'error_expired' => 'Request expired. Please start the setup process again.',
            'error_api_key' => 'No API key received from IVO.',
            'error_api_key_decrypt' => 'Failed to process API key from IVO.',
        );
    }
    
    /**
     * Add admin menu under Marketing
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce-marketing',
            __( 'IVO Marketplace', 'ivo-marketplace' ),
            __( 'IVO Marketplace', 'ivo-marketplace' ),
            'manage_woocommerce',
            'ivo-marketplace',
            array( $this, 'render_settings_page' ),
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting( 'ivo_marketplace_settings', self::OPTION_MERCHANT_POINT_ID );
        register_setting( 'ivo_marketplace_settings', self::OPTION_PRICE_MODIFIER, array(
            'type' => 'number',
            'sanitize_callback' => array( $this, 'sanitize_price_modifier' ),
            'default' => 0,
        ) );
        register_setting( 'ivo_marketplace_settings', self::OPTION_UPDATE_STOCK, array(
            'type' => 'string',
            'default' => '1',
        ) );
    }

    /**
     * Sanitize price modifier option
     */
    public function sanitize_price_modifier( $value ) {
        if ( $value === '' || $value === null ) {
            return 0;
        }
        return (float) $value;
    }
    
    /**
     * Admin notices CheckConfig Observer
     */
    public function admin_notices() {
        // Only show on non-IVO pages
        $screen = get_current_screen();
        if ( $screen && $screen->id === 'toplevel_page_ivo-marketplace' ) {
            return;
        }
        
        // Check if configured
        if ( ! $this->is_configured() ) {
            $configure_url = admin_url( 'admin.php?page=ivo-marketplace' );
            ?>
            <div class="notice notice-warning">
                <p>
                    <strong><?php esc_html_e( 'IVO Marketplace', 'ivo-marketplace' ); ?></strong>: 
                    <?php esc_html_e( 'IVO Marketplace is installed but not configured. Please configure it to start selling on IVO.', 'ivo-marketplace' ); ?>
                    <a href="<?php echo esc_url( $configure_url ); ?>"><?php esc_html_e( 'Configure', 'ivo-marketplace' ); ?></a>
                </p>
            </div>
            <?php
        }
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_scripts( $hook ) {
        if ( $hook === 'marketing_page_ivo-marketplace' || $hook === 'toplevel_page_ivo-marketplace' || $hook === 'post.php' || $hook === 'post-new.php' ) {
            wp_enqueue_style( 'ivo-marketplace-admin', IVO_MARKETPLACE_URL . 'assets/css/admin.css', array(), IVO_MARKETPLACE_VERSION );
            wp_enqueue_script( 'ivo-marketplace-admin', IVO_MARKETPLACE_URL . 'assets/js/admin.js', array( 'jquery' ), IVO_MARKETPLACE_VERSION, true );
            wp_localize_script( 'ivo-marketplace-admin', 'ivo_ajax', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'ivo_marketplace_nonce' ),
                'strings' => array(
                    'syncing' => __( 'Syncing...', 'ivo-marketplace' ),
                    'force_sync' => __( 'Force Sync with IVO', 'ivo-marketplace' ),
                    'loading' => __( 'Loading...', 'ivo-marketplace' ),
                    'connection_error' => __( 'Connection error.', 'ivo-marketplace' ),
                    'status' => __( 'IVO Status', 'ivo-marketplace' ),
                    'active' => __( 'Active', 'ivo-marketplace' ),
                    'inactive' => __( 'Inactive', 'ivo-marketplace' ),
                    'pending' => __( 'Pending', 'ivo-marketplace' ),
                    'not_synced' => __( 'Not Synced', 'ivo-marketplace' ),
                    'error' => __( 'Error', 'ivo-marketplace' ),
                    'product_visible' => __( 'The product is visible and purchasable.', 'ivo-marketplace' ),
                    'view_product' => __( 'View Product', 'ivo-marketplace' ),
                    // Message descriptions/Magento
                    'not_imported' => __( 'Product has not been synced to IVO yet.', 'ivo-marketplace' ),
                    'queued' => __( 'Product is queued for processing.', 'ivo-marketplace' ),
                    'processing' => __( 'Product is currently being processed.', 'ivo-marketplace' ),
                    'pending_approval' => __( 'Product created but still pending approval.', 'ivo-marketplace' ),
                    'import_error' => __( 'An error occurred during import.', 'ivo-marketplace' ),
                    'skipped_no_match' => __( 'The product details are too generic to accurately identify the specific item being sold.', 'ivo-marketplace' ),
                    'unauthorized_category' => __( 'Merchant not authorized for product category.', 'ivo-marketplace' ),
                    'offer_deleted' => __( 'The offer was deleted from the marketplace.', 'ivo-marketplace' ),
                    'offer_not_found' => __( 'Product not found on marketplace.', 'ivo-marketplace' ),
                    'unknown_status' => __( 'Unknown status', 'ivo-marketplace' ),
                    'refreshing_status' => __( 'Refreshing status...', 'ivo-marketplace' ),
                    'too_generic' => __( 'The product details are too generic to accurately identify the specific item being sold.', 'ivo-marketplace' ),
                ),
            ) );
        }
    }
    
    /**
     * Add settings link to plugins page
     */
    public function add_settings_link( $links ) {
        $settings_link = '<a href="' . admin_url( 'admin.php?page=ivo-marketplace' ) . '">' . __( 'Settings', 'ivo-marketplace' ) . '</a>';
        array_unshift( $links, $settings_link );
        return $links;
    }
    
    /**
     * Render settings page
     * 
     */
    public function render_settings_page() {
        $configured = $this->is_configured();
        $api_key = $this->get_api_key();
        $api_key_masked = $api_key ? substr( $api_key, 0, 8 ) . '••••••••••••••••' : '';
        $merchant_point_id = get_option( self::OPTION_MERCHANT_POINT_ID, '' );
        $update_stock = get_option( self::OPTION_UPDATE_STOCK, '1' );
        $merchant_points = $configured ? $this->fetch_merchant_points() : array();
        $configure_url = $this->get_setup_url();
        
        // Handle success/error messages
        $success = '';
        $error = '';
        
        if ( isset( $_GET['settings-updated'] ) ) {
            $success = __( 'Success: You have modified IVO Marketplace settings!', 'ivo-marketplace' );
        }
        
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'IVO Marketplace', 'ivo-marketplace' ); ?></h1>
            
            <?php if ( $success ) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html( $success ); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ( $error ) : ?>
            <div class="notice notice-error is-dismissible">
                <p><?php echo esc_html( $error ); ?></p>
            </div>
            <?php endif; ?>
            
            <section class="ivo-card">
                <div class="ivo-card__head">
                    <div class="ivo-card__icon">⚙</div>
                    <strong><?php echo esc_html( $this->translate( 'Edit IVO Marketplace' ) ); ?></strong>
                    
                    <?php if ( ! $configured ) : ?>
                        <div class="ivo-card__status">
                            <span class="ivo-card__status-dot"></span>
                            <?php echo esc_html( $this->translate( 'Not connected' ) ); ?>
                        </div>
                    <?php else : ?>
                        <div class="ivo-card__status ivo-card__status--connected">
                            <span class="ivo-card__status-dot ivo-card__status-dot--connected"></span>
                            <?php echo esc_html( $this->translate( 'Connected' ) ); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="ivo-card__body">
                    <div>
                        <div class="ivo-card__logo"><img src="https://static.ivo.md/favicon_white.png" alt="IVO" style="width: 42px; height: 42px; object-fit: contain; display: block;" /></div>
                        <p class="ivo-card__eyebrow"><?php echo esc_html( $this->translate( 'WordPress bridge' ) ); ?></p>
                        
                        <?php if ( ! $configured ) : ?>
                            <h2><?php echo esc_html( $this->translate( 'Connect your store to IVO.md.' ) ); ?></h2>
                            <p><?php echo esc_html( $this->translate( 'Authorize your marketplace account, choose what gets synced, then let WooCommerce and IVO work together.' ) ); ?></p>
                            
                            <div class="ivo-card__actions">
                                <a href="<?php echo esc_url( $configure_url ); ?>" class="ivo-card__button">🔌 <?php echo esc_html( $this->translate( 'Configure connection' ) ); ?></a>
                                <a href="<?php echo esc_url( $this->get_help_guide_url() ); ?>" target="_blank" class="ivo-card__link"><?php echo esc_html( $this->translate( 'View setup guide' ) ); ?></a>
                            </div>
                        <?php else : ?>
                            <h2><?php echo esc_html( $this->translate( 'Settings' ) ); ?></h2>
                            <form method="post" action="options.php" style="margin-top: 24px;">
                                <?php settings_fields( 'ivo_marketplace_settings' ); ?>
                                
                                <div class="ivo-form-group">
                                    <label><?php echo esc_html( $this->translate( 'API Key' ) ); ?></label>
                                    <input type="text" value="<?php echo esc_attr( $api_key_masked ); ?>" class="ivo-form-input" readonly disabled />
                                </div>
                                
                                <div class="ivo-form-group">
                                    <label><?php echo esc_html( $this->translate( 'Merchant Point' ) ); ?></label>
                                    <select name="<?php echo esc_attr( self::OPTION_MERCHANT_POINT_ID ); ?>" class="ivo-form-select">
                                        <option value=""><?php echo esc_html( $this->translate( '--- Select ---' ) ); ?></option>
                                        <?php foreach ( $merchant_points as $point ) : 
                                            $point_id = $point['id'] ?? $point['_id'] ?? '';
                                            ?>
                                            <option value="<?php echo esc_attr( $point_id ); ?>" <?php selected( $merchant_point_id, $point_id ); ?>>
                                                <?php echo esc_html( $point['name'] ); ?>
                                                <?php if ( ! empty( $point['address'] ) ) : ?>
                                                    - <?php echo esc_html( $point['address'] ); ?>
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="ivo-form-group">
                                    <label><?php echo esc_html( $this->translate( 'Price Modifier (%)' ) ); ?></label>
                                    <?php 
                                        $mod_val = get_option( self::OPTION_PRICE_MODIFIER, '0' ); 
                                        if ( $mod_val === '' ) $mod_val = '0';
                                    ?>
                                    <input type="number" step="0.01" name="<?php echo esc_attr( self::OPTION_PRICE_MODIFIER ); ?>" value="<?php echo esc_attr( $mod_val ); ?>" class="ivo-form-input" />
                                    <p class="description"><?php esc_html_e( 'Automatically adjust product prices sent to IVO (e.g., enter 10 to increase by 10%, or -5 to decrease by 5%). Enter 0 for no change.', 'ivo-marketplace' ); ?></p>
                                </div>
                                
                                <div class="ivo-form-group" style="display: flex; align-items: flex-start; gap: 10px;">
                                    <input type="hidden" name="<?php echo esc_attr( self::OPTION_UPDATE_STOCK ); ?>" value="0" />
                                    <?php 
                                        $update_stock_val = get_option( self::OPTION_UPDATE_STOCK, '1' ); 
                                    ?>
                                    <input type="checkbox" id="ivo_update_stock" name="<?php echo esc_attr( self::OPTION_UPDATE_STOCK ); ?>" value="1" <?php checked( $update_stock_val, '1' ); ?> style="margin-top: 4px; width: 16px; height: 16px; accent-color: #8a24d6;" />
                                    <div>
                                        <label for="ivo_update_stock" style="margin-bottom: 2px; cursor: pointer;"><?php echo esc_html( $this->translate( 'Update stock on sale' ) ); ?></label>
                                        <p class="description" style="margin-top: 0;"><?php echo esc_html( $this->translate( 'Automatically update your WooCommerce stock when a sale occurs on IVO.' ) ); ?></p>
                                    </div>
                                </div>
                                
                                <div class="ivo-card__actions" style="margin-top: 26px;">
                                    <button type="submit" class="ivo-card__button"><?php echo esc_html( $this->translate( 'Save settings' ) ); ?></button>
                                    <a href="<?php echo esc_url( $configure_url ); ?>" class="ivo-card__button-secondary"><?php echo esc_html( $this->translate( 'Reconfigure' ) ); ?></a>
                                    <button type="button" id="btn-force-sync" class="ivo-card__button-secondary">
                                        🔄 <?php echo esc_html( $this->translate( 'Force Sync' ) ); ?>
                                    </button>
                                    <span id="sync-status" class="ivo-sync-status"></span>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ivo-card__setup">
                        <div class="ivo-card__setup-box">
                            <div class="ivo-card__step">
                                <div class="ivo-card__step-number">1</div>
                                <div>
                                    <strong><?php echo esc_html( $this->translate( 'Account access' ) ); ?></strong>
                                    <span><?php echo esc_html( $this->translate( 'Add your IVO API key and merchant identifier.' ) ); ?></span>
                                </div>
                                <?php if ( $configured ) : ?>
                                    <div class="ivo-card__tag ivo-card__tag--success"><?php echo esc_html( $this->translate( 'Success' ) ); ?></div>
                                <?php else : ?>
                                    <div class="ivo-card__tag ivo-card__tag--active"><?php echo esc_html( $this->translate( 'Required' ) ); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="ivo-card__step">
                                <div class="ivo-card__step-number">2</div>
                                <div>
                                    <strong><?php echo esc_html( $this->translate( 'Product sync' ) ); ?></strong>
                                    <span><?php echo esc_html( $this->translate( 'Map categories, prices, stock, and images.' ) ); ?></span>
                                </div>
                                <?php if ( $configured ) : ?>
                                    <div class="ivo-card__tag ivo-card__tag--success"><?php echo esc_html( $this->translate( 'Active' ) ); ?></div>
                                <?php else : ?>
                                    <div class="ivo-card__tag"><?php echo esc_html( $this->translate( 'Next' ) ); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="ivo-card__step">
                                <div class="ivo-card__step-number">3</div>
                                <div>
                                    <strong><?php echo esc_html( $this->translate( 'Update stock' ) ); ?></strong>
                                    <span><?php echo esc_html( $this->translate( 'Automatically sync stock between your store and IVO.' ) ); ?></span>
                                </div>
                                <?php if ( $configured && $update_stock === '1' ) : ?>
                                    <div class="ivo-card__tag ivo-card__tag--success"><?php echo esc_html( $this->translate( 'Active' ) ); ?></div>
                                <?php else : ?>
                                    <div class="ivo-card__tag"><?php echo esc_html( $this->translate( $configured ? 'Inactive' : 'Ready' ) ); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php
    }

    /**
     * Get help guide URL based on current WordPress locale
     */
    public function get_help_guide_url() {
        $locale = get_locale();
        if ( strpos( $locale, 'ru' ) === 0 ) {
            return 'https://www.preview.ivo.md/ru/help/merchant-integration/woocommerce';
        } elseif ( strpos( $locale, 'en' ) === 0 ) {
            return 'https://www.preview.ivo.md/en/help/merchant-integration/woocommerce';
        } else {
            return 'https://www.preview.ivo.md/help/merchant-integration/woocommerce';
        }
    }

    /**
     * Helper to translate custom admin strings
     */
    private function translate( $text ) {
        $locale = get_locale();
        $is_ro = strpos( $locale, 'ro' ) === 0;
        $is_ru = strpos( $locale, 'ru' ) === 0;

        $dictionary = array(
            'Edit IVO Marketplace' => array(
                'ro' => 'Editare IVO Marketplace',
                'ru' => 'Редактировать IVO Marketplace',
            ),
            'Not connected' => array(
                'ro' => 'Neconectat',
                'ru' => 'Не подключено',
            ),
            'Connected' => array(
                'ro' => 'Conectat',
                'ru' => 'Подключено',
            ),
            'Connect your store to IVO.md.' => array(
                'ro' => 'Conectează-ți magazinul la IVO.md.',
                'ru' => 'Подключите свой магазин к IVO.md.',
            ),
            'Authorize your marketplace account, choose what gets synced, then let WooCommerce and IVO work together.' => array(
                'ro' => 'Autorizează contul de marketplace, alege ce dorești să sincronizezi, apoi lasă WooCommerce și IVO să lucreze împreună.',
                'ru' => 'Авторизуйте свой аккаунт на маркетплейсе, выберите, что синхронизировать, и позвольте WooCommerce и IVO работать вместе.',
            ),
            'Configure connection' => array(
                'ro' => 'Configurează conexiunea',
                'ru' => 'Настроить подключение',
            ),
            'View setup guide' => array(
                'ro' => 'Vezi ghidul de configurare',
                'ru' => 'Посмотреть руководство по настройке',
            ),
            'Account access' => array(
                'ro' => 'Acces cont',
                'ru' => 'Доступ к аккаунту',
            ),
            'Add your IVO API key and merchant identifier.' => array(
                'ro' => 'Adaugă cheia API IVO și identificatorul de comerciant.',
                'ru' => 'Добавьте API-ключ IVO и идентификатор продавца.',
            ),
            'Product sync' => array(
                'ro' => 'Sincronizare produse',
                'ru' => 'Синхронизация товаров',
            ),
            'Map categories, prices, stock, and images.' => array(
                'ro' => 'Asociază categoriile, prețurile, stocurile și imaginile.',
                'ru' => 'Сопоставьте категории, цены, запасы и изображения.',
            ),
            'Update stock' => array(
                'ro' => 'Actualizare stoc',
                'ru' => 'Обновление остатков',
            ),
            'Automatically sync stock between your store and IVO.' => array(
                'ro' => 'Sincronizează automat stocurile între magazin și IVO.',
                'ru' => 'Автоматически синхронизируйте остатки между магазином и IVO.',
            ),
            'Success' => array(
                'ro' => 'Succes',
                'ru' => 'Успех',
            ),
            'Required' => array(
                'ro' => 'Necesar',
                'ru' => 'Обязательно',
            ),
            'Next' => array(
                'ro' => 'Următorul',
                'ru' => 'Далее',
            ),
            'Ready' => array(
                'ro' => 'Pregătit',
                'ru' => 'Готово',
            ),
            'Active' => array(
                'ro' => 'Activ',
                'ru' => 'Активен',
            ),
            'Inactive' => array(
                'ro' => 'Inactiv',
                'ru' => 'Неактивен',
            ),
            'Settings' => array(
                'ro' => 'Setări',
                'ru' => 'Настройки',
            ),
            'Save settings' => array(
                'ro' => 'Salvează setările',
                'ru' => 'Сохранить настройки',
            ),
            'Reconfigure' => array(
                'ro' => 'Reconfigurează',
                'ru' => 'Перенастроить',
            ),
            'Force Sync' => array(
                'ro' => 'Sincronizare forțată',
                'ru' => 'Принудительная синхронизация',
            ),
            'WordPress bridge' => array(
                'ro' => 'Conexiune WordPress',
                'ru' => 'Мост WordPress',
            ),
            'Update stock on sale' => array(
                'ro' => 'Actualizează stocul la vânzare',
                'ru' => 'Обновлять наличие при продаже',
            ),
            'Automatically update your WooCommerce stock when a sale occurs on IVO.' => array(
                'ro' => 'Actualizează automat stocul WooCommerce atunci când are loc o vânzare pe IVO.',
                'ru' => 'Автоматически обновлять наличие в WooCommerce при продаже на IVO.',
            ),
        );

        if ( isset( $dictionary[$text] ) ) {
            if ( $is_ro && isset( $dictionary[$text]['ro'] ) ) {
                return $dictionary[$text]['ro'];
            }
            if ( $is_ru && isset( $dictionary[$text]['ru'] ) ) {
                return $dictionary[$text]['ru'];
            }
        }

        return $text;
    }
    
    /**
     * Add product metabox
     * 
     */
    public function add_product_metabox() {
        if ( ! $this->is_configured() ) {
            return;
        }
        
        add_meta_box(
            'ivo-marketplace-status',
            __( 'IVO Marketplace', 'ivo-marketplace' ),
            array( $this, 'render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }
    
    /**
     * Render product metabox
     * 
     */
    public function render_product_metabox( $post ) {
        $product_id = $post->ID;
        $product = wc_get_product( $product_id );
        $is_variable = $product && $product->is_type( 'variable' );
        $variations = array();
        
        if ( $is_variable ) {
            foreach ( $product->get_available_variations() as $v ) {
                $variation = wc_get_product( $v['variation_id'] );
                if ( $variation ) {
                    $attrs = array();
                    foreach ( $variation->get_variation_attributes() as $val ) {
                        if ( $val ) $attrs[] = $val;
                    }
                    $variations[] = array(
                        'id' => $v['variation_id'],
                        'name' => implode( ', ', $attrs ),
                        'sku' => $variation->get_sku() ?: (string) $v['variation_id'],
                    );
                }
            }
        }
        ?>
        <div id="ivo-status-container">
            <?php if ( $is_variable && ! empty( $variations ) ) : ?>
                <!-- Variable Product: Show each variation -->
                <p style="margin-bottom: 15px; color: #666;">
                    <span class="dashicons dashicons-info"></span>
                    <?php printf( esc_html__( 'This variable product has %d variations. Each variation is synced separately to IVO.', 'ivo-marketplace' ), count( $variations ) ); ?>
                </p>
                <div id="ivo-variations-list" style="max-height: 400px; overflow-y: auto;">
                    <?php foreach ( $variations as $var ) : ?>
                        <div class="ivo-variation-item" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; background: #f9f9f9;">
                            <strong><?php echo esc_html( $var['name'] ); ?></strong>
                            <span style="color: #666; font-size: 12px;">(SKU: <?php echo esc_html( $var['sku'] ); ?>)</span>
                            <div id="ivo-variation-status-<?php echo esc_attr( $var['id'] ); ?>" style="margin-top: 8px;">
                                <span class="spinner is-active" style="float: none; margin: 0;"></span>
                                <span style="color: #666;"><?php esc_html_e( 'Loading...', 'ivo-marketplace' ); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <!-- Simple Product: Show single status -->
                <div id="ivo-loading" class="ivo-loading">
                    <span class="spinner is-active"></span>
                    <p><?php esc_html_e( 'Loading...', 'ivo-marketplace' ); ?></p>
                </div>
                <div id="ivo-status-content" style="display:none;">
                    <h4 id="ivo-status-header"></h4>
                    <p id="ivo-status-description"></p>
                    <div id="ivo-view-btn-container" style="display:none; margin-top:10px;">
                        <a id="ivo-product-url" href="#" target="_blank" class="button button-primary" style="background-color: #eb5202; border-color: #eb5202;">
                            <?php esc_html_e( 'View Product', 'ivo-marketplace' ); ?>
                        </a>
                    </div>
                </div>
                <div id="ivo-error" class="notice notice-error" style="display:none; margin:0;"></div>
            <?php endif; ?>
            
            <hr style="margin: 15px 0;">
            <button type="button" id="btn-ivo-sync" class="button" data-product-id="<?php echo esc_attr( $product_id ); ?>">
                <span class="dashicons dashicons-update"></span>
                <?php esc_html_e( 'Force Sync with IVO', 'ivo-marketplace' ); ?>
            </button>
            <span id="ivo-sync-status" style="display:block; margin-top:5px;"></span>
        </div>
        <script>
        jQuery(document).ready(function($) {
            <?php if ( $is_variable && ! empty( $variations ) ) : ?>
                // Load status for each variation
                var variations = <?php echo json_encode( $variations ); ?>;
                variations.forEach(function(v) {
                    loadVariationStatus(v.id, v.name);
                });
            <?php else : ?>
                loadIvoStatus(<?php echo esc_js( $product_id ); ?>);
            <?php endif; ?>
        });
        
        function loadVariationStatus(variationId, variationName) {
            var container = jQuery('#ivo-variation-status-' + variationId);
            jQuery.ajax({
                url: ivo_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'ivo_get_product_status',
                    nonce: ivo_ajax.nonce,
                    product_id: variationId
                },
                success: function(response) {
                    if (response.success && response.data.status) {
                        var status = response.data.status;
                        var statusClass = status === 'active' ? 'color: green;' : (status === 'pending' ? 'color: orange;' : 'color: #666;');
                        var html = '<span style="' + statusClass + ' font-weight: bold;">' + status.toUpperCase() + '</span>';
                        if (response.data.url) {
                            html += ' <a href="' + response.data.url + '" target="_blank" style="margin-left: 10px;">View on IVO</a>';
                        }
                        container.html(html);
                    } else {
                        container.html('<span style="color: #999;">' + ivo_ajax.strings.not_synced + '</span>');
                    }
                },
                error: function() {
                    container.html('<span style="color: red;">Error</span>');
                }
            });
        }
        </script>
        <?php
    }
    
    /**
     * AJAX: Force sync all products
     * 
     */
    public function ajax_force_sync() {
        check_ajax_referer( 'ivo_marketplace_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Warning: You do not have permission to modify IVO Marketplace!', 'ivo-marketplace' ) ) );
        }
        
        try {
            $success = $this->sync_all_products();
        } catch ( \Throwable $e ) {
            error_log( 'IVO Marketplace Force Sync Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            wp_send_json_error( array( 'message' => sprintf( __( 'Force sync failed: %s', 'ivo-marketplace' ), $e->getMessage() ) ) );
        }
        
        if ( ! $success ) {
            // EXACT message from Magento: "Unable to fetch Merchant Point ID. Please check API Key configuration."
            wp_send_json_error( array( 'message' => __( 'Unable to fetch Merchant Point ID. Please check API Key configuration.', 'ivo-marketplace' ) ) );
        }
        
        // EXACT message from Magento: "Products synchronization started successfully."
        wp_send_json_success( array( 'message' => __( 'Products synchronization started successfully.', 'ivo-marketplace' ) ) );
    }

    /**
     * Sync all products to IVO
     */
    public function sync_all_products() {
        $merchant_point_id = $this->get_merchant_point_id();

        if ( ! $merchant_point_id ) {
            return false;
        }

        // Get all products
        $products = wc_get_products( array(
            'limit' => -1,
            'status' => 'publish',
        ) );

        // Get currency
        $currency = get_woocommerce_currency();

        // Prepare products for sync (max 100 per batch)
        $products_payload = array();
        $api_key = $this->get_api_key();

        // A full sync enumerates the complete catalog, so it can also tell
        // IVO what no longer exists: every batch carries the same run id, and
        // complete-run afterwards zeroes everything the run did not mention.
        $run_id = 'wc_' . time() . '_' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 12 );
        $all_batches_ok = true;
        $sent_any = false;

        foreach ( $products as $product ) {
            // Use helper to handle both simple and variable products
            $product_payloads = $this->prepare_product_payloads( $product, $merchant_point_id, $currency );

            foreach ( $product_payloads as $payload ) {
                $products_payload[] = $payload;

                // Batch sync at 100 products
                if ( count( $products_payload ) >= 100 ) {
                    $result = $this->sync_products( $products_payload, $api_key, 'async', $run_id );
                    $sent_any = true;
                    if ( $result['code'] < 200 || $result['code'] >= 300 ) {
                        $all_batches_ok = false;
                    }
                    $products_payload = array();
                }
            }
        }

        // Sync remaining products
        if ( ! empty( $products_payload ) ) {
            $result = $this->sync_products( $products_payload, $api_key, 'async', $run_id );
            $sent_any = true;
            if ( $result['code'] < 200 || $result['code'] >= 300 ) {
                $all_batches_ok = false;
            }
        }

        // Only a run that delivered every batch may declare missing products
        // gone; after a partial run, zeroing would hit products that merely
        // failed to arrive.
        if ( $sent_any && $all_batches_ok ) {
            $this->complete_sync_run( $run_id, $api_key );
        }

        return true;
    }

    /**
     * Close a full-sync run: products IVO knows from this store that were NOT
     * part of the run no longer exist here, so their offers go out of stock.
     */
    public function complete_sync_run( $run_id, $api_key = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }

        if ( ! $api_key || ! $run_id ) {
            return array( 'code' => 0, 'response' => null );
        }

        $payload = array(
            'import_name' => 'api_sync_import_woocommerce',
            'integration_run_id' => $run_id,
        );

        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, IVO_API_BASE_URL . '/v1/merchant-api/product/complete-run' );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
            'Content-Type: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $payload ) );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 60 );

        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );

        return array( 'code' => $http_code, 'response' => json_decode( $response, true ) );
    }

    /**
     * Trigger product updates when price modifier changes
     */
    public function on_price_modifier_update( $old_value, $value, $option ) {
        if ( (float) $old_value !== (float) $value ) {
            $this->sync_all_products();
        }
    }
    
    /**
     * AJAX: Get product status
     * 
     */
    public function ajax_get_product_status() {
        check_ajax_referer( 'ivo_marketplace_nonce', 'nonce' );
        
        $product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
        
        if ( ! $product_id ) {
            wp_send_json_error( array( 'message' => 'Product ID required' ) );
        }
        
        $api_key = $this->get_api_key();
        
        if ( ! $api_key ) {
            wp_send_json_error( array( 'message' => __( 'Not configured.', 'ivo-marketplace' ) ) );
        }
        
        $product = wc_get_product( $product_id );
        
        if ( ! $product ) {
            wp_send_json_error( array( 'message' => 'Product not found' ) );
        }
        
        $sku = $product->get_sku() ?: (string) $product_id;
        $ivo_data = $this->get_product_ivo_info( $sku, $api_key );
        
        // API response format:
        // Success: { status: "success", product: {...}, offer: {...} }
        // Error: { status: "error", message: "code" }
        if ( $ivo_data && isset( $ivo_data['status'] ) && $ivo_data['status'] === 'success' && isset( $ivo_data['product'] ) ) {
            wp_send_json_success( array(
                'status' => 'success',
                'name' => $ivo_data['product']['name'] ?? array(),
                'urls' => $ivo_data['product']['urls'] ?? array(),
                'url' => $ivo_data['product']['url'] ?? '',
            ) );
        } elseif ( $ivo_data && isset( $ivo_data['status'] ) && $ivo_data['status'] === 'error' && isset( $ivo_data['message'] ) ) {
            wp_send_json_success( array(
                'status' => 'error',
                'message' => $ivo_data['message'],
            ) );
        } else {
            wp_send_json_success( array(
                'status' => 'error',
                'message' => 'not_imported',
            ) );
        }
    }
    
    /**
     * AJAX: Sync single product
     * 
     */
    public function ajax_sync_product() {
        check_ajax_referer( 'ivo_marketplace_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Warning: You do not have permission to modify IVO Marketplace!', 'ivo-marketplace' ) ) );
        }
        
        $product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
        
        if ( ! $product_id ) {
            wp_send_json_error( array( 'message' => 'Product ID required' ) );
        }
        
        $api_key = $this->get_api_key();
        $merchant_point_id = $this->get_merchant_point_id();
        
        if ( ! $api_key || ! $merchant_point_id ) {
            wp_send_json_error( array( 'message' => __( 'Unable to fetch Merchant Point ID. Please check API Key configuration.', 'ivo-marketplace' ) ) );
        }
        
        $product = wc_get_product( $product_id );
        
        if ( ! $product ) {
            wp_send_json_error( array( 'message' => 'Product not found' ) );
        }
        
        $currency = get_woocommerce_currency();
        
        // Use helper to handle both simple and variable products
        $products_data = $this->prepare_product_payloads( $product, $merchant_point_id, $currency );
        
        if ( empty( $products_data ) ) {
            wp_send_json_error( array( 'message' => __( 'Product cannot be synced. Please ensure it has a valid price.', 'ivo-marketplace' ) ) );
        }
        
        $result = $this->sync_products( $products_data, $api_key );
        
        if ( $result['code'] >= 200 && $result['code'] < 300 ) {
            wp_send_json_success( array( 'message' => __( 'Product synced successfully!', 'ivo-marketplace' ) ) );
        } else {
            wp_send_json_error( array( 'message' => sprintf( __( 'Sync failed. API Code: %s', 'ivo-marketplace' ), $result['code'] ) ) );
        }
    }
    
    /**
     * On product save
     */
    public function on_product_save( $product_id, $product = null ) {
        // Check if configured
        if ( ! $this->is_configured() ) {
            return;
        }
        
        $api_key = $this->get_api_key();
        $merchant_point_id = $this->get_merchant_point_id();
        
        if ( ! $api_key || ! $merchant_point_id ) {
            return;
        }
        
        if ( ! $product ) {
            $product = wc_get_product( $product_id );
        }
        
        if ( ! $product ) {
            return;
        }
        
        $currency = get_woocommerce_currency();
        
        // Use helper to handle both simple and variable products
        $products_data = $this->prepare_product_payloads( $product, $merchant_point_id, $currency );
        
        $this->sync_products( $products_data, $api_key );
    }
    
    /**
     * A product being trashed or permanently deleted disappears from every
     * future sync, so nothing would ever zero its IVO offer. Push the zero
     * now, while the product (and its SKUs) can still be read.
     */
    public function on_product_remove( $post_id ) {
        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'product', 'product_variation' ), true ) ) {
            return;
        }

        $this->push_out_of_stock( $post_id );
    }

    /**
     * Unpublishing (draft/pending/private) has the same effect as deleting:
     * sync_all_products() only reads published products, and no save event
     * carries the change to IVO. Trash is handled by on_product_remove.
     */
    public function on_product_status_change( $new_status, $old_status, $post ) {
        if ( ! $post || 'product' !== $post->post_type ) {
            return;
        }

        if ( 'publish' !== $old_status || 'publish' === $new_status || 'trash' === $new_status ) {
            return;
        }

        $this->push_out_of_stock( $post->ID );
    }

    /**
     * Send availability 0 for a product (every variation of a variable one)
     * as an availability-only sync: the server only updates rows/offers it
     * already knows, so this can never create products.
     */
    public function push_out_of_stock( $product_id ) {
        if ( ! $this->is_configured() ) {
            return;
        }

        $api_key = $this->get_api_key();
        $merchant_point_id = $this->get_merchant_point_id();

        if ( ! $api_key || ! $merchant_point_id ) {
            return;
        }

        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            return;
        }

        $internal_ids = array();
        if ( $product->is_type( 'variable' ) ) {
            foreach ( $product->get_children() as $child_id ) {
                $child = wc_get_product( $child_id );
                if ( $child ) {
                    $internal_ids[] = $child->get_sku() ?: (string) $child->get_id();
                }
            }
        } else {
            $internal_ids[] = $product->get_sku() ?: (string) $product->get_id();
        }

        $products_payload = array();
        foreach ( array_unique( array_filter( $internal_ids ) ) as $internal_id ) {
            $products_payload[] = array(
                'availability_only' => true,
                'availability' => 0,
                'merchant_internal_id' => $internal_id,
                'merchant_point_id' => $merchant_point_id,
            );
        }

        if ( ! empty( $products_payload ) ) {
            $this->sync_products( $products_payload, $api_key );
        }
    }

    /**
     * On order complete
     */
    public function on_order_complete( $order_id ) {
        if ( ! $this->is_configured() ) {
            return;
        }
        
        $api_key = $this->get_api_key();
        $merchant_point_id = $this->get_merchant_point_id();
        
        if ( ! $api_key || ! $merchant_point_id ) {
            return;
        }
        
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }
        
        $currency = $order->get_currency();
        $processed_skus = array();
        $products_payload = array();
        
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product();
            if ( ! $product ) {
                continue;
            }
            
            // Use helper to handle both simple and variable products
            $item_payloads = $this->prepare_product_payloads( $product, $merchant_point_id, $currency );
            
            foreach ( $item_payloads as $payload ) {
                $sku = $payload['merchant_internal_id'];
                
                // Avoid processing same SKU twice
                if ( in_array( $sku, $processed_skus ) ) {
                    continue;
                }
                $processed_skus[] = $sku;
                
                $products_payload[] = $payload;
            }
        }
        
        if ( ! empty( $products_payload ) ) {
            $this->sync_products( $products_payload, $api_key );
        }
    }
    
    /**
     * Check if configured
     */
    /**
     * Get product availability
     * Handles WooCommerce stock management - if disabled, check stock status
     */
    public function get_product_availability( $product ) {
        // If stock management is enabled for this product, use the stock quantity
        if ( $product->managing_stock() ) {
            return (int) $product->get_stock_quantity();
        }
        
        // Stock management disabled - check stock status
        $stock_status = $product->get_stock_status();
        
        if ( $stock_status === 'instock' || $stock_status === 'onbackorder' ) {
            // Product is available but quantity not tracked - send high number
            return 9999;
        }
        
        // Out of stock
        return 0;
    }
    

    public function is_configured() {
        return (bool) get_option( self::OPTION_CONFIGURED, false );
    }
    
    /**
     * Get product images (featured + gallery)
     * Returns array of image URLs
     */
    public function get_product_images( $product, $parent_product = null ) {
        $images = array();
        
        // Get featured/main image
        $image_id = $product->get_image_id();
        if ( $image_id ) {
            $image_url = wp_get_attachment_url( $image_id );
            if ( $image_url ) {
                $images[] = $image_url;
            }
        }
        
        // Get gallery images
        $gallery_ids = $product->get_gallery_image_ids();
        if ( ! empty( $gallery_ids ) ) {
            foreach ( $gallery_ids as $gallery_id ) {
                $gallery_url = wp_get_attachment_url( $gallery_id );
                if ( $gallery_url && ! in_array( $gallery_url, $images ) ) {
                    $images[] = $gallery_url;
                }
            }
        }
        
        // For variations without images, fall back to parent product images
        if ( empty( $images ) && $parent_product ) {
            $parent_image_id = $parent_product->get_image_id();
            if ( $parent_image_id ) {
                $parent_image_url = wp_get_attachment_url( $parent_image_id );
                if ( $parent_image_url ) {
                    $images[] = $parent_image_url;
                }
            }
            
            $parent_gallery_ids = $parent_product->get_gallery_image_ids();
            if ( ! empty( $parent_gallery_ids ) ) {
                foreach ( $parent_gallery_ids as $gallery_id ) {
                    $gallery_url = wp_get_attachment_url( $gallery_id );
                    if ( $gallery_url && ! in_array( $gallery_url, $images ) ) {
                        $images[] = $gallery_url;
                    }
                }
            }
        }
        
        return $images;
    }
    
    /**
     * Get product category path (deepest category, full path e.g. "Electronics > Phones")
     * Matches Magento's category path logic
     */
    public function get_product_category( $product_id ) {
        $terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'all' ) );
        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            return '';
        }
        
        // Build full path for each term by traversing parents
        $term_map = array();
        foreach ( $terms as $term ) {
            $term_map[ $term->term_id ] = $term;
        }
        
        $paths = array();
        foreach ( $terms as $term ) {
            $path_names = array( $term->name );
            $parent_id  = $term->parent;
            
            while ( $parent_id ) {
                // Try from already-fetched terms first, then fetch from DB
                if ( isset( $term_map[ $parent_id ] ) ) {
                    $parent = $term_map[ $parent_id ];
                } else {
                    $parent = get_term( $parent_id, 'product_cat' );
                    if ( is_wp_error( $parent ) || ! $parent ) {
                        break;
                    }
                    $term_map[ $parent_id ] = $parent;
                }
                array_unshift( $path_names, $parent->name );
                $parent_id = $parent->parent;
            }
            
            $paths[] = implode( ' > ', $path_names );
        }
        
        if ( empty( $paths ) ) {
            return '';
        }
        
        // Use the deepest path (most specific category), matching Magento behaviour
        usort( $paths, function( $a, $b ) {
            return substr_count( $b, '>' ) - substr_count( $a, '>' );
        } );
        
        return $paths[0];
    }
    
    /**
     * Get product description (short description + full description)
     */
    public function get_product_description( $product ) {
        $parts = array();
        
        $short = $product->get_short_description();
        if ( $short ) {
            $parts[] = wp_strip_all_tags( $short );
        }
        
        $full = $product->get_description();
        if ( $full ) {
            $parts[] = wp_strip_all_tags( $full );
        }
        
        return implode( "\n\n", $parts );
    }
    
    /**
     * Get product brand (checks pa_brand attribute and product_brand taxonomy)
     */
    public function get_product_brand( $product ) {
        // Check product_brand taxonomy (used by many brand plugins)
        $brand_terms = wp_get_post_terms( $product->get_id(), 'product_brand', array( 'fields' => 'names' ) );
        if ( ! is_wp_error( $brand_terms ) && ! empty( $brand_terms ) ) {
            return $brand_terms[0];
        }
        
        // Check pa_brand attribute (WooCommerce global attribute)
        $brand = $product->get_attribute( 'pa_brand' );
        if ( $brand ) {
            return $brand;
        }
        
        // Check plain "brand" attribute
        $brand = $product->get_attribute( 'brand' );
        if ( $brand ) {
            return $brand;
        }
        
        return '';
    }
    
    /**
     * Get API key
     */
    /**
     * Prepare product payloads - handles both simple and variable products
     * Variable products are expanded into individual variation payloads
     */
    public function prepare_product_payloads( $product, $merchant_point_id, $currency ) {
        $payloads = array();
        
        // Gather shared fields from the parent/simple product
        $description = $this->get_product_description( $product );
        $brand       = $this->get_product_brand( $product );
        $category    = $this->get_product_category( $product->get_id() );
        
        // Check if it is a variable product
        if ( $product->is_type( 'variable' ) ) {
            // Get all variations
            $variations = $product->get_available_variations();
            
            foreach ( $variations as $variation_data ) {
                $variation = wc_get_product( $variation_data['variation_id'] );
                if ( ! $variation ) {
                    continue;
                }
                
                // Build variation name with attributes (e.g., "Product Name - Red, Large")
                $variation_name = $category ? $product->get_name() . ' - ' . $category : $product->get_name();
                $attributes = $variation->get_variation_attributes();
                if ( ! empty( $attributes ) ) {
                    $attr_values = array();
                    foreach ( $attributes as $attr_key => $attr_value ) {
                        if ( $attr_value ) {
                            $attr_values[] = $attr_value;
                        }
                    }
                    if ( ! empty( $attr_values ) ) {
                        $variation_name .= ' - ' . implode( ', ', $attr_values );
                    }
                }
                
                // Get images for variation (with parent fallback)
                $images = $this->get_product_images( $variation, $product );
                
                $payload = array(
                    'name' => $variation_name,
                    'price' => $this->apply_price_modifier( (float) $variation->get_price() ),
                    'currency' => $currency,
                    'availability' => $this->get_product_availability( $variation ),
                    'merchant_point_id' => $merchant_point_id,
                    'merchant_internal_id' => $variation->get_sku() ?: (string) $variation->get_id(),
                    'item_group_id' => 'woocommerce-product-' . $product->get_id(),
                    'item_group_title' => $product->get_name(),
                );
                if ( ! empty( $attr_values ) ) {
                    $payload['variant_options'] = array_values( array_unique( $attr_values ) );
                }
                
                if ( $description ) {
                    $payload['description'] = $description;
                }
                if ( $brand ) {
                    $payload['brand'] = $brand;
                }
                if ( $category ) {
                    $payload['category'] = $category;
                }
                if ( ! empty( $images ) ) {
                    $payload['images'] = $images;
                }
                
                $payloads[] = $payload;
            }
        } else {
            // Simple product - skip if no price
            $price = $this->apply_price_modifier( (float) $product->get_price() );
            if ( $price >= 0.01 ) {
                // Get images for simple product
                $images = $this->get_product_images( $product );
                
                $product_name = $category ? $product->get_name() . ' - ' . $category : $product->get_name();
                
                $payload = array(
                    'name' => $product_name,
                    'price' => $price,
                    'currency' => $currency,
                    'availability' => $this->get_product_availability( $product ),
                    'merchant_point_id' => $merchant_point_id,
                    'merchant_internal_id' => $product->get_sku() ?: (string) $product->get_id(),
                );
                
                if ( $description ) {
                    $payload['description'] = $description;
                }
                if ( $brand ) {
                    $payload['brand'] = $brand;
                }
                if ( $category ) {
                    $payload['category'] = $category;
                }
                if ( ! empty( $images ) ) {
                    $payload['images'] = $images;
                }
                
                $payloads[] = $payload;
            }
        }
        
        return $payloads;
    }

    /**
     * Apply the percentage price modifier to a given price
     */
    public function apply_price_modifier( $price ) {
        $modifier = (float) get_option( self::OPTION_PRICE_MODIFIER, '0' );
        if ( $modifier === 0.0 ) {
            return $price;
        }
        $adjusted_price = $price * ( 1 + ( $modifier / 100 ) );
        return round( max( 0.0, $adjusted_price ), 2 );
    }
    

    public function get_api_key() {
        return get_option( self::OPTION_API_KEY, '' );
    }
    
    /**
     * Get setup URL
     * 
     */
    public function get_setup_url() {
        $shop_url = home_url();
        
        // Generate a security nonce and store it temporarily
        $nonce = bin2hex( random_bytes( 16 ) );
        $locale = get_locale();
        update_option( self::OPTION_SETUP_NONCE, $nonce . '|' . time() . '|' . $locale );
        
        // Flush rewrite rules to ensure callback endpoint works
        flush_rewrite_rules();
        
        $return_url = home_url( '/ivo-callback/' ) . '?nonce=' . $nonce;
        
        $params = array(
            'url_shop' => $shop_url,
            'url_return' => $return_url,
            'platform' => 'woocommerce',
            'version' => defined('WC_VERSION') ? WC_VERSION : get_bloginfo('version'),
            'ip_server' => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
            'os_server' => php_uname( 's' ),
            'locale' => $locale,
        );
        
        return IVO_SETUP_URL . '?' . http_build_query( $params );
    }
    
    /**
     * Fetch merchant points from IVO API
     * 
     */
    public function fetch_merchant_points( $api_key = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }
        
        if ( ! $api_key ) {
            return array();
        }
        
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, IVO_API_BASE_URL . '/v1/merchant-api/merchant-points' );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 30 );
        
        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );
        
        if ( $http_code === 200 ) {
            $data = json_decode( $response, true );
            return $this->normalize_merchant_points( $data );
        }
        
        return array();
    }

    /**
     * Normalize API merchant-points responses to a flat list with id aliases.
     */
    private function normalize_merchant_points( $data ) {
        if ( ! is_array( $data ) ) {
            return array();
        }

        $points = $data['points'] ?? $data['data'] ?? $data;
        if ( ! is_array( $points ) ) {
            return array();
        }

        $normalized = array();
        foreach ( $points as $point ) {
            if ( ! is_array( $point ) ) {
                continue;
            }
            if ( isset( $point['_id'] ) && ! isset( $point['id'] ) ) {
                $point['id'] = $point['_id'];
            }
            $normalized[] = $point;
        }

        return $normalized;
    }
    
    /**
     * Get Merchant Point ID
     * 
     */
    public function get_merchant_point_id() {
        // First check option
        $config_id = get_option( self::OPTION_MERCHANT_POINT_ID, '' );
        if ( $config_id ) {
            return $config_id;
        }
        
        // Fetch from API only when the merchant has exactly one possible point.
        $points = $this->fetch_merchant_points();
        if ( count( $points ) === 1 ) {
            return $points[0]['id'] ?? $points[0]['_id'] ?? null;
        }
        
        return null;
    }
    
    /**
     * Sync products to IVO API
     * 
     */
    public function sync_products( $products_data, $api_key = null, $mode = 'async', $integration_run_id = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }

        if ( ! $api_key ) {
            return array( 'code' => 0, 'response' => null );
        }

        // EXACT payload from Magento Config.php syncProducts()
        $payload = array(
            'mode' => $mode,
            'import_name' => 'api_sync_import_woocommerce', // Similar to Magento's "api_sync_import_magento"
            'products' => $products_data,
        );
        if ( $integration_run_id ) {
            $payload['integration_run_id'] = $integration_run_id;
        }
        
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, IVO_API_BASE_URL . '/v1/merchant-api/product/sync-multiple' );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
            'Content-Type: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $payload ) );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 60 );
        
        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );
        
        // EXACT return format from Magento
        return array( 'code' => $http_code, 'response' => json_decode( $response, true ) );
    }
    
    /**
     * Get product IVO info by SKU
     * 
     */
    public function get_product_ivo_info( $sku, $api_key = null ) {
        if ( ! $api_key ) {
            $api_key = $this->get_api_key();
        }
        
        if ( ! $api_key ) {
            return null;
        }
        
        // EXACT payload from Magento Config.php getProductIvoInfo()
        $payload = array(
            'import_name' => 'api_sync_import_woocommerce',
            'merchant_internal_id' => $sku,
        );
        
        $url = IVO_API_BASE_URL . '/v1/merchant-api/product/info-by-sku';
        
        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Accept: application/json',
            'Content-Type: application/json',
        ) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $payload ) );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 30 );
        
        $response = curl_exec( $ch );
        curl_close( $ch );
        
        if ( $response ) {
            return json_decode( $response, true );
        }
        
        return null;
    }

    /**
     * Register inbound REST endpoints (called from rest_api_init).
     *
     * Endpoint:  POST /wp-json/ivo-marketplace/v1/stock
     * Auth:      Authorization: Bearer <api_key>     (matches stored API key)
     * Body:      { "products": [ { "merchant_internal_id": "SKU-or-ID", "availability": 5 }, ... ] }
     *
     * Triggered when a sale on IVO occurs, so the merchant's local WooCommerce stock stays in sync.
     */
    public function register_webhook_routes() {
        register_rest_route( 'ivo-marketplace/v1', '/stock', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'rest_update_stock' ),
            'permission_callback' => array( $this, 'rest_check_auth' ),
        ) );
    }

    /**
     * Verify Authorization: Bearer <api_key> against the stored API key.
     */
    public function rest_check_auth( $request ) {
        $expected = (string) $this->get_api_key();
        if ( $expected === '' ) {
            return new WP_Error( 'ivo_not_configured', 'IVO Marketplace is not configured', array( 'status' => 503 ) );
        }

        $header = (string) $request->get_header( 'authorization' );
        if ( $header === '' ) {
            return new WP_Error( 'ivo_unauthorized', 'Missing Authorization header', array( 'status' => 401 ) );
        }
        if ( stripos( $header, 'Bearer ' ) === 0 ) {
            $bearer = trim( substr( $header, 7 ) );
        } else {
            $bearer = trim( $header );
        }

        if ( $bearer === '' || ! hash_equals( $expected, $bearer ) ) {
            return new WP_Error( 'ivo_unauthorized', 'Invalid API key', array( 'status' => 401 ) );
        }
        return true;
    }

    /**
     * Handle POST /wp-json/ivo-marketplace/v1/stock
     */
    public function rest_update_stock( $request ) {
        $data = $request->get_json_params();
        if ( ! is_array( $data ) || empty( $data['products'] ) || ! is_array( $data['products'] ) ) {
            return new WP_REST_Response( array(
                'success' => false,
                'error'   => 'Invalid payload: expected { products: [...] }',
            ), 400 );
        }

        $updated = array();
        $errors  = array();
        
        $should_update = get_option( self::OPTION_UPDATE_STOCK, '1' );

        foreach ( $data['products'] as $item ) {
            $ref = isset( $item['merchant_internal_id'] ) ? (string) $item['merchant_internal_id'] : '';
            if ( $ref === '' || ! array_key_exists( 'availability', $item ) ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => 'Missing merchant_internal_id or availability' );
                continue;
            }
            $delta = (int) $item['availability'];

            $product_id = $this->resolve_product_id( $ref );
            if ( ! $product_id ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => 'Product not found' );
                continue;
            }

            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => 'Product not loadable' );
                continue;
            }

            // Calculate new stock using delta
            $current_stock = $product->get_stock_quantity();
            if ( $current_stock === null ) {
                $current_stock = 9999; // Treat unmanaged stock as high quantity
            }
            $new_stock = max( 0, $current_stock + $delta );

            if ( $should_update !== '1' ) {
                $updated[] = array( 'merchant_internal_id' => $ref, 'availability' => $new_stock, 'note' => 'Skipped (stock sync disabled)' );
                continue;
            }

            try {
                // Make sure stock management is on so the quantity is honored
                if ( ! $product->managing_stock() ) {
                    $product->set_manage_stock( true );
                }
                wc_update_product_stock( $product, $new_stock, 'set' );
                $product->set_stock_status( $new_stock > 0 ? 'instock' : 'outofstock' );
                $product->save();

                $updated[] = array( 'merchant_internal_id' => $ref, 'availability' => $new_stock );
            } catch ( \Throwable $e ) {
                $errors[] = array( 'merchant_internal_id' => $ref, 'error' => $e->getMessage() );
            }
        }

        return new WP_REST_Response( array(
            'success' => empty( $errors ),
            'updated' => $updated,
            'errors'  => $errors,
        ), 200 );
    }

    /**
     * Resolve a product (or variation) by SKU first, then by numeric ID.
     */
    private function resolve_product_id( $ref ) {
        $product_id = wc_get_product_id_by_sku( $ref );
        if ( $product_id ) {
            return (int) $product_id;
        }
        if ( ctype_digit( (string) $ref ) ) {
            $product = wc_get_product( (int) $ref );
            if ( $product ) {
                return (int) $ref;
            }
        }
        return 0;
    }
}

// Initialize the plugin
IVO_Marketplace::get_instance();

// Activation hook - flush rewrite rules
register_activation_hook( __FILE__, function() {
    IVO_Marketplace::get_instance()->register_callback_endpoint();
    flush_rewrite_rules();
} );

// Deactivation hook
register_deactivation_hook( __FILE__, function() {
    flush_rewrite_rules();
} );
